<div class="message-container">
    @php
        $alerts = [
            'success_message' => 'success',
            'admin_error_message' => 'danger',
            'warning_message' => 'warning',
            'success' => 'success',
            'info' => 'warning',
            'error' => 'danger'
        ];
    @endphp

    @foreach($alerts as $key => $class)
        @if(session()->has($key))
            <div class="alert alert-{{ $class }} alert-dismissible fade show border-0 shadow-sm mb-3" role="alert">
                <div class="d-flex align-items-center">
                    {{-- Optional: Add an icon based on type --}}
                    <div class="me-2 mr-3">
                        @if($class == 'success') ✅ @elseif($class == 'danger') ❌ @else ℹ️ @endif
                    </div>
                    <div>
                        {{ session($key) }}
                    </div>
                </div>
                {{-- Custom Styled Close Button --}}
                <button type="button"
                        class="btn-close-custom"
                        onclick="this.parentElement.style.display='none';"
                        style="position: absolute; top: 0; right: 0; z-index: 2; padding: 0.75rem 1rem; background: transparent; border: none; font-size: 1.5rem; line-height: 1; cursor: pointer; opacity: 0.5;">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        @endif
    @endforeach
</div>

<style>
    .btn-close-custom:hover {
        opacity: 1 !important;
        color: #000;
    }
    .alert {
        position: relative;
        padding-right: 3rem; /* Make room for our custom X */
    }
</style>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Find all alerts and set a timeout to close them
        setTimeout(function() {
            let alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                let bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 20000); // 20000ms = 20 seconds
    });


</script>

<script>
        document.addEventListener('livewire:init', () => {
            Livewire.on('toast', (event) => {
                butterup.toast({
                    message: event.message,
                    type: event.type, // dynamic: 'success' or 'error'
                    icon: true
                });
            });
        });

       

    </script>


{{-- Use this when you are moving the user to a new page (like after a successful login). --}}
{{-- return redirect()->route('admin.dashboard')->with('success_message', 'Welcome back, Akhy!'); --}}


{{-- Use this when you want to show a message on the same page (like after a failed login attempt). --}}
{{-- session()->flash('admin_error_message', 'Invalid email or password'); --}}

