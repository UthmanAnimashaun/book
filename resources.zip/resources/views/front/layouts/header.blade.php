<div 
    x-data="{ 
        mobileMenuOpen: false, 
        cartOpen: false, 
        cartItemCount: 3, 
        cartTotalPrice: 49.97,
        isScrolled: false 
    }"
    @scroll.window="isScrolled = (window.pageYOffset > 20)"
    class="relative"
>

    <header 
        class="sticky top-0 z-50 w-full transition-all duration-300"
        :class="{ 'bg-white shadow-lg h-16': isScrolled, 'bg-white h-20': !isScrolled }"
    >
    
        <div class="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
            
            <div class="flex items-center justify-between h-20 transition-all duration-300" :class="{ 'h-16': isScrolled }">
                
                <div class="flex-shrink-0">
                    <a href="#" class="flex items-center space-x-2 text-2xl font-black tracking-tight text-emerald-600 hover:opacity-90 transition">
                        <div class="p-1.5 bg-emerald-100 rounded-lg">
                            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.723 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5s3.332.477 4.5 1.253v13C19.832 18.723 18.246 18 16.5 18s-3.332.477-4.5 1.253"></path>
                            </svg>
                        </div>
                        <span class="hidden lg:block">Book Buffet</span>
                    </a>
                </div>

                <div class="flex-1 max-w-lg mx-8 hidden md:block">
                    <div class="relative group">
                        <input 
                            type="search" 
                            placeholder="Search your next favorite book..." 
                            class="w-full py-2.5 pl-11 pr-4 text-sm bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all duration-200"
                        >
                        <svg class="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-emerald-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </div>
                </div>

                <nav class="flex items-center space-x-1 lg:space-x-4">
                    
                    <div class="hidden lg:flex items-center space-x-1">
                        <a href="#" class="px-4 py-2 text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition font-semibold">Home</a>
                        <a href="#" class="px-4 py-2 text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition font-semibold">Shop</a>
                        
                        <div class="relative" x-data="{ open: false }" @click.away="open = false">
                            <button @click="open = !open" class="flex items-center px-4 py-2 text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition font-semibold">
                                Profile
                                <svg class="ml-1 w-4 h-4 transition-transform" :class="{'rotate-180': open}" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                            </button>
                            <div x-cloak x-show="open" x-transition class="absolute right-0 mt-3 w-56 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 z-50">
                                <a href="#" class="block px-5 py-2.5 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 transition">My Orders</a>
                                <a href="#" class="block px-5 py-2.5 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 transition">Account Settings</a>
                                <hr class="my-2 border-gray-100">
                                <a href="#" class="block px-5 py-2.5 text-sm text-red-600 hover:bg-red-50 transition">Logout</a>
                            </div>
                        </div>
                    </div>

                    <button @click="cartOpen = !cartOpen" class="relative p-3 bg-gray-50 text-gray-600 hover:bg-emerald-50 hover:text-emerald-600 rounded-full transition-all group">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
                        <span x-text="cartItemCount" class="absolute top-1 right-1 flex items-center justify-center min-w-[20px] h-5 px-1.5 text-[10px] font-bold text-white bg-emerald-600 border-2 border-white rounded-full group-hover:scale-110 transition-transform"></span>
                    </button>

                    <button @click="mobileMenuOpen = !mobileMenuOpen" class="lg:hidden p-3 text-gray-600 hover:bg-gray-100 rounded-full transition">
                        <svg x-show="!mobileMenuOpen" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
                        <svg x-show="mobileMenuOpen" x-cloak class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </nav>
            </div>
        </div>

        <div x-cloak x-show="mobileMenuOpen" x-transition class="lg:hidden border-t border-gray-100 bg-white">
            <div class="px-4 py-6 space-y-2">
                <a href="#" class="block px-4 py-3 rounded-xl bg-emerald-50 text-emerald-700 font-bold text-lg">Home</a>
                <a href="#" class="block px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 font-semibold text-lg transition">Shop</a>
                <a href="#" class="block px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 font-semibold text-lg transition">Profile</a>
                <a href="#" class="block px-4 py-3 rounded-xl text-red-600 hover:bg-red-50 font-semibold text-lg transition">Logout</a>
            </div>
        </div>
    </header>
</div>


    {{-- sidebar for cart items --}}
    <div>

        <div x-cloak x-show="cartOpen" @click="cartOpen = false"
            x-transition:enter="transition ease-in-out duration-300" x-transition:enter-start="opacity-0"
            x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in-out duration-300"
            x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
            class="fixed inset-0 bg-gray-600 bg-opacity-75 transition-opacity z-[90]" aria-hidden="true"></div>

        <div x-cloak x-show="cartOpen" x-transition:enter="transition ease-in-out duration-300 transform"
            x-transition:enter-start="translate-x-full" x-transition:enter-end="translate-x-0"
            x-transition:leave="transition ease-in-out duration-300 transform" x-transition:leave-start="translate-x-0"
            x-transition:leave-end="translate-x-full" class="fixed inset-y-0 right-0 max-w-full flex z-[100]">
            <div class="w-screen max-w-[80vw] sm:max-w-sm md:max-w-md">
                <div class="h-full flex flex-col bg-white shadow-xl">

                    <div class="px-4 py-4 sm:px-6 border-b">
                        <div class="flex items-start justify-between">
                            <h2 class="text-lg font-medium text-book-dark">
                                Shopping Cart (<span x-text="cartItemCount"></span>)
                            </h2>
                            <div class="ml-3 h-7 flex items-center">
                                <button @click="cartOpen = false" type="button"
                                    class="p-2 text-gray-400 hover:text-gray-500 rounded-md">
                                    <span class="sr-only">Close panel</span>
                                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                        stroke="currentColor" aria-hidden="true">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="mt-4 flex-1 overflow-y-auto px-4 sm:px-6">
                        <ul role="list" class="divide-y divide-gray-200">
                            <li class="flex py-6">
                                <div
                                    class="h-16 w-16 flex-shrink-0 overflow-hidden rounded-md border border-gray-200 bg-gray-100">
                                </div>
                                <div class="ml-4 flex flex-1 flex-col">
                                    <div>
                                        <div class="flex justify-between text-base font-medium text-book-dark">
                                            <h3><a href="#">The Midnight Library</a></h3>
                                            <p class="ml-4">$15.99</p>
                                        </div>
                                        <p class="mt-1 text-sm text-gray-500">Matt Haig</p>
                                    </div>
                                    <div class="flex flex-1 items-end justify-between text-sm">
                                        <p class="text-gray-500">Qty 1</p>
                                        <button type="button"
                                            class="font-medium text-book-primary hover:text-blue-500">Remove</button>
                                    </div>
                                </div>
                            </li>
                            <li class="flex py-6">
                                <div
                                    class="h-16 w-16 flex-shrink-0 overflow-hidden rounded-md border border-gray-200 bg-gray-100">
                                </div>
                                <div class="ml-4 flex flex-1 flex-col">
                                    <div>
                                        <div class="flex justify-between text-base font-medium text-book-dark">
                                            <h3><a href="#">Project Hail Mary</a></h3>
                                            <p class="ml-4">$19.99</p>
                                        </div>
                                        <p class="mt-1 text-sm text-gray-500">Andy Weir</p>
                                    </div>
                                    <div class="flex flex-1 items-end justify-between text-sm">
                                        <p class="text-gray-500">Qty 1</p>
                                        <button type="button"
                                            class="font-medium text-book-primary hover:text-blue-500">Remove</button>
                                    </div>
                                </div>
                            </li>
                            <li class="flex py-6">
                                <div
                                    class="h-16 w-16 flex-shrink-0 overflow-hidden rounded-md border border-gray-200 bg-gray-100">
                                </div>
                                <div class="ml-4 flex flex-1 flex-col">
                                    <div>
                                        <div class="flex justify-between text-base font-medium text-book-dark">
                                            <h3><a href="#">The Food Lab</a></h3>
                                            <p class="ml-4">$13.99</p>
                                        </div>
                                        <p class="mt-1 text-sm text-gray-500">J. Kenji López-Alt</p>
                                    </div>
                                    <div class="flex flex-1 items-end justify-between text-sm">
                                        <p class="text-gray-500">Qty 1</p>
                                        <button type="button"
                                            class="font-medium text-book-primary hover:text-blue-500">Remove</button>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>

                    <div class="border-t border-gray-200 px-4 py-6 sm:px-6">
                        <div class="flex justify-between text-base font-medium text-book-dark">
                            <p>Subtotal</p>
                            <p>$<span x-text="cartTotalPrice.toFixed(2)"></span></p>
                        </div>
                        <p class="mt-0.5 text-sm text-gray-500">Shipping and taxes calculated at checkout.</p>
                        <div class="mt-6">
                            <a href="#"
                                class="flex items-center justify-center rounded-md border border-transparent bg-book-primary px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-blue-600 transition duration-150">
                                Checkout
                            </a>
                        </div>
                        <div class="mt-6 flex justify-center text-center text-sm text-gray-500">
                            <p>
                                or
                                <button @click="cartOpen = false" type="button"
                                    class="font-medium text-book-primary hover:text-blue-600 ml-1">
                                    Continue Shopping
                                    <span aria-hidden="true"> &rarr;</span>
                                </button>
                            </p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>