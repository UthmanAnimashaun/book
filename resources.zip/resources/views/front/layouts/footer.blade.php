<!-- ========== FOOTER ========== -->

<footer class="bg-blue-900 text-gray-300 mt-16 pt-12 pb-8 border-t border-amber-600/30">
  <div class="max-w-6xl mx-auto px-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
    <div>
      <h4 class="text-lg font-semibold text-gray-100 mb-2">Book Buffet</h4>
      <p class="text-gray-400 hover:text-gray-200 focus:outline-hidden focus:text-gray-200">Lagos' premier multi-vendor bookstore connecting readers with book sellers across the states.</p>
    </div>
    <div>
      <h4 class="text-lg font-semibold text-gray-100 mb-2">Shop</h4>
      <ul class=" grid grid space-y-3 text-sfm">
        <li><a href="{{ route('product-shop') }}" class="hover:text-amber-600 transition duration-150">All Books</a></li>
        {{-- <li><a href="#" class="hover:text-amber-600 transition duration-150">Categories</a></li> --}}
        <li><a href="{{ route('about') }}" class="hover:text-amber-600 transition duration-150">About Us</a></li>
        <li><a href="{{ route('contact') }}" class="hover:text-amber-600 transition duration-150">Contact Us</a></li>
        <li><a href="#" class="hover:text-amber-600 transition duration-150">Delivery Info</a></li>
      </ul>
    </div>
    <div>
      <h4 class="text-lg font-semibold text-gray-100 mb-2">Vendors</h4>
      <ul class="grid space-y-3">
        <li><a href="{{ route('vendors') }}" class="hover:text-amber-600 transition duration-150">Vendors</a></li>
        <li><a href="#" class="hover:text-amber-600 transition duration-150">Become a Vendor</a></li>
        <li><a href="{{ route('admin.login') }}" class="hover:text-amber-600 transition duration-150">Vendor Login</a></li>
        <li><a href="#" class="hover:text-amber-600 transition duration-150">Vendor Help</a></li>
      </ul>
    </div>
    <div>
      <h4 class="text-lg font-semibold text-gray-100 mb-2">Links</h4>
      <ul class=" grid space-y-3">
       
        <li><a href="{{ route('faq') }}" class="hover:text-amber-600 transition duration-150">FAQ</a></li>
        <li><a href="{{ route('pp') }}" class="hover:text-amber-600 transition duration-150">Privacy Policy</a></li>
        <li><a href="{{ route('tc') }}" class="hover:text-amber-600 transition duration-150">Terms & Condition</a></li>
      </ul>
    </div>
  
  </div>
  <div class="mt-8 text-center text-sm text-gray-400  hover:text-gray-200 focus:outline-hidden space-x-3 focus:text-gray-200">
      <p> © 2025 Book Buffet. All rights reserved. Made with ❤️ By: <a href="http://axiondesign.netlify.app" target="_blank" rel="noopener noreferrer">Uthman (AXION)</a> <b></b> in Lagos, Nigeria. </p>

      <a href="tel:{{ optional($websites[0])->phone_number }}" class="hover:text-amber-600 transition duration-150"><i class="fas fa-phone"></i> {{ optional($websites[0])->phone_number }}</a>
      
      <a href="mailto:{{ optional($websites[0])->email }}" class="hover:text-amber-600 transition duration-150"><i class="fas fa-envelope" ></i>  {{ optional($websites[0])->email }}</a>

      <a href="{{ optional($websites[0])->facebook }}" class="hover:text-amber-600 transition duration-150"><i class="fab fa-facebook"></i></a>

      <a href="{{ optional($websites[0])->whatsapp }}" class="hover:text-amber-600 transition duration-150">
          <i class="fab fa-whatsapp"></i>
         
      </a>

      <a href="{{ optional($websites[0])->twitter }}" class="hover:text-amber-600 transition duration-150"><i class="fab fa-twitter"></i></a>



   
   
  </div>
</footer>
  <!-- ========== END FOOTER ========== -->