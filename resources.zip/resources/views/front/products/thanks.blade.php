<?php use App\Models\Product; use Illuminate\Support\Str;
?>
@extends('front.layouts.layout')
@section('pageTitle', isset($pageTitle) ?  $pageTitle : "Cart")
@section('content')

      <!-- Page Introduction Wrapper -->
    <div class="page-style-a">
        <div class="container">
            <div class="page-intro">
                <h2>Thanks</h2>
                <ul class="bread-crumb">
                    <li class="has-separator">
                        <i class="ion ion-md-home"></i>
                        <a href="{{ url('/') }}">Home</a>
                    </li>
                    <li class="is-marked">
                        <a href="javascript:;">Thanks</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="page-cart u-s-p-t-80">
        <div class="container">
            <div class="row" >
               <center class="col-12 text-bold">

              
                    <div class="col-12 alert alert-success alert-dismissible fade show" role="alert">
                        YOUR ORDER HAS BEEN PLACED SUCCESSFULLY </h1>
                        <p>Your order number is <b class="text-danger"> {{ Session::get('order_id') }} </b> and Grand total is  <b class="text-danger"><s class="double">N</s> {{ Session::get('grand_total') }}</b> </p>
                        
                      
                    </div>
                </center>
              
             
            </div>
        </div>
    </div>

@endsection