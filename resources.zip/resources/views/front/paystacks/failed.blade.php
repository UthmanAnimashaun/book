<?php use App\Models\Product; use Illuminate\Support\Str;
?>
@extends('front.layouts.layout')
@section('pageTitle', isset($pageTitle) ?  $pageTitle : "Failed")
@section('content')



<main class="flex-grow flex items-center justify-center p-6">
        
    <div  class="transition-opacity duration-500  max-w-md w-full">

        <div class="bg-white rounded-2xl shadow-lg p-8 w-full border border-red-200">
            <div class="flex flex-col items-center text-center">
                <i class="fas fa-times-circle text-7xl text-red-500 mb-6 animate-pop-in"></i>
                
                <h2 class="text-3xl font-extrabold text-blue-900 mb-2">Payment Failed</h2>
                <p class="text-gray-600 mt-2">
                    Sorry, something went wrong while processing your payment. Your order could not be completed.
                </p>
                
                <div class="mt-6 p-4 rounded-xl bg-gray-50 border border-gray-200 w-full text-left space-y-2 text-sm">
                    <p class="text-red-600 font-semibold"><i class="fas fa-exclamation-triangle mr-2"></i> Error: Insufficient funds or card declined.</p>
                    <p class="text-gray-600">Please verify your payment details or try a different method.</p>
                </div>

                <div class="flex flex-col sm:flex-row gap-3 mt-8 w-full">
                    <a href="/checkout" class="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition duration-150 shadow-md">
                        <i class="fas fa-sync-alt mr-2"></i> Try Again
                    </a>
                    <a href="/" class="w-full bg-gray-700 hover:bg-gray-800 text-white font-bold py-3 px-4 rounded-lg transition duration-150 shadow-md">
                        <i class="fas fa-home mr-2"></i> Go Home
                    </a>
                </div>
            </div>
        </div>
        
        </div>

</main>


@endsection

@php
    Session::forget('order_id');
    Session::forget('grand_total');
    Session::forget('email');
    Session::forget('currency');
    Session::forget('name');

@endphp