<?php use App\Models\Product; use Illuminate\Support\Str;
?>
@extends('front.layouts.layout')
@section('pageTitle', isset($pageTitle) ?  $pageTitle : "Success")
@section('content')




<main class="flex-grow flex items-center justify-center p-6">
        
    <div  class="transition-opacity duration-500  max-w-md w-full">

        <div class="bg-white rounded-2xl shadow-lg p-8 w-full border border-green-200">
            <div class="flex flex-col items-center text-center">
                <i class="fas fa-check-circle text-7xl text-green-500 mb-6 animate-pop-in"></i>
                
                <h2 class="text-3xl font-extrabold text-blue-900 mb-2">Order Placed Successfully!</h2>
                <p class="text-gray-600 mt-2">
                    Thank you for shopping with {{ config("app.name") }}. Your order has been received and is being processed.
                </p>
        
        
        
                <div class="flex flex-col sm:flex-row gap-3 mt-8 w-full">
                    <a href="{{ route("user.orders") }}" class="w-full bg-blue-900 hover:bg-blue-800 text-white font-bold py-3 px-4 rounded-lg transition duration-150 shadow-md">
                        <i class="fas fa-list-alt mr-2"></i> View My Orders
                    </a>
                    <a href="{{ route("product-shop") }}" class="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-4 rounded-lg transition duration-150 shadow-md">
                        <i class="fas fa-book-open mr-2"></i> Continue Shopping
                    </a>
                </div>
            </div>
        </div>
        
        </div>

</main>





@endsection

@php
    Session::forget('order_id');
    Session::forget('grand_total');
    Session::forget('email');
    Session::forget('currency');
    Session::forget('name');

@endphp