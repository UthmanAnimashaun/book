<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ALERT: New User Deployment</title>
    <!-- Use a system font stack for better email client compatibility -->
    <style type="text/css">
        /* Basic Resets and Font Stack */
        body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
        img { -ms-interpolation-mode: bicubic; }
        a[x-apple-data-detectors] { color: inherit !important; text-decoration: none !important; font-size: inherit !important; font-family: inherit !important; font-weight: inherit !important; line-height: inherit !important; }

        /* General Styles for the futuristic theme */
        .container {
            background-color: #1A1F30; /* Dark inner container */
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5); /* Subtle lift */
        }
        .text-light { color: #E0E6F0; } /* Light text */
        .text-accent { color: #00AEEF; } /* Electric blue accent */

        /* Alert Details box styling */
        .details-box {
            background-color: #111520;
            border: 1px solid #333C52;
            border-radius: 8px;
            padding: 20px;
        }

        /* Responsive adjustments */
        @media only screen and (max-width: 600px) {
            .main-wrapper {
                width: 100% !important;
            }
            .content-padding {
                padding: 20px !important;
            }
            .header-logo {
                padding: 20px 0 !important;
            }
        }
    </style>
</head>

<body style="margin: 0; padding: 0; background-color: #0A0D15; font-family: Arial, Helvetica, sans-serif;">

<!-- Outer Wrapper Table for Background and Centering -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width: 100%; table-layout: fixed; background-color: #0A0D15;">
    <tr>
        <td align="center" style="padding: 40px 10px;">

            <!-- Main Container Table (Max Width) - FIXED FOR MOBILE RESPONSIVENESS -->
            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="main-wrapper" style="max-width: 600px; width: 100%;">
                <tr>
                    <td align="center">

                        <!-- Inner Content Wrapper (Futuristic Card Look) -->
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="container" style="background-color: #1A1F30; border-radius: 12px;">

                            <!-- Header / Logo -->
                            <tr>
                                <td align="center" style="padding: 30px 0 20px 0;" class="header-logo">
                                    <h1 style="margin: 0; font-size: 28px; color: #00AEEF; letter-spacing: 2px; text-shadow: 0 0 5px rgba(0, 174, 239, 0.4);">
                                        {{ config('app.name') }}
                                    </h1>
                                </td>
                            </tr>

                            <!-- Alert Title -->
                            <tr>
                                <td align="center" style="padding: 0 30px 20px 30px; border-bottom: 1px solid #333C52;" class="content-padding">
                                    <h2 style="margin: 0; font-size: 26px; font-weight: 700; color: #10B981; line-height: 1.2;">
                                        NEW USER DEPLOYMENT CONFIRMED
                                    </h2>
                                </td>
                            </tr>

                            <!-- Message Header -->
                            <tr>
                                <td align="left" style="padding: 30px 30px 20px 30px;" class="content-padding">
                                    <p style="margin: 0 0 10px 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                        Dear <strong style="color: #E0E6F0;">{{ config('app.name') }} Operations</strong>,
                                    </p>
                                    <p style="margin: 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                        A new user has successfully completed the registration and activation protocol.
                                    </p>
                                </td>
                            </tr>

                            <!-- User Details Box -->
                            <tr>
                                <td align="left" style="padding: 0 30px 30px 30px;" class="content-padding">
                                    <p style="margin: 0 0 10px 0; font-size: 16px; color: #E0E6F0; font-weight: bold; line-height: 1.6;">
                                        User Profile Data:
                                    </p>
                                    <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td class="details-box" style="background-color: #111520; border: 1px solid #10B981; border-radius: 8px; padding: 20px;">

                                                <!-- Metadata -->
                                                <p style="margin: 0 0 15px 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                                    <strong style="color: #E0E6F0;">User Name:</strong> <span style="color: #00AEEF;">{{ $name }}</span>
                                                </p>
                                                <p style="margin: 0 0 15px 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                                    <strong style="color: #E0E6F0;">User Email:</strong> <a href="mailto:{{ $email }}" style="color: #00AEEF; text-decoration: none;">{{ $email }}</a>
                                                </p>
                                                <p style="margin: 0 0 5px 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                                    <strong style="color: #E0E6F0;">User State:</strong> <span style="color: #E0E6F0;">{{ $state }}</span>
                                                </p>
                                                <p style="margin: 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                                    <strong style="color: #E0E6F0;">Registered Time:</strong> <span style="color: #E0E6F0;">{{ $created_at }}</span>
                                                </p>
                                                <p style="margin: 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                                    <strong style="color: #E0E6F0;">Confirmed Time:</strong> <span style="color: #E0E6F0;">{{ $updated_at }}</span>
                                                </p>

                                            </td>
                                        </tr>
                                    </table>
                                    <!-- End User Details Box -->
                                </td>
                            </tr>




                            <!-- Footer / Sign-off -->
                            <tr>
                                <td align="left" style="padding: 0 30px 30px 30px; border-top: 1px solid #333C52;" class="content-padding">
                                    <p style="margin: 20px 0 0 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                        This alert was auto-generated by the <b>{{ config('app.name') }}</b>.
                                    </p>
                                    <p style="margin: 10px 0 0 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                        Best regards,<br>
                                        <strong style="color: #00AEEF;">The {{ config("app.name") }} Internal Monitoring System</strong>
                                    </p>
                                </td>
                            </tr>

                        </table>
                        <!-- End Inner Content Wrapper -->

                        <!-- Footer -->
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td align="center" style="padding: 30px 10px 0 10px;">
                                    <p style="margin: 0; font-size: 12px; color: #58617B; line-height: 1.8;">
                                        &copy; 2025 Synthesis Protocol. Internal Communication.
                                    </p>
                                </td>
                            </tr>
                        </table>
                        <!-- End Footer -->

                    </td>
                </tr>
            </table>
            <!-- End Main Container Table -->

        </td>
    </tr>
</table>
<!-- End Outer Wrapper Table -->

</body>
</html>

