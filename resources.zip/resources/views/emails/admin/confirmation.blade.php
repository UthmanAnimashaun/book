
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> {{config('app.name') }} || Account Activation Required</title>
    <!-- Use a system font stack for better email client compatibility -->
    <style type="text/css">
        /* Basic Resets and Font Stack */
        body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
        img { -ms-interpolation-mode: bicubic; }
        a[x-apple-data-detectors] { color: inherit !important; text-decoration: none !important; font-size: inherit !important; font-family: inherit !important; font-weight: inherit !important; line-height: inherit !important; }

        /* General Styles for the futuristic theme */
        .container {
            background-color: #1A1F30; /* Dark inner container */
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5); /* Subtle lift */
        }
        .text-light { color: #E0E6F0; } /* Light text */
        .text-accent { color: #00AEEF; } /* Electric blue accent */
        .button {
            background-color: #00AEEF; /* Electric Blue CTA */
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 174, 239, 0.6); /* Subtle glow effect */
            transition: all 0.3s ease;
        }
        .button a {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 16px;
            font-weight: bold;
            color: #1A1F30 !important; /* Dark text on bright button */
            text-decoration: none;
            display: block;
            padding: 15px 25px;
            border-radius: 8px;
        }

        /* Responsive adjustments */
        @media only screen and (max-width: 600px) {
            .main-wrapper {
                width: 100% !important;
                min-width: 100% !important;
            }
            .content-padding {
                padding: 20px !important;
            }
            .header-logo {
                padding: 20px 0 !important;
            }
        }
    </style>
</head>

<body style="margin: 0; padding: 0; background-color: #0A0D15; font-family: Arial, Helvetica, sans-serif;">

<!-- Outer Wrapper Table for Background and Centering -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width: 100%; table-layout: fixed; background-color: #0A0D15;">
    <tr>
        <td align="center" style="padding: 40px 10px;">

            <!-- Main Container Table (Max Width) -->
            <table border="0" cellpadding="0" cellspacing="0" width="600" class="main-wrapper" style="width: 600px; min-width: 600px;">
                <tr>
                    <td align="center">

                        <!-- Inner Content Wrapper (Futuristic Card Look) -->
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="container" style="background-color: #1A1F30; border-radius: 12px;">

                            <!-- Header / Logo -->
                            <tr>
                                <td align="center" style="padding: 30px 0 20px 0;" class="header-logo">
                                    <h1 style="margin: 0; font-size: 28px; color: #00AEEF; letter-spacing: 2px; text-shadow: 0 0 5px rgba(0, 174, 239, 0.4);">

               {{ config('app.name') }}
                                    </h1>
                                </td>
                            </tr>

                            <!-- Activation Title -->
                            <tr>
                                <td align="center" style="padding: 0 30px 20px 30px;" class="content-padding">
                                    <h2 style="margin: 0; font-size: 26px; font-weight: 700; color: #E0E6F0; line-height: 1.2;">
                                        Initiate Protocol: Account Activation
                                    </h2>
                                </td>
                            </tr>

                            <!-- Main Body Content -->
                            <tr>
                                <td align="left" style="padding: 0 30px 20px 30px;" class="content-padding">
                                    <p style="margin: 0 0 20px 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                        Welcome, <strong style="color: #E0E6F0;">{{ $name }}</strong>. Your digital workspace is ready.
                                    </p>
                                    <p style="margin: 0 0 20px 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                        To complete the handshake and secure your access credentials within our matrix, please click the link below. This final step confirms your identity and deploys your personalized instance.
                                    </p>
                                </td>
                            </tr>

                            <!-- CTA Button Row -->
                            <tr>
                                <td align="center" style="padding: 10px 30px 40px 30px;" class="content-padding">
                                    <table border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td align="center" class="button" style="background-color: #00AEEF; border-radius: 8px;">
                                                <a href="{{ route('admin.confirm-code', ['code' => $code]) }}" target="_blank" style="font-size: 16px; font-weight: bold; color: #1A1F30 !important; text-decoration: none; display: inline-block; padding: 15px 30px; border: 1px solid #00AEEF; border-radius: 8px;">
                                                    ACTIVATE ACCOUNT
                                                </a>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <!-- If the button is not clickable -->
                            <tr>
                                <td align="center" style="padding: 0 30px 30px 30px;" class="content-padding">
                                    <p style="margin: 0; font-size: 14px; color: #58617B; line-height: 1.5;">
                                        If the button above does not render, paste the following URI into your browser console:
                                    </p>
                                    <p style="margin: 10px 0 0 0; font-size: 14px; color: #00AEEF; word-break: break-all;">
                                        <a href="{{ route('admin.confirm-code', ['code' => $code]) }}" style="color: #00AEEF; text-decoration: none;">
                                            {{ route('admin.confirm-code', ['code' => $code]) }}
                                        </a>
                                    </p>
                                </td>
                            </tr>

                        </table>
                        <!-- End Inner Content Wrapper -->

                        <!-- Footer -->
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td align="center" style="padding: 30px 10px 0 10px;">
                                    <p style="margin: 0; font-size: 12px; color: #58617B; line-height: 1.8;">
                                        &copy; 2025
                 <strong>{{ config("app.name") }}</strong>. All systems reserved.
                                    </p>
                                    <p style="margin: 15px 0 0 0; font-size: 12px; color: #58617B;">
                                    </p>
                                </td>
                            </tr>
                        </table>
                        <!-- End Footer -->

                    </td>
                </tr>
            </table>
            <!-- End Main Container Table -->

        </td>
    </tr>
</table>
<!-- End Outer Wrapper Table -->

</body>
</html>
