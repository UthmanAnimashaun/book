<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ optional($websites[0])->name }}</title>
</head>
<body>
    <table>
        <tr><td>Dear {{ $name }}</td></tr>
        <tr><td>&nbsp; <br></td></tr>
        <tr><td>Thank You for shopping with us, Your Order details are as below</td></tr>
        <tr><td></td> <td></td></tr>
        <tr><td>Order Number: {{ $order_id }}</td></tr>
        <tr><td>&nbsp;</td></tr>
        <tr><td>
            Email: {{ $email }}
            <table  style="width:90%" cellpadding="5" cellspacing="5" bgcolor="#f7f4f4">
                <tr bgcolor="#cccccc">
                    <td>Product Name</td>
                    <td>Product Format</td>
                    <td>Product Price</td>
                    <td>Product Code</td>
                    <td>Product Quantity</td>
                </tr>
                @foreach ($orderDetails['orders_products'] as $order)
                    <tr bgcolor="#cccccc">
                        <td>{{ $order['product_name'] }}</td>
                        <td>{{ $order['product_format'] }}</td>
                        <td>{{ $order['product_price'] }}</td>
                        <td>{{ $order['product_code'] }}</td>
                        <td>{{ $order['product_qty'] }}</td>
                    </tr>
                @endforeach
                <tr>
                    <td colspan="5" align='right'>Delivery Charges <s class="double">N</s>{{ $orderDetails['shipping_charges'] }} </td>
                </tr>
                <tr>
                    <td colspan="5" align='right'>Grand Total  <s class="double">N</s>{{ $orderDetails['grand_total'] }}</td>
                </tr>
            </table>
            </td></tr>
            <tr><td></td> <td></td></tr>
            <tr><td></td> <td></td></tr>

            <table>
                <tr><td><strong>Delivery Address:</strong></td></tr>
                <tr><td><strong>Name:</strong> {{ $orderDetails['name'] }}</td></tr>
                <tr><td><strong>Email:</strong> {{ $orderDetails['email'] }}</td></tr>
                <tr><td><strong>Mobile:</strong> {{ $orderDetails['mobile'] }}</td></tr>
                <tr><td><strong>Address:</strong> {{ $orderDetails['address'] }} <br>
                     {{ $orderDetails['city'] }} <br>
                     {{ $orderDetails['state'] }} <br>
                     {{ $orderDetails['pincode'] }} <br>
                     {{ $orderDetails['country'] }} </td></tr>
            </table>

            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>

            <tr><td></td><td></td></tr>
            <tr>
                <td> 
                    <a href="{{ asset('https://bookbuffet.shop/admin/orders/invoice/pdf/'.$orderDetails['id'])  }}">Click here to download Order Invoice
                    </a> 
                </td>
            </tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>

            <tr><td>For any queries, you can contact us at <a href="mailto:{{ optional($websites[0])->email }}">{{ optional($websites[0])->email }}</a> </td></tr>

            <tr><td>Thanks.</td></tr>
            <tr><td> {{ optional($websites[0])->name }}</td></tr>
    </table>
</body>
</html>