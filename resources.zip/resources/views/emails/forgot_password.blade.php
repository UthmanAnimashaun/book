<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config("app.name") }} - Password Reset Request</title>
    <style type="text/css">
        body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
        img { -ms-interpolation-mode: bicubic; }
        a[x-apple-data-detectors] { color: inherit !important; text-decoration: none !important; font-size: inherit !important; font-family: inherit !important; font-weight: inherit !important; line-height: inherit !important; }

        .container {
            background-color: #1A1F30;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
        }
        .text-light { color: #E0E6F0; }
        .text-accent { color: #00AEEF; }
        .button {
            background-color: #00AEEF;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 174, 239, 0.6);
            transition: all 0.3s ease;
        }
        .button a {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 16px;
            font-weight: bold;
            color: #1A1F30 !important;
            text-decoration: none;
            display: block;
            padding: 15px 25px;
            border-radius: 8px;
        }

        @media only screen and (max-width: 600px) {
            .main-wrapper { width: 100% !important; min-width: 100% !important; }
            .content-padding { padding: 20px !important; }
            .header-logo { padding: 20px 0 !important; }
        }
    </style>
</head>

<body style="margin: 0; padding: 0; background-color: #0A0D15; font-family: Arial, Helvetica, sans-serif;">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width: 100%; table-layout: fixed; background-color: #0A0D15;">
    <tr>
        <td align="center" style="padding: 40px 10px;">
            <table border="0" cellpadding="0" cellspacing="0" width="600" class="main-wrapper" style="width: 600px; min-width: 600px;">
                <tr>
                    <td align="center">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="container" style="background-color: #1A1F30; border-radius: 12px;">
                            <tr>
                                <td align="center" style="padding: 30px 0 20px 0;" class="header-logo">
                                    <h1 style="margin: 0; font-size: 28px; color: #00AEEF; letter-spacing: 2px; text-shadow: 0 0 5px rgba(0, 174, 239, 0.4);">
                                       {{ config("app.name") }}
                                    </h1>
                                </td>
                            </tr>

                            <tr>
                                <td align="center" style="padding: 0 30px 20px 30px;" class="content-padding">
                                    <h2 style="margin: 0; font-size: 26px; font-weight: 700; color: #E0E6F0; line-height: 1.2;">
                                        Password Reset Protocol
                                    </h2>
                                </td>
                            </tr>

                            <tr>
                                <td align="left" style="padding: 0 30px 20px 30px;" class="content-padding">
                                    <p style="margin: 0 0 20px 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                        We received a request to reset your <strong style="color: #00AEEF;">{{ config("app.name") }}</strong> account password.
                                        If you made this request, click the button below to initiate the reset sequence.
                                    </p>
                                </td>
                            </tr>

                            <tr>
                                <td align="center" style="padding: 10px 30px 30px 30px;" class="content-padding">
                                    <table border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td align="center" class="button" style="background-color: #00AEEF; border-radius: 8px;">
                                                <a href="{{ $link }}" target="_blank" style="font-size: 16px; font-weight: bold; color: #1A1F30 !important; text-decoration: none; display: inline-block; padding: 15px 30px; border: 1px solid #00AEEF; border-radius: 8px;">
                                                    RESET PASSWORD
                                                </a>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                  
                            <tr>
                                <td align="left" style="padding: 0 30px 30px 30px; border-top: 1px solid #333C52;" class="content-padding">
                                    <p style="margin: 20px 0 10px 0; font-size: 14px; font-weight: bold; color: #E0E6F0; line-height: 1.6;">
                                        Security Alert:
                                    </p>
                                    <p style="margin: 0; font-size: 14px; color: #58617B; line-height: 1.5;">
                                        If you did not request a password reset, you can safely ignore this message. Your security protocols remain operational.
                                    </p>
                                </td>
                            </tr>

                            <tr>
                                <td align="left" style="padding: 0 30px 30px 30px;" class="content-padding">
                                    <p style="margin: 0; font-size: 16px; color: #B0B5C2;">
                                        Regards,<br>
                                        <strong style="color: #00AEEF;">{{ config("app.name") }} Support Systems</strong>
                                    </p>
                                </td>
                            </tr>
                        </table>

                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td align="center" style="padding: 30px 10px 0 10px;">
                                    <p style="margin: 0; font-size: 12px; color: #58617B; line-height: 1.8;">
                                        &copy; {{ date('Y') }} {{ config("app.name") }} Protocol. All systems reserved.
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>