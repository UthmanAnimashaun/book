<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config("app.name") }} - Order Status Update</title>
    <style type="text/css">
        /* Basic Resets and Font Stack */
        body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
        img { -ms-interpolation-mode: bicubic; }
        a[x-apple-data-detectors] { color: inherit !important; text-decoration: none !important; font-size: inherit !important; font-family: inherit !important; font-weight: inherit !important; line-height: inherit !important; }

        /* General Styles for the futuristic theme */
        .container {
            background-color: #1A1F30; /* Dark inner container */
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5); /* Subtle lift */
        }
        .text-light { color: #E0E6F0; } /* Light text */
        .text-accent { color: #00AEEF; } /* Electric blue accent */
        .button {
            background-color: #00AEEF; /* Electric Blue CTA */
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 174, 239, 0.6); /* Subtle glow effect */
            transition: all 0.3s ease;
        }
        .button a {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 16px;
            font-weight: bold;
            color: #1A1F30 !important; /* Dark text on bright button */
            text-decoration: none;
            display: block;
            padding: 15px 25px;
            border-radius: 8px;
        }
        /* Table styles for readability on dark background */
        .data-table {
            border-collapse: collapse;
            background: #111520; /* Slightly darker than main container for contrast */
            border: 1px solid #333C52;
            border-radius: 6px;
        }
        .data-table th, .data-table td {
            color: #B0B5C2;
            border: 1px solid #333C52;
            padding: 10px;
            /* Added explicit alignment for data cells */
            text-align: left;
        }
        .data-table th {
            background-color: #0A0D15;
            color: #00AEEF;
            font-size: 14px;
            font-weight: bold;
            text-align: left;
        }
        .summary-row {
            background-color: #262D40; /* Darker accent for summary rows */
            color: #E0E6F0 !important;
            font-weight: bold;
        }


        /* Responsive adjustments */
        @media only screen and (max-width: 600px) {
            .main-wrapper {
                width: 100% !important;
            }
            .content-padding {
                padding: 20px !important;
            }
            .header-logo {
                padding: 20px 0 !important;
            }
            /* --- START OF NEW/MODIFIED STYLES FOR TABLE SCROLLING --- */
            .table-container {
                overflow-x: auto !important; /* Forces scroll on small screens */
                -webkit-overflow-scrolling: touch !important; /* Improves iOS scrolling */
            }
            .data-table {
                min-width: 500px !important; /* Ensures table is wider than mobile screen to trigger scroll */
            }
            /* --- END OF NEW/MODIFIED STYLES FOR TABLE SCROLLING --- */
        }
    </style>
</head>

<body style="margin: 0; padding: 0; background-color: #0A0D15; font-family: Arial, Helvetica, sans-serif;">

<table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width: 100%; table-layout: fixed; background-color: #0A0D15;">
    <tr>
        <td align="center" style="padding: 40px 10px;">

            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="main-wrapper" style="max-width: 600px; width: 100%;">
                <tr>
                    <td align="center">

                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="container" style="background-color: #1A1F30; border-radius: 12px;">

                            <tr>
                                <td align="center" style="padding: 30px 0 20px 0;" class="header-logo">
                                    <h1 style="margin: 0; font-size: 28px; color: #00AEEF; letter-spacing: 2px; text-shadow: 0 0 5px rgba(0, 174, 239, 0.4);">
                                        {{ config("app.name") }}
                                    </h1>
                                </td>
                            </tr>

                            <tr>
                                <td align="center" style="padding: 0 30px 20px 30px;" class="content-padding">
                                    <h2 style="margin: 0; font-size: 26px; font-weight: 700; color: #E0E6F0; line-height: 1.2;">
                                        Order Status Update
                                    </h2>
                                </td>
                            </tr>

                            <tr>
                                <td align="left" style="padding: 0 30px 20px 30px;" class="content-padding">
                                    <p style="margin: 0 0 10px 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                        Dear <strong style="color: #E0E6F0;">{{ $name }}</strong>,
                                    </p>
                                    <p style="margin: 0 0 20px 0; font-size: 16px; color: #B0B5C2; line-height: 1.6;">
                                        The status of your order <b>#{{ $order_id ?? 'N/A' }}</b> has been updated to:
                                        <br><span style="font-size: 22px; font-weight: bold; color: #00AEEF; display: block; margin-top: 5px;">{{ $order_status }}</span>
                                    </p>
                                </td>
                            </tr>

                            @if (in_array($order_status, ['Shipped','Delivered','Paid','Partially Delivered']))
                            <tr>
                                <td align="left" style="padding: 0 30px 25px 30px; border-top: 1px solid #333C52;" class="content-padding">
                                    <p style="margin: 20px 0 10px 0; font-size: 16px; font-weight: bold; color: #E0E6F0;">
                                        Delivery Protocol:
                                    </p>
                                    <p style="margin: 0; font-size: 15px; color: #B0B5C2; line-height: 1.6;">
                                        <strong>Courier Name:</strong> <span style="color: #00AEEF;">{{ !empty($courier_name) ? $courier_name : 'Not Provided' }}</span><br>
                                        <strong>Tracking Number:</strong> <span style="color: #00AEEF;">{{ !empty($tracking_number) ? $tracking_number : 'Not Provided' }}</span>
                                    </p>
                                </td>
                            </tr>
                            @endif

                            <tr>
                                <td align="left" style="padding: 0 30px 10px 30px;" class="content-padding">
                                    <p style="margin: 0; font-size: 16px; font-weight: bold; color: #E0E6F0;">
                                        Order Manifest ({{ $order_id ?? 'N/A' }})
                                    </p>
                                </td>
                            </tr>

                            <tr>
                                <td style="padding: 0 0 30px 0;">
                                    <div class="table-container" style="padding: 0 30px;">
                                    <table width="100%" cellpadding="8" cellspacing="0" class="data-table" style="border-collapse: collapse; background: #111520; border: 1px solid #333C52; border-radius: 6px;">

                                        <thead>
                                            <tr>
                                                <th width="38%" style="background-color: #0A0D15; color: #00AEEF;">Product Name</th>
                                                <th width="18%" style="background-color: #0A0D15; color: #00AEEF;">Format</th>
                                                <th width="18%" style="background-color: #0A0D15; color: #00AEEF;">Price</th>
                                                <th width="13%" style="background-color: #0A0D15; color: #00AEEF;">Qty</th>
                                                <th width="13%" style="background-color: #0A0D15; color: #00AEEF;">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($orderDetails['orders_products'] as $order)
                                            <tr>
                                                <td style="color: #B0B5C2;">{{ $order['product_name'] }}</td>
                                                <td style="color: #B0B5C2;">{{ $order['product_format'] }}</td>
                                                <td style="color: #00AEEF;">₦{{ number_format($order['product_price']) }}</td>
                                                <td style="color: #B0B5C2; text-align: center;">{{ $order['product_qty'] }}</td>
                                                <td style="color: #B0B5C2; text-align: center;">{{ $order['item_status'] ?? 'N/A' }}</td>
                                            </tr>
                                            @endforeach


                                        <tr class="summary-row">
                                            <td colspan="4" align="right" style="text-align: right; background-color: #262D40; color: #E0E6F0; font-weight: bold;">Shipping Charges:</td>
                                            <td style="background-color: #262D40; color: #00AEEF; font-weight: bold; text-align: right;">₦{{ number_format($orderDetails['shipping_charges']) }}</td>
                                        </tr>

                                        <tr class="summary-row">
                                            <td colspan="4" align="right" style="text-align: right; background-color: #00AEEF; color: #1A1F30; font-weight: bold;">Grand Total:</td>
                                            <td style="background-color: #00AEEF; color: #1A1F30; font-weight: bold; text-align: right;">₦{{ number_format($orderDetails['grand_total']) }}</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    </div>
                                    </td>
                            </tr>

                            <tr>
                                <td align="left" style="padding: 0 30px 10px 30px;" class="content-padding">
                                    <p style="margin: 0; font-size: 16px; font-weight: bold; color: #E0E6F0;">
                                        Delivery Target Coordinates:
                                    </p>
                                </td>
                            </tr>

                            <tr>
                                <td align="left" style="padding: 0 30px 30px 30px;" class="content-padding">
                                    <p style="margin: 0; font-size: 15px; color: #B0B5C2; line-height: 1.6; padding-left: 10px; border-left: 2px solid #00AEEF;">
                                        <strong style="color: #E0E6F0;">Recipient:</strong> {{ $orderDetails['name'] }}<br>
                                        <strong style="color: #E0E6F0;">Contact:</strong> {{ $orderDetails['mobile'] }} / {{ $orderDetails['email'] }}<br><br>

                                        <strong style="color: #E0E6F0;">Address:</strong><br>
                                        {{ $orderDetails['address'] }}<br>
                                        {{ $orderDetails['city'] }}, {{ $orderDetails['state'] }} - {{ $orderDetails['pincode'] }}<br>
                                        {{ $orderDetails['country'] }}
                                    </p>
                                </td>
                            </tr>

                            <tr>
                                <td align="left" style="padding: 0 30px 30px 30px; border-top: 1px solid #333C52;" class="content-padding">
                                    <p style="margin: 20px 0 10px 0; font-size: 15px; color: #B0B5C2; line-height: 1.6;">
                                        Thank you for entrusting the deployment to <b>{{ config("app.name") }}</b>! For any protocol deviation or query, contact our support systems at:
                                    </p>
                                    <p style="margin: 0; font-size: 15px;">
                                        <a href="mailto:{{ config("app.email") }}" style="color: #00AEEF; text-decoration: none;">
                                            {{ config("app.email") }}
                                        </a>
                                    </p>
                                    <p style="margin: 20px 0 0 0; font-size: 15px; color: #B0B5C2; line-height: 1.6;">
                                        Best regards,<br>
                                        <strong style="color: #00AEEF;">{{ config("app.name") }} Logistics Hub</strong>
                                    </p>
                                </td>
                            </tr>

                        </table>
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td align="center" style="padding: 30px 10px 0 10px;">
                                    <p style="margin: 0; font-size: 12px; color: #58617B; line-height: 1.8;">
                                        &copy; 2026 {{ config("app.name") }} Protocol. All systems reserved.
                                    </p>
                                </td>
                            </tr>
                        </table>
                        </td>
                </tr>
            </table>
            </td>
    </tr>
</table>
</body>
</html>
