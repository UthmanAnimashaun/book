<?php

use Livewire\Volt\Component;
use Livewire\WithPagination;
use App\Models\Product;
use App\Models\Category;
use App\Models\Admin;
use App\Models\Section;
use App\Models\Subscriber; // Make sure your model namespace matches this
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
    #[Title('Book Buffet | Buy & Sell Books Online in Nigeria')]
class extends Component {
    use WithPagination;
    protected string $paginationTheme = 'tailwind';

    // State for newsletter tracking
    public string $subscriber_email = '';

    public function mount(): void
    {
        Session::put('page', 'Index');
        // Handle one-time system notification flash tracking
        if (!session()->has('has_seen_notification')) {
            session()->flash('show_notification', true);
            session()->put('has_seen_notification', true);
        }
    }

    /**
     * Handles newsletter subscription logic
     */
    public function subscribe(): void
    {
        $this->validate([
            'subscriber_email' => 'required|email|unique:subscribers,email',
        ], [
            'subscriber_email.required' => 'Please provide an email address.',
            'subscriber_email.email' => 'This email address is invalid.',
            'subscriber_email.unique' => 'This email is already subscribed to our newsletter!',
        ]);

        try {
            // Persist subscriber entry to database
            Subscriber::create([
                'email' => $this->subscriber_email
            ]);

            // Clear input context
            $this->reset('subscriber_email');

            // Dispatch toast data event payload down to script interceptor
            $this->dispatch('toast', [
                'title' => 'Subscription Successful!',
                'message' => 'Thank you for subscribing!.',
                'type' => 'success'
            ]);
        } catch (\Exception $e) {
            $this->dispatch('toast', [
                'title' => 'Error',
                'message' => 'Something went wrong. Please try again later.',
                'type' => 'error'
            ]);
        }
    }

    /**
     * Streams operational data properties down into the template viewport context
     */
    public function with(): array
    {
        return [
            'products' => Product::with(['section', 'Category', 'ratings', 'images'])
                ->where('status', 1)
                ->inRandomOrder()
                ->take(5)
                ->get(),

            'categories' => Category::where('status', 1)
                ->whereHas('products')
                ->take(6)
                ->orderBy('id', 'desc')
                ->get(),

            'vendors' => Admin::with('products')
                ->orderBy('name')
                ->paginate(12),

            // Metrics for the new marketplace summary addition
            'total_books' => Product::where('status', 1)->count(),
            'total_vendors' => Admin::count(),

            'testimonials' => [
                [
                    'stars' => 5,
                    'text'  => 'The book selection is incredible, and the checkout process was seamless. Perfect for real book lovers!',
                    'name'  => 'Jane Doe',
                ],
                [
                    'stars' => 4,
                    'text'  => 'Fast delivery and the books arrived in perfect condition. I am really impressed.',
                    'name'  => 'Michael Ogunleye',
                ],
                [
                    'stars' => 5,
                    'text'  => 'Amazing quality and excellent customer support. I will definitely order again!',
                    'name'  => 'Aisha Bello',
                ],
                [
                    'stars' => 3,
                    'text'  => 'Good service, but delivery took a little longer than expected.',
                    'name'  => 'Samuel Okoro',
                ],
                [
                    'stars' => 4,
                    'text'  => 'Nice packaging and genuine books. Worth every naira spent.',
                    'name'  => 'Fatimah Yusuf',
                ],
            ]
        ];
    }
}; ?>

<div>
    {{-- ASSIGN DYNAMIC SEO METRICS IN-COMPONENT --}}
    @section('meta_tags')
        <meta name="robots" content="index, follow" />
        <meta name="title" content="{{ optional($websites[0])->name }}" />
        <meta name="description" content="{{ optional($websites[0])->website_description }}" />
        <meta name="author" content="{{ optional($websites[0])->name }}" />
        <link class="canonical" href="{{ Request::root() }}" />
        <meta name="keywords" content="books, online bookstore, buy books online, {{ optional($websites[0])->name }}">
        <meta property="og:site_name" content="{{ optional($websites[0])->name }}">
        <meta property="og:title" content="{{ optional($websites[0])->name }}" />
        <meta property="og:type" content="website" />
        <meta property="og:description" content="{{ optional($websites[0])->website_description }}" />
        <meta property="og:url" content="{{ Request::root() }}" />
        <meta property="og:image" content="{{ url(optional($websites[0])->logo) }}" />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:domain" content="{{ Request::root() }}" />
        <meta name="twitter:title" content="{{ optional($websites[0])->name }}" />
        <meta name="twitter:description" content="{{ optional($websites[0])->website_description }}" />
        <meta name="twitter:image" content="{{ url(optional($websites[0])->logo) }}" />
    @endsection

    {{-- MAIN DISPLAY INTERFACE LAYER --}}
    <div class="mt-k5">
        <main class="max-w-7xl mx-auto">

            {{-- HERO BANNER ENTRY BLOCK --}}
            <section class="relative h-96 sm:h-[400px] bg-blue-900/90 bg-cover bg-center overflow-hidden"
                style="background-image: linear-gradient(rgba(30, 58, 138, 0.7), rgba(30, 58, 138, 0.7)), url('https://images.unsplash.com/photo-1521587765099-b586d623ce75?fit=crop&w=1400&q=80');">
                <div class="absolute inset-0 flex flex-col justify-center items-center text-center px-4">
                    <h1 class="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white mb-6 leading-tight tracking-tight">
                        Discover, Read, and Own Your Favorite Books
                    </h1>
                    <p class="text-xl text-gray-200 mb-8 font-medium max-w-xl">
                        The ultimate marketplace for every genre, author, and publisher.
                    </p>
                    <a href="{{ route('product-shop') }}"
                        class="bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition duration-300 transform hover:scale-105">
                        Shop Now
                    </a>
                </div>
            </section>

            <hr class="my-12 border-gray-300">

            {{-- CATEGORIES SELECTION GRID --}}
            <section class="px-4 sm:px-6 lg:px-8 mb-16">
                <h2 class="text-3xl font-bold text-center mb-8">Explore Our Top Categories</h2>
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
                    @foreach ($categories as $category)
                    {{-- Updated mapping to standard web shop URI utilizing query arrays --}}
                    <a href="{{ route('product-shop', ['category' => $category->id]) }}" class="group block p-4 text-center rounded-xl bg-white shadow-lg border border-gray-200 card-hover transition duration-200 hover:-translate-y-1">
                        <span class="text-md font-medium mt-2 text-blue-900 group-hover:text-amber-600">{{ $category->category_name }}</span>
                    </a>
                    @endforeach
                </div>
            </section>

            <hr class="my-12 border-gray-300">

            {{-- DYNAMIC FEATURED PRODUCTS SHELF --}}
            <section class="px-4 sm:px-6 lg:px-8 mb-16">
                <h2 class="text-3xl font-bold text-center mb-10">Top Picks for You 📚</h2>
                <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                    @foreach ($products as $product)
                        @php
                            $product_image = $product->image_url
                                ? '/storage/images/product_image/small/'.$product->image_url
                                : '/storage/images/product_image/medium/default.jpg';
                            $link = url('product/'.$product->slug);
                            $discount = \App\Models\Product::getDiscountPrice($product->id);
                            $isSold = $product->stock == 0;
                        @endphp
                        <div wire:key="home-product-{{ $product->id }}" class="bg-white rounded-xl shadow-md sm:shadow-lg hover:shadow-xl p-3 sm:p-4 text-center transition border border-gray-100">
                            <div class="relative w-full h-40 sm:h-56 bg-gray-100 overflow-hidden rounded-lg mb-3 mx-auto">
                                <img src="{{ asset($product_image) }}" alt="Book Cover" class="w-full h-full object-cover">
                                @if($product->stock > 0)
                                    @if($discount)
                                        <span class="absolute top-2 right-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded-full shadow-md">
                                            {{ $product->discount }}% OFF
                                        </span>
                                    @endif
                                @else
                                    <span class="absolute top-2 right-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded-full shadow-md">
                                        Out of stock
                                    </span>
                                @endif
                            </div>

                            <div class="p-4">
                                <h4 class="font-semibold text-blue-900 truncate text-sm sm:text-base mb-1">{{ $product->title }}</h4>
                                <p class="text-xs sm:text-sm text-gray-500 mb-2">BY: {{ $product->author }}</p>

                                <div class="flex justify-center text-amber-600 text-[10px] sm:text-xs mb-2">
                                    @php
                                        $avgRating = $product->ratings->avg('rating') ?? 0;
                                    @endphp
                                    @for ($i = 1; $i <= 5; $i++)
                                        @if ($avgRating >= $i)
                                            <i class="fas fa-star"></i>
                                        @elseif ($avgRating >= ($i - 0.5))
                                            <i class="fas fa-star-half-alt"></i>
                                        @else
                                            <i class="far fa-star"></i>
                                        @endif
                                    @endfor
                                </div>

                                <span class="font-bold text-base sm:text-lg text-amber-600 mb-3">
                                    ₦{{ number_format($product->price - ($product->price * $product->discount / 100)) }}
                                </span>

                                @if ($product->discount)
                                    <span class="text-sm sm:text-lg text-gray-400 line-through ml-3">
                                       ₦{{ number_format($product->price, 2) }}
                                    </span>
                                @endif

                                <div class="flex flex-col text-base sm:text-lg space-y-2 mt-3">
                                    <a href="{{ $link }}" class="w-full text-center border border-blue-900 text-blue-900 hover:text-amber-600 hover:border-amber-600 text-sm font-medium py-2 rounded-lg transition duration-150">
                                         View Details
                                    </a>
                                </div>
                            </div>
                        </div>

                        {{-- DYNAMIC INLINE ASSIGNED SCHEMA FOR SRAWLERS --}}
                        <script type="application/ld+json">
                            {!! json_encode([
                                '@context' => 'https://schema.org',
                                '@type' => 'Product',
                                'name' => $product->title,
                                'image' => url('/storage/images/product_image/' . $product->image_url),
                                'description' => $product->description,
                                'sku' => $product->id,
                                'brand' => [
                                    '@type' => 'Brand',
                                    'name' => optional($websites[0])->name,
                                ],
                                'offers' => [
                                    '@type' => 'Offer',
                                    'url' => route('product.detail', $product->slug),
                                    'priceCurrency' => 'NGN',
                                    'price' => $product->price,
                                    'availability' => 'http://schema.org/InStock',
                                ],
                            ], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT) !!}
                        </script>
                    @endforeach
                </div>

                <div class="text-center mt-10">
                    <a href="/shop" class="text-base sm:text-lg font-medium text-amber-600 hover:text-blue-900 border-b-2 border-amber-600 hover:border-blue-900 transition duration-150">
                        View All Books &rarr;
                    </a>
                </div>
            </section>

            <hr class="my-12 border-gray-300">

            {{-- RE-ACTIVE VENDORS SECTIONS FEED WITH AJAX PAGINATION --}}
            <section class="px-4 sm:px-6 lg:px-8 mb-16">
                <h2 class="text-3xl font-bold text-center mb-10">Trusted Vendors & Publishers 🤝</h2>

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    @forelse ($vendors as $vendor)
                        <div wire:key="home-vendor-{{ $vendor->id }}" class="vendor-card bg-white rounded-2xl shadow-lg p-5 flex flex-col items-center text-center transition duration-300 hover:-translate-y-1 hover:shadow-xl border-t-4 border-amber-600/50">
                             @php
                                $admin_image = $vendor->image
                                    ? '/storage/images/admin_photos/'.$vendor->image
                                    : '/storage/images/profile.jpg';
                            @endphp
                            <img src="{{ $admin_image }}" alt="Vendor Logo" class="w-20 h-20 rounded-full object-cover mb-4 border-2 border-gray-100 shadow-inner">

                            <a href="{{ url('/vendor/' . $vendor->slug) }}" class="text-xl font-serif font-bold text-maroon hover:text-amber-600 transition mb-1">
                                 {{ $vendor->name }}
                            </a>

                            <p class="text-sm text-gray-600 italic mb-3">{{ $vendor->tagline }}</p>

                            <div class="w-full text-left space-y-1 text-sm mb-4 border-t pt-3">
                                <p class="text-gray-600">
                                    <i class="fas fa-map-marker-alt w-4 mr-2 text-amber-600"></i>
                                    Location: <span class="font-semibold">{{ $vendor->state }}</span>
                                </p>
                                <p class="text-gray-600">
                                    <i class="fas fa-book-open w-4 mr-2 text-amber-600"></i>
                                    Books Listed: <span class="font-semibold">{{ count($vendor->products) ?? 0 }}</span>
                                </p>
                            </div>

                            <a href="{{ url('/vendor/' . $vendor->slug) }}" class="w-full bg-amber-600 hover:bg-maroon-700 text-white px-4 py-2 rounded-full text-sm font-semibold transition duration-200">
                                <i class="fas fa-store mr-2"></i> Visit Shop
                            </a>
                        </div>
                    @empty
                        <div class="col-span-full bg-white p-10 rounded-xl shadow-md text-center w-full">
                            <i class="fas fa-box-open text-6xl text-gray-300 mb-4"></i>
                            <h2 class="text-2xl font-semibold text-gray-700 mb-2">No Vendors Found</h2>
                            <p class="text-gray-500">No vendors found for your search. Try a different keyword or filter.</p>
                        </div>
                    @endforelse
                </div>

                {{-- RE-ACTIVE TAILWIND PAGINATION LINKS --}}
                @if ($vendors->hasPages())
                    <div class="mt-10 flex justify-center modern-pagination">
                        {{ $vendors->links() }}
                    </div>
                @endif
            </section>

            <hr class="my-12 border-gray-300">

            {{-- MARKETPLACE SUMMARY & TESTIMONIALS --}}
            {{-- REMOVED FONTAWESOME DEPENDENCIES IN FAVOR OF UNIVERSAL EMOJIS --}}
            <section class="px-4 sm:px-6 lg:px-8 mb-16 text-center">
                <h2 class="text-3xl font-bold mb-4 text-blue-900">Why Choose Book Buffet?</h2>
                <p class="text-gray-600 max-w-xl mx-auto mb-10 text-sm sm:text-base">Nigeria’s premier multi-vendor book ecosystem connecting bookworms with reliable publishers nationwide.</p>

                <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div class="p-6 bg-white border border-gray-100 rounded-2xl shadow-sm hover:shadow-md transition">
                        <div class="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                            🛡️
                        </div>
                        <h3 class="font-bold text-blue-900 mb-2">Secure Escrow</h3>
                        <p class="text-gray-500 text-xs sm:text-sm">Your multi-vendor payments are securely processed and protected throughout transaction lifecycles.</p>
                    </div>

                    <div class="p-6 bg-white border border-gray-100 rounded-2xl shadow-sm hover:shadow-md transition">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                            🚚
                        </div>
                        <h3 class="font-bold text-blue-900 mb-2">Nationwide Logistics</h3>
                        <p class="text-gray-500 text-xs sm:text-sm">Seamless shipping integrations deliver direct from vendor storefronts to your door anywhere in Nigeria.</p>
                    </div>

                    <div class="p-6 bg-white border border-gray-100 rounded-2xl shadow-sm hover:shadow-md transition">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                            📚
                        </div>
                        <h3 class="font-bold text-blue-900 mb-2">{{ number_format($total_books) }}+ Books Listed</h3>
                        <p class="text-gray-500 text-xs sm:text-sm">Unrestricted access to unique selections encompassing local academic volumes, rare finds, and international bestsellers.</p>
                    </div>

                    <div class="p-6 bg-white border border-gray-100 rounded-2xl shadow-sm hover:shadow-md transition">
                        <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                            💼
                        </div>
                        <h3 class="font-bold text-blue-900 mb-2">{{ $total_vendors }}+ Publishers</h3>
                        <p class="text-gray-500 text-xs sm:text-sm">Empowering independent African authors and elite retail publishers within a centralized network ecosystem.</p>
                    </div>
                </div>
            </section>

            <hr class="my-12 border-gray-300">

            {{-- READERS TESTIMONIALS SLIDER SECTION --}}
            <section class="px-4 sm:px-6 lg:px-8 mb-16 bg-blue-900/5 py-12 rounded-xl">
                <h2 class="text-3xl font-bold text-center mb-10 text-blue-900">What Our Readers Say ⭐️</h2>
                <div class="grid md:grid-cols-3 gap-8">
                    @foreach ($testimonials as $index => $t)
                        <div wire:key="testimonial-{{ $index }}" class="bg-white p-6 rounded-3xl shadow-xl border border-gray-200">
                            <div class="flex justify-center text-amber-500 mb-4">
                                 @for ($i = 1; $i <= $t['stars']; $i++)
                                    <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24">
                                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                                    </svg>
                                @endfor
                            </div>

                            <p class="text-gray-700 italic mb-4 text-center">
                                "{{ $t['text'] }}"
                            </p>

                            <div class="flex items-center justify-center space-x-3">
                                <div class="w-10 h-10 rounded-full bg-gray-200"></div>
                                <span class="font-semibold text-blue-900">{{ $t['name'] }}</span>
                            </div>
                        </div>
                    @endforeach
                </div>
            </section>

            <hr class="my-12 border-gray-300">

            {{-- MARKETING CAPTION NEWSLETTER SUBSCRIPTION --}}
            <section class="px-4 sm:px-6 lg:px-8 mb-16">
                <div class="p-6 md:p-12 rounded-2xl bg-blue-900 shadow-2xl text-center">
                    <h2 class="text-2xl sm:text-3xl font-bold text-white mb-4">Get Exclusive Book Deals!</h2>
                    <p class="text-base sm:text-lg text-gray-300 mb-8">
                        Subscribe to our newsletter for 10% off your first purchase and weekly updates.
                    </p>

                    {{-- Wired up to live reactive state method execution context --}}
                    <form wire:submit="subscribe" class="max-w-md mx-auto flex flex-col sm:flex-row gap-3">
                        <div class="w-full sm:flex-grow flex flex-col text-left">
                            <input type="email" wire:model="subscriber_email" placeholder="Enter your email address" class="w-full py-3 px-6 rounded-lg border-2 border-gray-300 focus:outline-none focus:ring-2 focus:ring-amber-600 transition duration-150 text-blue-900" required>
                            @error('subscriber_email') <span class="text-red-400 text-xs mt-1 font-medium">{{ $message }}</span> @enderror
                        </div>
                        <button type="submit" class="w-full sm:w-auto h-[52px] whitespace-nowrap bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-8 rounded-lg transition duration-150 shadow-md">
                            {{-- Wire loading optimization indicator display toggles --}}
                            <span wire:loading.remove wire:target="subscribe">Subscribe</span>
                            <span wire:loading wire:target="subscribe"><i class="fas fa-spinner fa-spin mr-2"></i>Processing...</span>
                        </button>
                    </form>
                </div>
            </section>

        </main>
    </div>

    @push('css')
        <style>
            #random-image { transition: opacity 0.5s ease-in-out; }
            .hidden { opacity: 1; }
            .modern-pagination nav { display: inline-flex; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-radius: 0.375rem; }
        </style>
    @endpush

    @script
    <script>
        // Butterup toast listener
        $wire.on('toast', ([data]) => {
            if(typeof butterup !== 'undefined') {
                butterup.toast({
                    title: data.title,
                    message: data.message,
                    type: data.type,
                    location: 'top-right',
                    icon: true
                });
            } else {
                alert(data.message); // Fallback if script dependency hasn't mounted globally
            }
        });
    </script>
    @endscript
</div>
