<?php

use Livewire\Volt\Component;
use App\Models\Cart;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use App\Models\Section;
use App\Models\Product;

new class extends Component {

    protected $listeners = ['cartUpdated' =>'updateCartDetails'];
    public $cartItems = [];
    public $getCartItems = 0;

    public function mount(){
        $sections = Section::sections();
        $totalCartItems = totalCartItems();
        $this->updateCartDetails();
    }

    public function updateCartDetails(){
        $this->getCartItems = Cart::getCartItems();
        // Assumes you have a custom `getCartItems()` method in Cart model
    }
};
?>

<div>

<div x-data="{
        mobileMenuOpen: false,
        cartOpen: false,
        cartItemCount: @entangle('cartItemCount'),
        cartTotalPrice: @entangle('cartTotalPrice')
    }" x-init="$watch('cartOpen', value => {
        document.body.style.overflow = value ? 'hidden' : 'auto'
    })">

    <header class="fixed inset-x-0 top-0 z-50 bg-white border-b border-gray-100 shadow-md">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

             <div class="flex items-center justify-between h-14 sm:h-16">

                <a href="/" class="flex items-center space-x-2 text-2xl font-bold text-blue-900">
                    <img class="w-10 h-10" src="/storage/images/logo/{{ optional($websites[0])->logo }}"
                        alt="{{ config('app.name') }} Logo">
                </a>

                <nav class="flex items-center space-x-4 lg:space-x-8 text-lg font-medium">

                    <div class="hidden md:flex items-center space-x-3 lg:space-x-6">
                        <a href="/" class="text-blue-900 hover:text-amber-600 transition">🏠 Home</a>
                        <a href="{{ route('product-shop') }}" class="text-blue-900 hover:text-amber-600 transition">🛍️ Shop</a>
                        <a href="{{ route('about') }}" class="text-blue-900 hover:text-amber-600 transition">📖 About</a>
                        <a href="{{ route('contact') }}" class="text-blue-900 hover:text-amber-600 transition">📞 Contact</a>
                    </div>

                         @if (Auth::check())

                          <div class="relative" x-data="{ open: false }" @click.away="open = false">
                             <button @click="open = !open" class="flex items-center text-blue-900 hover:text-amber-600 transition focus:outline-none">
                                 👤 Profile

                              <svg class="ml-1 w-4 h-4 transition-transform" :class="{'rotate-180': open}"
                                     fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                   <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                           d="M19 9l-7 7-7-7"></path>
                                 </svg>
                             </button>
                             <div
                                 x-cloak x-show="open"
                                 x-transition:enter="transition ease-out duration-200"
                                 x-transition:enter-start="opacity-0 scale-95"
                                 x-transition:enter-end="opacity-100 scale-100"
                                 x-transition:leave="transition ease-in duration-150"
                                 x-transition:leave-start="opacity-100 scale-100"
                                 x-transition:leave-end="opacity-0 scale-95"
                                 class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 z-10">

                                 <a href="{{ route('checkout') }}" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">💳 Checkout</a>
                                 <a href="{{ route('user.orders') }}" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">📦 My Orders</a>
                                 <a href="{{ route('user.account') }}" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">👤 My Account</a>

{{-- Reactive Front-End Customer Notification Bell --}}
        <livewire:front.components.notification-bell />


                                 <a href="{{ route('user.logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="block px-4 py-2 text-sm hover:bg-gray-100 text-red-600 border-t">🚪 Logout</a>
                                  <form id="logout-form" action="{{ route('user.logout') }}" method="POST" class="hidden">@csrf</form>
                               </div>
                         </div>
                         @endif

                        {{-- More Dropdown --}}
                        <div x-data="{ open: false }" @click.outside="open = false" class="relative">
                        <button @click="open = !open" class="flex items-center text-blue-900 hover:text-amber-600 transition focus:outline-none">
                            ➕ More

                            <svg class="ml-1 w-4 h-4 transition-transform" :class="{'rotate-180': open}"
                            fill="none" stroke="currentColor" viewBox="0 0 24 24">
                               <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </button>

                        <div x-cloak x-show="open"
                            x-transition:enter="transition ease-out duration-200"
                            x-transition:enter-start="opacity-0 scale-95"
                            x-transition:enter-end="opacity-100 scale-100"
                            x-transition:leave="transition ease-in duration-150"
                            x-transition:leave-start="opacity-100 scale-100"
                            x-transition:leave-end="opacity-0 scale-95"
                            class="absolute right-0 mt-3 w-48 rounded-lg shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-20 origin-top-right">

                            <div class="py-1">
                                <a href="{{ route('faq') }}" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">❓ FAQ</a>
                                <a href="{{ route('tc') }}" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">📜 Terms &amp; Condition</a>
                                <a href="{{ route('pp') }}" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">🔒 Privacy Policy</a>
                                <a href="{{ route('cart') }}" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">🛒 Cart</a>

                                @if (!Auth::check())
                                    <a href="{{ route('user.login') }}" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">🔑 Login/Register</a>
                                @endif
                            </div>
                        </div>
                    </div>

                     <button @click="cartOpen = !cartOpen" class="relative p-2 text-gray-600 hover:text-blue-600">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M3 3h2l.4 2M7 13h10l4-8H5.4M7
                                   13L5.4 5M7 13l-2.293 2.293c-.63.63-.184
                                  1.707.707 1.707H17m0 0a2 2 0
                                  100 4 2 2 0 000-4zm-8
                                  2a2 2 0
                                  11-4 0 2 2 0 014 0z"></path>
                        </svg>
                        <span class="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-0.5 text-xs font-bold bg-red-600 text-white rounded-full transform translate-x-1/2 -translate-y-1/2">
                            @livewire('front.carts.cart-badge')
                        </span>
                    </button>

                    @if (!Auth::check())
                    <div class="hidden lg:block">
                        <a href="{{ route('user.login') }}"
                            class="text-white bg-blue-900 hover:bg-amber-600 px-4 py-2 rounded-lg font-medium transition duration-150">🔐 Sign In</a>
                    </div>
                    @endif

                     <div class="md:hidden flex items-center ml-2">
                        <button @click="mobileMenuOpen = !mobileMenuOpen"
                            class="text-gray-600 hover:text-blue-600 focus:outline-none">
                            <svg x-cloak x-show="!mobileMenuOpen" class="h-6 w-6" fill="none" stroke="currentColor"
                                 viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round"
                                 stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
                            <svg x-cloak x-show="mobileMenuOpen" class="h-6 w-6" fill="none" stroke="currentColor"
                                 viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round"
                                 stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                        </button>
                    </div>
                </nav>
            </div>
        </div>

        <div x-cloak x-show="mobileMenuOpen"
            x-transition:enter="transition ease-out duration-200"
            x-transition:enter-start="opacity-0 scale-95"
            x-transition:enter-end="opacity-100 scale-100"
            x-transition:leave="transition ease-in duration-150"
            x-transition:leave-start="opacity-100 scale-100"
            x-transition:leave-end="opacity-0 scale-95"
            class="md:hidden border-t border-gray-100">
            <div class="px-4 py-3 space-y-2">
                <a href="/" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">🏠 Home</a>
                <a href="{{ route('product-shop') }}" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">🛍️ Shop</a>
                <a href="{{ route('about') }}" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">📖 About</a>
                <a href="{{ route('contact') }}" class="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-amber-600">📞 Contact</a>
            </div>
        </div>
    </header>

    <div class="pt-14 sm:pt-16">
        <div x-cloak x-show="cartOpen" class="fixed inset-0 z-50">
            <div @click="cartOpen = false" class="absolute inset-0 bg-gray-600 bg-opacity-75"></div>

            <div x-cloak x-show="cartOpen"
                 x-transition:enter="transition ease-in-out duration-300 transform"
                 x-transition:enter-start="translate-x-full"
                 x-transition:enter-end="translate-x-0"
                 x-transition:leave="transition ease-in-out duration-300 transform"
                 x-transition:leave-start="translate-x-0"
                 x-transition:leave-end="translate-x-full"
                 class="absolute right-0 top-0 bottom-0 w-11/12 max-w-sm sm:w-80 bg-white shadow-xl flex flex-col">

                 <div class="p-4 border-b flex justify-between items-center">
                    <h2 class="font-semibold text-lg text-gray-800">Your Cart 🛒</h2>
                    <button @click="cartOpen = false" class="text-gray-500 hover:text-gray-700">
                        <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>

                <div class="flex-1 overflow-y-auto p-4">
                    @php
                        $totalPrice = 0;
                    @endphp
                    @foreach ($getCartItems as $item)
                    <li class="py-3 border-b border-gray-100 last:border-none list-none">
                        <span class="flex items-start gap-3 hover:bg-gray-50 p-2 rounded-xl transition">
                            {{-- Product Image --}}
                            <img
                                src="/storage/images/product_image/small/{{ $item['product']['image_url'] }}"
                                alt="Product"
                                class="w-16 h-16 object-cover rounded-lg shadow-sm border"
                            >

                            <div class="flex flex-col flex-1">
                                {{-- Title + Format --}}
                                <div>
                                    <p class="font-medium text-gray-800 leading-tight">
                                         {{ $item['product']['title'] }}
                                    </p>
                                    <p class="text-xs text-gray-500 mt-0.5">
                                        <span class="font-semibold text-gray-700">Format:</span>
                                         {{ $item['product']['format'] }}
                                    </p>
                                </div>

                                {{-- Price + Quantity --}}
                                @php
                                    $getDiscountPrice = Product::getDiscountPrice($item['product_id']);
                                @endphp
                                <div class="flex items-center justify-between mt-2">
                                    <span class="text-gray-900 font-semibold text-sm">
                                        <span class="line-through text-gray-500">N</span>
                                         {{  number_format($getDiscountPrice['final_price'], 2) }}
                                    </span>

                                    <span class="text-gray-600 text-sm">
                                        × {{ $item['quantity'] }}
                                    </span>
                                </div>
                            </div>
                        </span>
                    </li>

                    @php
                        $totalPrice += $getDiscountPrice['final_price'] * $item['quantity'];
                    @endphp
                    @endforeach
                </div>

                <div class="border-t p-4">
                    <div class="flex justify-between font-semibold text-gray-800">
                        <span>Subtotal:</span>
                        <span> ₦<span>{{ number_format($totalPrice, 2) }}</span></span>
                    </div>
                    <button class="mt-4 w-full bg-amber-600 hover:bg-amber-700 text-white py-2 rounded-md font-medium">
                        <a href="{{ route('cart') }}" class="cart-anchor block w-full text-center">View Cart 🛒</a>
                    </button>
                    @if (Auth::check())
                   <button class="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-md font-medium">
                        <a href="{{ route('checkout') }}" class="cart-anchor block w-full text-center">Checkout 💳</a>
                    </button>
                    @endif
                </div>
            </div>
       </div>
    </div> </div>

</div>
