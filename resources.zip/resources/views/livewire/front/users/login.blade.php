<?php

use Livewire\Volt\Component;
use Illuminate\Support\Facades\Auth;

use App\Models\User;

use Livewire\Attributes\Validate;

use Illuminate\Support\Facades\Hash;


use Illuminate\Support\Facades\Session; // Added missing import
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use App\Models\Cart; // Ensure your Cart model is imported

new #[Layout('layouts.front.app')]
#[Title('Login | Book Buffet')]
 class extends Component {

    public $email = '';
    public $password = '';
    public $remember = false;

    protected $rules = [
        'email' => 'required|email',
        'password' => 'required',
    ];



    public function login()
    {
        $this->validate();

        // 1. Attempt authentication FIRST
        if (Auth::attempt(['email' => $this->email, 'password' => $this->password], $this->remember)) {

            // 2. NOW you can safely check Auth::user() status
            if (Auth::user()->status == 0) {
                Auth::logout();

                $this->dispatch('toast', [
                    'title' => 'Account Inactive',
                    'message' => 'Your account is not activated, pls check your email account for confirmation',
                    'type' => 'error'
                ]);
                return;
            }

            // 3. Merge cart if session exists
            if (Session::has('session_id')) {
                $user_id = Auth::user()->id;
                $session_id = Session::get('session_id');
                Cart::where('session_id', $session_id)->update(['user_id' => $user_id]);
            }

            session()->regenerate();

            $this->dispatch('toast', [
                'title' => 'Welcome Back!',
                'message' => 'Login successful. Redirecting...',
                'type' => 'success'
            ]);

            //return redirect()->intended(route('index'));
            return redirect()->intended(route('index'));
        }

        // If Auth::attempt fails
        $this->dispatch('toast', [
            'title' => 'Login Failed',
            'message' => 'The provided credentials do not match our records.',
            'type' => 'error'
        ]);

        throw ValidationException::withMessages([
            'email' => __('auth.failed'),
        ]);
    }
}; ?>

<div class="w-full max-w-lg p-6">

    <div class="text-center mb-8">
        <h1 class="text-4xl font-extrabold text-blue-900">BookBuffet</h1>
        <p class="text-sm text-amber-600 mt-1">Where Readers Meet Knowledge</p>
    </div>
    <div class="flex flex-col md:flex-row gap-6">
        <div class="bg-white flex-1 rounded-2xl shadow-xl p-8 border border-gray-100">

            <h2 class="text-3xl font-bold text-gray-800 mb-2">Login</h2>
            <p class="text-gray-600 mb-6">Welcome back! Sign in to your account.</p>

            <form wire:submit="login" class="space-y-5">
                <div>
                    <input type="email" wire:model="email" placeholder="Email Address"
                        class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-amber-600 focus:outline-none transition">
                    @error('email') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                </div>

                <div class="relative">
                    <input type="password" wire:model="password" placeholder="Password" id="user-password"
                        class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-amber-600 focus:outline-none transition">

                    <button type="button" onclick="togglePasswordVisibility('user-password')" class="absolute right-3 top-3.5 text-gray-400 hover:text-gray-600">
                        <span id="toggle-password-icon-user-password">👁️</span>
                    </button>

                    @error('password') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                </div>

                <div class="flex items-center justify-between">
                    <label class="flex items-center">
                        <input type="checkbox" wire:model="remember" class="h-4 w-4 text-amber-600 border-gray-300 rounded">
                        <span class="ml-2 text-sm text-gray-700">Remember me</span>
                    </label>
                    <a href="{{ route('user.forgot-password') }}" class="text-sm text-amber-600 hover:underline">Forgot password?</a>
                </div>

                <button type="submit"
                    class="w-full bg-amber-600 hover:bg-amber-700 text-white font-semibold py-2.5 rounded-lg transition duration-300 shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
                    wire:loading.attr="disabled">
                    <span wire:loading.remove>Login</span>
                    <span wire:loading>Please wait...</span>
                </button>

                <p class="text-gray-600 mt-4">Don't have an account?
                    <a href="{{ route('user.register') }}" class="text-sm text-amber-600 hover:underline">Register here</a>
                </p>
            </form>
        </div>

        @script
        <script>
            // Butterup toast listener
            $wire.on('toast', ([data]) => {
                butterup.toast({
                    title: data.title,
                    message: data.message,
                    type: data.type,
                    location: 'top-right',
                    icon: true
                });
            });

            // Global password toggle utility
            window.togglePasswordVisibility = function(fieldId) {
                const field = document.getElementById(fieldId);
                const icon = document.getElementById(`toggle-password-icon-${fieldId}`);

                if (field.type === 'password') {
                    field.type = 'text';
                    icon.innerText = '🙈';
                } else {
                    field.type = 'password';
                    icon.innerText = '👁️';
                }
            }
        </script>
        @endscript
    </div>
</div>
