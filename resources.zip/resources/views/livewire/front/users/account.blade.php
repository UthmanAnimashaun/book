<?php

use Livewire\Volt\Component;


use App\Models\User;
use App\Models\Order;
use App\Models\DeliveryAddress;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('My Profile | Book Buffet')]
class extends Component {

    public $user;

    // Profile fields
    public $name, $email, $mobile, $address, $city, $state, $country, $pincode;

    // Edit switch mode
    public $editing = false;

    // Order metrics object array
    public $stats = [
        'total' => 0, 'Delivered' => 0, 'New' => 0,
        'In Process' => 0, 'Cancelled' => 0, 'Shipped' => 0, 'Pending' => 0
    ];

    // Delivery addresses collection
    public $addresses = [];

    // Address modal tracking states
    public $showAddressModal = false;
    public $address_id = null;
    public $address_name = '';
    public $address_phone = '';
    public $address_line = '';
    public $address_city = '';
    public $address_state = '';
    public $address_country = '';
    public $address_pincode = '';

    // Password modification tracking states
    public $showPasswordModal = false;
    public $current_password = '';
    public $new_password = '';
    public $confirm_password = '';

    protected function rules()
    {
        return [
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email,' . Auth::id(),
            'mobile' => 'required|string|max:50',
        ];
    }

    public function mount(): void
    {
        // Enforce native auth guard route protection cleanly in-line
        if (!Auth::check()) {
            $this->redirect(route('user.login'));
            return;
        }

        $this->user = Auth::user();
        $this->fillProfileFields();
        $this->loadAddresses();
        $this->loadOrderStats();
    }

    private function fillProfileFields(): void
    {
        $this->name    = $this->user->name;
        $this->email   = $this->user->email;
        $this->mobile  = $this->user->mobile ?? '';
        $this->address = $this->user->address ?? '';
        $this->city    = $this->user->city ?? '';
        $this->state   = $this->user->state ?? '';
        $this->country = $this->user->country ?? '';
        $this->pincode = $this->user->pincode ?? '';
    }

    public function loadAddresses(): void
    {
        $this->addresses = DeliveryAddress::where('user_id', Auth::id())
            ->orderByDesc('id')
            ->get();
    }

    public function loadOrderStats(): void
    {
        // Optimized: Pulls all counts grouped together in 1 query instead of 7 individual hits
        $rawStats = Order::where('user_id', Auth::id())
            ->select('order_status', DB::raw('count(*) as total'))
            ->groupBy('order_status')
            ->pluck('total', 'order_status')
            ->all();

        $this->stats['total'] = array_sum($rawStats);
        foreach (['Delivered', 'New', 'In Process', 'Cancelled', 'Shipped', 'Pending'] as $status) {
            $this->stats[$status] = $rawStats[$status] ?? 0;
        }
    }

    public function toggleEdit(): void
    {
        $this->editing = !$this->editing;
        if (!$this->editing) {
            $this->fillProfileFields();
        }
    }

    public function saveProfile(): void
    {
        $this->validate();

        $this->user->update([
            'name' => $this->name,
            'email' => $this->email,
            'mobile' => $this->mobile,
            'address' => $this->address,
            'city' => $this->city,
            'state' => $this->state,
            'country' => $this->country,
            'pincode' => $this->pincode,
        ]);

        $this->editing = false;
        $this->dispatch('toast', [
            'title' => 'Success!',
            'message' => 'Profile updated successfully',
            'type' => 'success'
        ]);
    }

    public function openAddressModal($id = null): void
    {
        $this->resetAddressForm();
        if ($id) {
            $addr = DeliveryAddress::find($id);
            if ($addr && $addr->user_id == Auth::id()) {
                $this->address_id = $addr->id;
                $this->address_name = $addr->name;
                $this->address_phone = $addr->mobile;
                $this->address_line = $addr->address;
                $this->address_city = $addr->city;
                $this->address_state = $addr->state;
                $this->address_country = $addr->country;
                $this->address_pincode = $addr->pincode;
            }
        }
        $this->showAddressModal = true;
    }

    public function saveAddress(): void
    {
        $this->validate([
            'address_name' => 'required|string|max:255',
            'address_phone' => 'required|string|max:50',
            'address_line' => 'required|string|max:1000',
            'address_state' => 'required|string|max:255',
            'address_city' => 'required|string|max:255',
            'address_pincode' => 'required|string|max:255',
        ]);

        DeliveryAddress::updateOrCreate(
            ['id' => $this->address_id],
            [
                'user_id' => Auth::id(),
                'name' => $this->address_name,
                'mobile' => $this->address_phone,
                'address' => $this->address_line,
                'city' => $this->address_city,
                'state' => $this->address_state,
                'country' => $this->address_country,
                'pincode' => $this->address_pincode,
                'isDefault' => 0,
                'status' => 1,
            ]
        );

        $this->showAddressModal = false;
        $this->loadAddresses();

        $this->dispatch('toast', [
            'title' => 'Saved!',
            'message' => 'Address saved successfully!',
            'type' => 'success'
        ]);
    }

    public function deleteAddress($id): void
    {
        $addr = DeliveryAddress::find($id);
        if ($addr && $addr->user_id == Auth::id()) {
            $addr->delete();
            $this->loadAddresses();
            $this->dispatch('toast', [
                'title' => 'Deleted',
                'message' => 'Address deleted successfully.',
                'type' => 'success'
            ]);
        }
    }

    private function resetAddressForm(): void
    {
        $this->address_id = null;
        $this->address_name = $this->address_phone = $this->address_line = '';
        $this->address_city = $this->address_state = $this->address_country = $this->address_pincode = '';
    }

    public function openPasswordModal(): void
    {
        $this->current_password = $this->new_password = $this->confirm_password = '';
        $this->showPasswordModal = true;
    }

    public function updatePassword(): void
    {
        $this->validate([
            'current_password' => 'required',
            'new_password' => 'required|min:6|same:confirm_password',
        ]);

        if (!Hash::check($this->current_password, $this->user->password)) {
            $this->dispatch('toast', [
                'title' => 'Invalid Password',
                'message' => 'Current password is incorrect.',
                'type' => 'error'
            ]);
            return;
        }

        $this->user->update(['password' => Hash::make($this->new_password)]);
        $this->showPasswordModal = false;
        $this->current_password = $this->new_password = $this->confirm_password = '';

        $this->dispatch('toast', [
            'title' => 'Updated!',
            'message' => 'Password updated successfully!',
            'type' => 'success'
        ]);
    }
};
?>

<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12" x-data="{ currentTab: 'profile' }">

    {{-- Breadcrumb Navigation Row --}}
    <div class="mb-8">
        <div class="text-sm text-gray-500 flex items-center space-x-2 mb-2">
            <a href="/" class="hover:text-amber-600 transition">Home</a>
            <span class="text-amber-600">/</span>
            <a href="/cart" class="hover:text-amber-600 transition">Cart</a>
            <span class="text-amber-600">/</span>
            <span class="text-blue-900 font-medium">My Profile</span>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">

        {{-- Left Side Dynamic Workspace Navigation Links --}}
        <div class="lg:col-span-1 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm h-fit space-y-2">
            <div class="pb-4 border-b border-gray-100 mb-4">
                <h3 class="text-lg font-bold text-blue-900 truncate">{{ $name }}</h3>
                <p class="text-xs text-gray-500 truncate">{{ $email }}</p>
            </div>

            <button @click="currentTab = 'profile'" :class="currentTab === 'profile' ? 'bg-amber-50 text-amber-700 font-semibold' : 'text-gray-600 hover:bg-gray-50'" class="w-full text-left px-4 py-2.5 text-sm rounded-xl transition flex items-center space-x-2">
                <span>👤</span> <span>Profile Info</span>
            </button>
            <button @click="currentTab = 'addresses'" :class="currentTab === 'addresses' ? 'bg-amber-50 text-amber-700 font-semibold' : 'text-gray-600 hover:bg-gray-50'" class="w-full text-left px-4 py-2.5 text-sm rounded-xl transition flex items-center space-x-2">
                <span>🚚</span> <span>Saved Addresses</span>
            </button>
            <button wire:click="openPasswordModal" class="w-full text-left text-gray-600 hover:bg-gray-50 px-4 py-2.5 text-sm rounded-xl transition flex items-center space-x-2">
                <span>🔒</span> <span>Change Password</span>
            </button>
        </div>

        {{-- Right Side Main Content Render Window --}}
        <div class="lg:col-span-3 space-y-8">

            {{-- Order History Overview Stats Cards Matrix Grid --}}
            <section id="order-stats-dashboard" class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div class="bg-blue-900 text-white p-4 rounded-xl shadow-sm border border-blue-950">
                    <span class="text-xs uppercase text-blue-200">Total Orders</span>
                    <p class="text-2xl font-bold mt-1">{{ $stats['total'] }}</p>
                </div>
                <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                    <span class="text-xs uppercase text-gray-400 font-medium">Delivered</span>
                    <p class="text-2xl font-bold text-green-600 mt-1">{{ $stats['Delivered'] }}</p>
                </div>
                <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                    <span class="text-xs uppercase text-gray-400 font-medium">Pending/New</span>
                    <p class="text-2xl font-bold text-yellow-600 mt-1">{{ $stats['New'] + $stats['Pending'] }}</p>
                </div>
                <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                    <span class="text-xs uppercase text-gray-400 font-medium">Cancelled</span>
                    <p class="text-2xl font-bold text-red-600 mt-1">{{ $stats['Cancelled'] }}</p>
                </div>
            </section>

            {{-- Tab 1: Profile Information Container Block --}}
            <div x-show="currentTab === 'profile'" x-cloak class="bg-white p-6 sm:p-8 rounded-2xl border border-gray-100 shadow-sm">
                <div class="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
                    <h2 class="text-xl font-bold text-blue-900">Personal Information</h2>
                    <button wire:click="toggleEdit" class="text-sm font-semibold text-amber-600 hover:underline">
                        {{ $editing ? 'Cancel' : 'Edit Profile' }}
                    </button>
                </div>

                <form wire:submit="saveProfile" class="space-y-5">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Full Name</label>
                            <input type="text" wire:model="name" :disabled="!$wire.editing" class="mt-1 w-full border border-gray-300 rounded-xl px-4 py-2.5 bg-gray-50 disabled:opacity-60 transition focus:outline-none focus:ring-2 focus:ring-amber-600">
                            @error('name') <span class="text-red-600 text-xs mt-1 block">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Email Address</label>
                            <input type="email" wire:model="email" :disabled="!$wire.editing" class="mt-1 w-full border border-gray-300 rounded-xl px-4 py-2.5 bg-gray-50 disabled:opacity-60 transition focus:outline-none focus:ring-2 focus:ring-amber-600">
                            @error('email') <span class="text-red-600 text-xs mt-1 block">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Mobile Phone</label>
                            <input type="text" wire:model="mobile" :disabled="!$wire.editing" class="mt-1 w-full border border-gray-300 rounded-xl px-4 py-2.5 bg-gray-50 disabled:opacity-60 transition focus:outline-none focus:ring-2 focus:ring-amber-600">
                            @error('mobile') <span class="text-red-600 text-xs mt-1 block">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">ZIP / Pincode</label>
                            <input type="text" wire:model="pincode" :disabled="!$wire.editing" class="mt-1 w-full border border-gray-300 rounded-xl px-4 py-2.5 bg-gray-50 disabled:opacity-60 transition focus:outline-none focus:ring-2 focus:ring-amber-600">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Street Address</label>
                        <input type="text" wire:model="address" :disabled="!$wire.editing" class="mt-1 w-full border border-gray-300 rounded-xl px-4 py-2.5 bg-gray-50 disabled:opacity-60 transition focus:outline-none focus:ring-2 focus:ring-amber-600">
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-5">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">City</label>
                            <input type="text" wire:model="city" :disabled="!$wire.editing" class="mt-1 w-full border border-gray-300 rounded-xl px-4 py-2.5 bg-gray-50 disabled:opacity-60 transition focus:outline-none focus:ring-2 focus:ring-amber-600">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">State</label>
                            <input type="text" wire:model="state" :disabled="!$wire.editing" class="mt-1 w-full border border-gray-300 rounded-xl px-4 py-2.5 bg-gray-50 disabled:opacity-60 transition focus:outline-none focus:ring-2 focus:ring-amber-600">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Country</label>
                            <input type="text" wire:model="country" :disabled="!$wire.editing" class="mt-1 w-full border border-gray-300 rounded-xl px-4 py-2.5 bg-gray-50 disabled:opacity-60 transition focus:outline-none focus:ring-2 focus:ring-amber-600">
                        </div>
                    </div>

                    <div x-show="$wire.editing" x-cloak class="pt-2 flex justify-end">
                        <button type="submit" class="bg-amber-600 hover:bg-amber-700 text-white font-semibold px-6 py-2 rounded-xl shadow transition duration-150">
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>

            {{-- Tab 2: Saved Shipping Addresses List Block --}}
            <div x-show="currentTab === 'addresses'" x-cloak class="bg-white p-6 sm:p-8 rounded-2xl border border-gray-100 shadow-sm">
                <div class="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
                    <h2 class="text-xl font-bold text-blue-900">Saved Shipping Addresses</h2>
                    <button wire:click="openAddressModal()" class="bg-blue-900 hover:bg-blue-950 text-white text-xs font-semibold px-4 py-2 rounded-xl transition shadow-sm">
                        ➕ Add Address
                    </button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    @forelse ($addresses as $addr)
                        <div class="border border-gray-200 rounded-xl p-4 flex flex-col justify-between hover:border-amber-500/50 transition bg-gray-50/50">
                            <div>
                                <h4 class="font-bold text-blue-900">{{ $addr->name }}</h4>
                                <p class="text-sm text-gray-600 mt-1">{{ $addr->address }}, {{ $addr->city }}, {{ $addr->state }}</p>
                                <p class="text-xs text-gray-400 mt-0.5">{{ $addr->country }} - {{ $addr->pincode }}</p>
                                <p class="text-sm text-gray-700 mt-2 font-medium">📞 {{ $addr->mobile }}</p>
                            </div>
                            <div class="mt-4 pt-3 border-t border-gray-100 flex justify-end space-x-3 text-xs">
                                <button wire:click="openAddressModal({{ $addr->id }})" class="text-blue-900 hover:underline font-semibold">Edit</button>
                                <button wire:click="deleteAddress({{ $addr->id }})" wire:confirm="Are you sure you want to delete this address?" class="text-red-600 hover:underline font-semibold">Delete</button>
                            </div>
                        </div>
                    @empty
                        <div class="col-span-2 py-8 text-center text-gray-500 text-sm">
                            No additional delivery addresses saved yet.
                        </div>
                    @endforelse
                </div>
            </div>

        </div>
    </div>

    {{-- ========================================== --}}
    {{-- MODAL: ADDRESS ADD/EDIT (Tailwind + Alpine) --}}
    {{-- ========================================== --}}
    <div x-data="{ open: @entangle('showAddressModal') }" x-show="open" class="fixed inset-0 z-50 overflow-y-auto" x-cloak>
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div x-show="open" @click="open = false" class="fixed inset-0 transition-opacity bg-gray-900/40 backdrop-blur-xs"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen">&#8203;</span>

            <div x-show="open" class="inline-block w-full max-w-lg p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl border border-gray-100 sm:align-middle">
                <h3 class="text-xl font-bold text-blue-900 border-b pb-3 mb-4">
                    {{ $address_id ? 'Update Address' : 'Add Delivery Address' }}
                </h3>

                <form wire:submit="saveAddress" class="space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 uppercase">Contact Person Name</label>
                            <input type="text" wire:model="address_name" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                            @error('address_name') <span class="text-red-600 text-xs">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 uppercase">Phone Number</label>
                            <input type="text" wire:model="address_phone" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                            @error('address_phone') <span class="text-red-600 text-xs">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-gray-500 uppercase">Street Address</label>
                        <input type="text" wire:model="address_line" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                        @error('address_line') <span class="text-red-600 text-xs">{{ $message }}</span> @enderror
                    </div>

                    <div class="grid grid-cols-3 gap-3">
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 uppercase">City</label>
                            <input type="text" wire:model="address_city" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                            @error('address_city') <span class="text-red-600 text-xs">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 uppercase">State</label>
                            <input type="text" wire:model="address_state" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                            @error('address_state') <span class="text-red-600 text-xs">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 uppercase">Zipcode</label>
                            <input type="text" wire:model="address_pincode" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                            @error('address_pincode') <span class="text-red-600 text-xs">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-gray-500 uppercase">Country</label>
                        <input type="text" wire:model="address_country" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                    </div>

                    <div class="pt-4 flex justify-end space-x-3 border-t">
                        <button type="button" @click="open = false" class="px-4 py-2 text-sm font-semibold text-gray-500 hover:bg-gray-100 rounded-xl transition">Cancel</button>
                        <button type="submit" class="px-5 py-2 text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow transition">Save Address</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- =========================================== --}}
    {{-- MODAL: UPDATE PASSWORD (Tailwind + Alpine)  --}}
    {{-- =========================================== --}}
    <div x-data="{ open: @entangle('showPasswordModal') }" x-show="open" class="fixed inset-0 z-50 overflow-y-auto" x-cloak>
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div x-show="open" @click="open = false" class="fixed inset-0 transition-opacity bg-gray-900/40 backdrop-blur-xs"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen">&#8203;</span>

            <div x-show="open" class="inline-block w-full max-w-md p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl border border-gray-100 sm:align-middle">
                <h3 class="text-xl font-bold text-blue-900 border-b pb-3 mb-4">🛡️ Update Account Password</h3>

                <form wire:submit="updatePassword" class="space-y-4">
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 uppercase">Current Password</label>
                        <input type="password" wire:model="current_password" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                        @error('current_password') <span class="text-red-600 text-xs">{{ $message }}</span> @enderror
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 uppercase">New Password</label>
                        <input type="password" wire:model="new_password" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                        @error('new_password') <span class="text-red-600 text-xs">{{ $message }}</span> @enderror
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 uppercase">Confirm New Password</label>
                        <input type="password" wire:model="confirm_password" class="mt-1 w-full border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                    </div>

                    <div class="pt-4 flex justify-end space-x-3 border-t">
                        <button type="button" @click="open = false" class="px-4 py-2 text-sm font-semibold text-gray-500 hover:bg-gray-100 rounded-xl transition">Cancel</button>
                        <button type="submit" class="px-5 py-2 text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow transition">Change Password</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

      @script
        <script>
            // Butterup toast listener
            $wire.on('toast', ([data]) => {
                butterup.toast({
                    title: data.title,
                    message: data.message,
                    type: data.type,
                    location: 'top-right',
                    icon: true
                });
            });

            // Global password toggle utility
            window.togglePasswordVisibility = function(fieldId) {
                const field = document.getElementById(fieldId);
                const icon = document.getElementById(`toggle-password-icon-${fieldId}`);

                if (field.type === 'password') {
                    field.type = 'text';
                    icon.innerText = '🙈';
                } else {
                    field.type = 'password';
                    icon.innerText = '👁️';
                }
            }
        </script>
        @endscript

</main>
