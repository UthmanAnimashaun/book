<?php

use Livewire\Volt\Component;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Attributes\Validate;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Hash;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Str;

new #[Layout('layouts.front.app')]
#[Title('Reset Password | Book Buffet')]
class extends Component {
    public $token;

    #[Validate('required|email')]
    public $email = '';

    #[Validate('required|min:8|confirmed')]
    public $password = '';

    public $password_confirmation = '';

    public function mount($token)
    {
        $this->token = $token;
        // Automatically pre-fill the email if it's passed in the URL query string
        $this->email = request()->query('email', '');
    }

    public function resetPassword()
    {
        $this->validate();

        // Attempt to reset the password using Laravel's native Password broker
        $status = Password::reset(
            [
                'token' => $this->token,
                'email' => $this->email,
                'password' => $this->password,
                'password_confirmation' => $this->password_confirmation,
            ],
            function ($user, $password) {
                $user->forceFill([
                    'password' => Hash::make($password)
                ])->setRememberToken(Str::random(60));

                $user->save();

                event(new PasswordReset($user));
            }
        );

        if ($status === Password::PASSWORD_RESET) {
            session()->flash('status', __($status));

            // Dispatch toast notification for butterup
            $this->dispatch('toast', [
                'title' => 'Success!',
                'message' => __($status),
                'type' => 'success'
            ]);

            // Redirect back to login after a brief delay, or immediately
            return redirect()->route('user.login');
        } else {
            // Add error message to the email field if token/email validation fails
            $this->addError('email', __($status));
        }
    }
}; ?>

<div class="min-h-screen flex items-center justify-center bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
    <div class="w-full max-w-md bg-white p-8 rounded-3xl shadow-xl border border-slate-100">

        <div class="text-center mb-8">
            <h2 class="text-3xl font-black text-slate-800 tracking-tight">Reset your password</h2>
            <p class="text-sm text-slate-500 mt-2 font-medium">Enter your email and choose a strong new password.</p>
        </div>

        @if (session('status'))
            <div class="mb-6 p-4 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl text-sm font-bold animate-in fade-in slide-in-from-top-2">
                {{ session('status') }}
            </div>
        @endif

        <form wire:submit="resetPassword" class="space-y-5">
            {{-- Email Input --}}
            <div>
                <label class="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Email Address</label>
                <input type="email" wire:model="email" placeholder="name@example.com" required
                    class="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition shadow-sm">
                @error('email')
                    <span class="text-xs text-rose-500 font-bold mt-1 ml-1 block">{{ $message }}</span>
                @enderror
            </div>

            {{-- Password Input --}}
            <div>
                <label class="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">New Password</label>
                <div class="relative">
                    <input type="password" id="password" wire:model="password" placeholder="••••••••" required
                        class="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition shadow-sm">
                    <button type="button" onclick="togglePasswordVisibility('password')" class="absolute right-4 top-1/2 -translate-y-1/2 text-lg filter grayscale opacity-60 hover:opacity-100 transition" id="toggle-password-icon-password">👁️</button>
                </div>
                <small class="text-slate-400 text-xs mt-1 block font-medium">Minimum of 8 characters</small>
                @error('password')
                    <span class="text-xs text-rose-500 font-bold mt-1 ml-1 block">{{ $message }}</span>
                @enderror
            </div>

            {{-- Confirm Password Input --}}
            <div>
                <label class="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Confirm New Password</label>
                <div class="relative">
                    <input type="password" id="password_confirmation" wire:model="password_confirmation" placeholder="••••••••" required
                        class="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition shadow-sm">
                    <button type="button" onclick="togglePasswordVisibility('password_confirmation')" class="absolute right-4 top-1/2 -translate-y-1/2 text-lg filter grayscale opacity-60 hover:opacity-100 transition" id="toggle-password-icon-password_confirmation">👁️</button>
                </div>
            </div>

            {{-- Form Submit Action Button --}}
            <button type="submit" wire:loading.attr="disabled"
                class="w-full py-4 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition shadow-lg shadow-emerald-100 flex justify-center items-center active:scale-95 disabled:opacity-70 disabled:pointer-events-none">
                <span wire:loading.remove>Reset Password</span>
                <span wire:loading class="flex items-center gap-2">
                    <svg class="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Resetting...
                </span>
            </button>
        </form>
    </div>

    @script
    <script>
        // Butterup toast listener
        $wire.on('toast', ([data]) => {
            butterup.toast({
                title: data.title,
                message: data.message,
                type: data.type,
                location: 'top-right',
                icon: true
            });
        });

        // Global password toggle utility
        window.togglePasswordVisibility = function(fieldId) {
            const field = document.getElementById(fieldId);
            const icon = document.getElementById(`toggle-password-icon-${fieldId}`);

            if (field && field.type === 'password') {
                field.type = 'text';
                if(icon) icon.innerText = '🙈';
            } else if(field) {
                field.type = 'password';
                if(icon) icon.innerText = '👁️';
            }
        }
    </script>
    @endscript
</div>
