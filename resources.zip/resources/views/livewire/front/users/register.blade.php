<?php

use Livewire\Volt\Component;
use App\Models\User;
use App\Models\State;
use App\Models\Lga;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('Create Account | BookBuffet')]
class extends Component {

    // Form model properties
    public $name = '';
    public $email = '';
    public $mobile = '';
    public $state = '';
    public $city = '';
    public $password = '';
    public $password_confirmation = '';
    public $accept = false;

    // Collections containers cached for component lifecycle
    public $statesList = [];
    public $lgasList = [];

    public function mount(): void
    {
        // Cache data sets straight into the component mount phase to optimize load speeds
        $this->statesList = states();

        // Map out LGA collection details for smooth Alpine engine synchronization loops
        $this->lgasList = lgas()->map(fn($lga) => [
            'name' => $lga->name,
            'state_name' => $lga->state->name
        ])->toArray();
    }

    public function register()
    {
        $this->validate([
            'name' => 'required|string|max:255',
            'email' => ['required', 'email', 'unique:users,email'],
            'mobile' => ['required', 'string', 'max:20'],
            'state' => 'required|string',
            'city' => 'required|string',
            'password' => 'required|min:8|confirmed',
        ]);

        $user = new User([
            'name' => $this->name,
            'email' => $this->email,
            'mobile' => $this->mobile,
            'state' => $this->state,
            'city' => $this->city,
            'password' => Hash::make($this->password),
        ]);

        try {
            $email = $this->email;
            $messageData = [
                'email' => $this->email,
                'name' => $this->name,
                'code' => base64_encode($this->email)
            ];

            Mail::send('emails.confirmation', $messageData, function ($message) use ($email) {
                $website_name = DB::table('websites')->get();
                $web_name = $website_name[0]->name ?? 'BookBuffet';
                $message->to($email)->subject('Confirm your ' . $web_name . " account");
            });

            // Persist the verified user parameters to the DB
            $user->save();

            // Set up a native browser redirect session string mapping
            session()->flash('success_message', 'A verification link has been sent to your email');
            return $this->redirect('/login-page', navigate: true);

        } catch (\Exception $e) {
            // Intercept errors and route them directly to the frontend Butterup engine layout
            $this->dispatch('toast', [
                'title' => 'Registration Error',
                'message' => $e->getMessage(),
                'type' => 'error'
            ]);
        }
    }
}; ?>

<main class="w-full min-h-screen flex items-center justify-center bg-gray-50/50 py-12 px-4 sm:px-6 lg:px-8">
    <div class="w-full max-w-xl space-y-8">

        <div class="text-center">
            <h1 class="text-4xl font-extrabold text-blue-900 tracking-tight">BookBuffet</h1>
            <p class="text-sm text-amber-600 font-medium mt-1.5">Where Readers Meet Knowledge</p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl p-6 sm:p-10 border border-gray-100">
            <h2 class="text-2xl font-bold text-gray-800">Create Account</h2>
            <p class="text-sm text-gray-500 mt-1 mb-6">Join BookBuffet and start your reading journey.</p>

            {{-- Alpine.js State Tracking Matrix wrapper handles conditional local element layout processing --}}
            <form wire:submit.prevent="register"
                  x-data="{ chosenState: @entangle('state'), availableLgas: @js($lgasList) }"
                  class="space-y-5">

                <div>
                    <label for="name" class="block text-xs font-bold uppercase text-gray-500 mb-1">Full Name <span class="text-red-600">*</span></label>
                    <input type="text" id="name" wire:model="name" placeholder="Full Name"
                        class="w-full border @error('name') border-red-500 @else border-gray-300 @enderror rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-amber-600/40 focus:outline-none transition">
                    @error('name') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label for="email" class="block text-xs font-bold uppercase text-gray-500 mb-1">Email <span class="text-red-600">*</span></label>
                        <input type="email" id="email" wire:model="email" placeholder="Email Address"
                            class="w-full border @error('email') border-red-500 @else border-gray-300 @enderror rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-amber-600/40 focus:outline-none transition">
                        @error('email') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                    </div>

                    <div>
                        <label for="mobile" class="block text-xs font-bold uppercase text-gray-500 mb-1">Mobile <span class="text-red-600">*</span></label>
                        <input type="tel" id="mobile" wire:model="mobile" placeholder="Phone Number"
                            class="w-full border @error('mobile') border-red-500 @else border-gray-300 @enderror rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-amber-600/40 focus:outline-none transition">
                        @error('mobile') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label for="state" class="block text-xs font-bold uppercase text-gray-500 mb-1">State <span class="text-red-600">*</span></label>
                        <select id="state" wire:model.live="state" class="w-full border @error('state') border-red-500 @else border-gray-300 @enderror rounded-xl px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-amber-600/40">
                            <option value="">Select State</option>
                            @foreach ($statesList as $st)
                                <option value="{{ $st->name }}">{{ $st->name }}</option>
                            @endforeach
                        </select>
                        @error('state') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                    </div>

                    <div>
                        <label for="city" class="block text-xs font-bold uppercase text-gray-500 mb-1">Local Government Area <span class="text-red-600">*</span></label>
                        <select id="city" wire:model="city" class="w-full border @error('city') border-red-500 @else border-gray-300 @enderror rounded-xl px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-amber-600/40">
                            <option value="">Select City</option>
                            {{-- High Performance Client-Side Alpine Loop filter outputs matches smoothly based on the parent state selection context --}}
                            <template x-for="lga in availableLgas.filter(item => item.state_name === chosenState)" :key="lga.name">
                                <option :value="lga.name" x-text="lga.name"></option>
                            </template>
                        </select>
                        @error('city') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4" x-data="{ showPass: false, showConfirm: false }">
                    <div>
                        <label for="password" class="block text-xs font-bold uppercase text-gray-500 mb-1">Password <span class="text-red-600">*</span></label>
                        <div class="relative">
                            <input :type="showPass ? 'text' : 'password'" id="password" wire:model="password" placeholder="••••••••"
                                class="w-full border @error('password') border-red-500 @else border-gray-300 @enderror rounded-xl px-4 py-2.5 pr-10 text-sm focus:ring-2 focus:ring-amber-600/40 focus:outline-none transition">
                            <button type="button" @click="showPass = !showPass" class="absolute right-3 top-3 text-gray-400 text-xs focus:outline-none" x-text="showPass ? '🙈' : '👁️'"></button>
                        </div>
                        <div class="text-[10px] text-gray-400 mt-1 font-medium">Minimum of 8 characters</div>
                        @error('password') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                    </div>

                    <div>
                        <label for="password_confirmation" class="block text-xs font-bold uppercase text-gray-500 mb-1">Confirm Password <span class="text-red-600">*</span></label>
                        <div class="relative">
                            <input :type="showConfirm ? 'text' : 'password'" id="password_confirmation" wire:model="password_confirmation" placeholder="••••••••"
                                class="w-full border @error('password_confirmation') border-red-500 @else border-gray-300 @enderror rounded-xl px-4 py-2.5 pr-10 text-sm focus:ring-2 focus:ring-amber-600/40 focus:outline-none transition">
                            <button type="button" @click="showConfirm = !showConfirm" class="absolute right-3 top-3 text-gray-400 text-xs focus:outline-none" x-text="showConfirm ? '🙈' : '👁️'"></button>
                        </div>
                        @error('password_confirmation') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                    </div>
                </div>

                <div class="flex items-start pt-1">
                    <div class="flex items-center h-5">
                        <input id="accept" type="checkbox" wire:model="accept" required class="h-4 w-4 text-amber-600 border-gray-300 rounded focus:ring-amber-500">
                    </div>
                    <div class="ml-3 text-sm">
                        <label for="accept" class="font-medium text-gray-700">I agree to the <a href="{{ route('tc') }}" class="text-amber-600 font-bold hover:underline">Terms & Conditions</a></label>
                        @error('accept') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                    </div>
                </div>

                <div class="pt-2">
                    <button type="submit"
                        class="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-4 rounded-xl transition duration-150 shadow-md flex items-center justify-center space-x-2"
                        wire:loading.attr="disabled">
                        <span wire:loading.remove>Create Account &rarr;</span>
                        <span wire:loading>Processing Request...</span>
                    </button>
                </div>

                <div class="text-center pt-2 border-t border-gray-100 text-sm text-gray-500">
                    Already have an account? <a href="{{ route('user.login') }}" class="font-bold text-amber-600 hover:underline ml-0.5">Login here</a>
                </div>

            </form>
        </div>
    </div>

    {{-- Butterup Real-Time Toast Event Script Bridge --}}
    @script
    <script>
        $wire.on('toast', ([data]) => {
            butterup.toast({
                title: data.title,
                message: data.message,
                type: data.type,
                location: 'top-right',
                icon: true
            });
        });
    </script>
    @endscript
</main>
