<?php

use Livewire\Volt\Component;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Carbon\Carbon;

new #[Layout('layouts.front.app')]
#[Title('Forgot Password | Book Buffet')]

class extends Component {
    public $email = '';

    public function sendResetLink()
    {
        $this->validate([
            'email' => 'required|email'
        ]);

        // 1. Verify the user actually exists in your regular users database table
        $user = DB::table('users')->where('email', $this->email)->first();

        if (!$user) {
            // Keep it secure: Don't explicitly leak if an email exists or not,
            // or show an error depending on your design preference.
            $this->addError('email', 'We could not find a user with that email address.');
            return;
        }

        // 2. Generate a secure random token
        $token = Str::random(60);

        // 3. Wipe out any older tokens for this email to prevent spam and insert the new one
        DB::table('password_reset_tokens')->where('email', $this->email)->delete();

        DB::table('password_reset_tokens')->insert([
            'email' => $this->email,
            'token' => password_hash($token, PASSWORD_BCRYPT), // Laravel hashes tokens natively
            'created_at' => Carbon::now()
        ]);

        // 4. Force-build the exact user storefront password reset URL
        $resetUrl = route('user.reset-password', [
            'token' => $token,
            'email' => $this->email
        ]);

        // 5. Instantly ship your custom email layout template
        $appName = config('app.name');
        Mail::send('emails.forgot_password', ['link' => $resetUrl], function($message) use ($appName) {
            $message->to($this->email)
                    ->subject($appName . ' - Password Reset Protocol');
        });

        // 6. Flash success status and reset UI
        session()->flash('status', 'We have emailed your password reset link!');
        $this->email = '';

        $this->dispatch('toast', [
            'title' => 'Protocol Initiated',
            'message' => 'We have emailed your password reset link!',
            'type' => 'success'
        ]);
    }
}; ?>

<div class="min-h-screen flex items-center justify-center bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
    <div class="w-full max-w-md bg-white p-8 rounded-3xl shadow-xl border border-slate-100">
        <div class="text-center mb-8">
            <h2 class="text-2xl font-black text-slate-800 tracking-tight">Forgot Password?</h2>
            <p class="text-sm text-slate-500 mt-2 font-medium">No worries, we'll send you a link to get back into your Vault.</p>
        </div>

        @if (session('status'))
            <div class="mb-6 p-4 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl text-sm font-bold animate-in fade-in slide-in-from-top-2">
                {{ session('status') }}
            </div>
        @endif

        <form wire:submit="sendResetLink" class="space-y-6">
            <div>
                <label class="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Email Address</label>
                <input type="email" wire:model.blur="email" required autofocus
                    class="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition shadow-sm">
                @error('email')
                    <span class="text-xs text-rose-500 font-bold mt-1 ml-1 block">{{ $message }}</span>
                @enderror
            </div>

            <button type="submit" wire:loading.attr="disabled"
                class="w-full py-4 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition shadow-lg shadow-emerald-100 flex justify-center items-center active:scale-95 disabled:opacity-70 disabled:pointer-events-none">
                <span wire:loading.remove>Send Reset Link</span>
                <span wire:loading class="flex items-center gap-2">
                    <svg class="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Sending...
                </span>
            </button>

            <div class="text-center mt-6">
                <a href="{{ route('user.login') }}" class="text-sm font-bold text-slate-400 hover:text-emerald-600 transition">
                    &larr; Back to Login
                </a>
            </div>
        </form>
    </div>

    @script
    <script>
        // Butterup toast listener
        $wire.on('toast', ([data]) => {
            butterup.toast({
                title: data.title,
                message: data.message,
                type: data.type,
                location: 'top-right',
                icon: true
            });
        });

        // Global password toggle utility (Kept for compatibility, though not needed on this form)
        window.togglePasswordVisibility = function(fieldId) {
            const field = document.getElementById(fieldId);
            const icon = document.getElementById(`toggle-password-icon-${fieldId}`);

            if (field && field.type === 'password') {
                field.type = 'text';
                if(icon) icon.innerText = '🙈';
            } else if(field) {
                field.type = 'password';
                if(icon) icon.innerText = '👁️';
            }
        }
    </script>
    @endscript
</div>
