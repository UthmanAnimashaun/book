<?php

use Livewire\Volt\Component; // 👈 Fixed: Changed from Livewire\Component to Volt\Component
use App\Models\Product;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session; // Added missing import for clean execution
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('Payment Failed | Book Buffet')]
class extends Component {

    public function mount(): void
    {
        // Clean up fallback session footprints right in the backend mount lifecycle
        Session::forget([
            'order_id',
            'grand_total',
            'email',
            'currency',
            'name'
        ]);
    }
};
?>

<main class="flex-grow flex items-center justify-center p-6">
    <div class="transition-opacity duration-500 max-w-md w-full">
        <div class="bg-white rounded-2xl shadow-lg p-8 w-full border border-red-200">
            <div class="flex flex-col items-center text-center">

                {{-- Swapped FontAwesome icon to a clean matching layout emoji --}}
                <div class="text-7xl mb-6 select-none animate-pulse">
                    ❌
                </div>

                <h2 class="text-3xl font-extrabold text-blue-900 mb-2">Payment Failed</h2>

                <p class="text-gray-600 mt-2">
                    Sorry, something went wrong while processing your payment. Your order could not be completed.
                </p>

                <div class="mt-6 p-4 rounded-xl bg-gray-50 border border-gray-200 w-full text-left space-y-2 text-sm">
                    <p class="text-red-600 font-semibold">⚠️ Error: Insufficient funds or card declined.</p>
                    <p class="text-gray-600">Please verify your payment details or try a different method.</p>
                </div>

                <div class="flex flex-col sm:flex-row gap-3 mt-8 w-full">
                    <a href="{{ route('checkout') }}" class="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition duration-150 shadow-md">
                        🔄 Try Again
                    </a>
                    <a href="/" class="w-full bg-gray-700 hover:bg-gray-800 text-white font-bold py-3 px-4 rounded-lg transition duration-150 shadow-md">
                        🏠 Go Home
                    </a>
                </div>
            </div>
        </div>
    </div>
</main>
