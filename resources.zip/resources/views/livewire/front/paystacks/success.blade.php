<?php
use Livewire\Volt\Component;
use Illuminate\Support\Facades\Session;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;


new #[Layout('layouts.front.app')]
#[Title('Success | Book Buffet')]
class extends Component {

    public function mount(): void
    {
        // 💡 Best Practice: Clean up checkout sessions immediately upon landing
        // but safely contained inside the component backend controller lifecycle
        Session::forget([
            'order_id',
            'grand_total',
            'email',
            'currency',
            'name'
        ]);
    }
};
?>

<main class="flex-grow flex items-center justify-center p-6">
    <div class="transition-opacity duration-500 max-w-md w-full">
        <div class="bg-white rounded-2xl shadow-lg p-8 w-full border border-green-200">
            <div class="flex flex-col items-center text-center">

                {{-- Swapped FontAwesome circle icon with matching system emoji --}}
                <div class="text-7xl mb-6 select-none animate-bounce">
                    🎉
                </div>

                <h2 class="text-3xl font-extrabold text-blue-900 mb-2">Order Placed Successfully!</h2>

                <p class="text-gray-600 mt-2">
                    Thank you for shopping with {{ config("app.name") }}. Your order has been received and is being processed.
                </p>

                <div class="flex flex-col sm:flex-row gap-3 mt-8 w-full">
                    <a href="{{ route('user.orders') }}" class="w-full bg-blue-900 hover:bg-blue-800 text-white font-bold py-3 px-4 rounded-lg transition duration-150 shadow-md">
                        📦 View My Orders
                    </a>
                    <a href="{{ route('product-shop') }}" class="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-4 rounded-lg transition duration-150 shadow-md">
                        🛍️ Continue Shopping
                    </a>
                </div>
            </div>
        </div>
    </div>
</main>
