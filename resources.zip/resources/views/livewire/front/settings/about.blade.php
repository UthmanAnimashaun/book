<?php

use Livewire\Volt\Component;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('About | Book Buffet')]
 class extends Component {
    //
};
?>

<div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">

    <div class="mb-6 text-sm text-gray-500 flex items-center space-x-2">
        <a href="/" class="hover:text-amber-600 transition">Home</a>
        <span class="text-amber-600">/</span>
        <span class="text-blue-900 font-medium">About</span>
    </div>

    <section class="mb-16">
        <h2 class="text-4xl font-extrabold text-center mb-4">
            Welcome to <span class="text-amber-600">{{ optional($websites[0])->name }}</span>
        </h2>
        <p class="text-xl text-center max-w-3xl mx-auto mb-8 text-blue-900/90">
            A place where every reader can find their perfect dish. We believe that <b>reading is a feast</b> , and we're here to serve up your next unforgettable meal.
            {{-- {{ optional($websites[0])->information }} --}}
        </p>

        <div class="md:flex md:space-x-12 mt-10">
            <div class="md:w-1/2 mb-6 md:mb-0">
                <h3 class="text-2xl font-bold mb-3 border-b-2 border-amber-600 pb-1">Our Mission</h3>
                <p class="text-lg leading-relaxed">
                    Our mission is simple: to connect readers with the books they'll genuinely love. We cut through the noise to offer curated collections, insightful reviews, and a vibrant community. Whether you're craving a classic literary novel or a fresh, new genre title, <b>{{ optional($websites[0])->name }}</b> is your trusted source for discovery.
                </p>
            </div>
            <div class="md:w-1/2">
                <h3 class="text-2xl font-bold mb-3 border-b-2 border-amber-600 pb-1">The Buffet Concept</h3>
                <p class="text-lg leading-relaxed">
                    Just like a grand buffet, we offer <b>variety, quality, and abundance</b>. You're invited to sample a little of everything: fiction, non-fiction, poetry, and graphic novels. Dive in, explore new tastes, and don't be afraid to go back for seconds (or thirds!). Your reading journey should be exciting and unrestricted.
                </p>
            </div>
        </div>
    </section>

    <hr class="border-gray-300 my-10">

    <section class="mb-16">
        <h2 class="text-3xl font-extrabold text-center mb-10">
            Our <span class="text-amber-600">Core Values</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">

            <div class="bg-white p-6 rounded-lg shadow-lg card-hover border-t-4 border-amber-600">
                <div class="text-3xl mb-3 text-amber-600">📖</div>
                <h4 class="text-xl font-bold mb-2">Focused Discovery</h4>
                <p class="text-blue-900/80">
                    We don't just list books; we curate them. Our goal is to minimize browsing time and maximize the joy of finding <b>the perfect next read</b>.
                </p>
            </div>

            <div class="bg-white p-6 rounded-lg shadow-lg card-hover border-t-4 border-amber-600">
                <div class="text-3xl mb-3 text-amber-600">🤝</div>
                <h4 class="text-xl font-bold mb-2">Vibrant Community</h4>
                <p class="text-blue-900/80">
                    Reading is better together. We foster a supportive space for readers to share recommendations, reviews, and their passion for literature.
                </p>
            </div>

            <div class="bg-white p-6 rounded-lg shadow-lg card-hover border-t-4 border-amber-600">
                <div class="text-3xl mb-3 text-amber-600">🌟</div>
                <h4 class="text-xl font-bold mb-2">Unwavering Quality</h4>
                <p class="text-blue-900/80">
                    From the books we feature to the service we provide, quality is paramount. We strive for excellence in every interaction with our readers.
                </p>
            </div>
        </div>
    </section>

    <section class="bg-blue-900 text-white p-10 rounded-lg text-center shadow-xl">
        <h2 class="text-3xl font-bold mb-3">Ready for your next serving?</h2>
        <p class="text-lg mb-6">
            Explore our curated selections and join the {{ optional($websites[0])->name }} family today.
        </p>
        <a href="{{ route('product-shop') }}" class="inline-block bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-8 rounded-full transition duration-300 ease-in-out transform hover:scale-105">
            Start Browsing Books
        </a>
    </section>

</div>

