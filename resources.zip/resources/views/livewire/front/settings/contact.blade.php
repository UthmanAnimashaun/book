<?php

use Livewire\Volt\Component;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Models\Website;

new #[Layout('layouts.front.app')]
#[Title('Contact | Book Buffet')]
 class extends Component {


    public $name, $email, $subject, $userMessage;
    public $websites; // Declared to pass database data safely down to blade

    protected $rules = [
        'name' => 'required|string|min:3',
        'email' => 'required|email',
        'subject' => 'required|string|min:3',
        'userMessage' => 'required|string|min:5',
    ];

    public function mount(): void
    {
        // Pull down the website records once when the component initializes
        $this->websites = DB::table('websites')->get();
    }

    public function sendMessage()
    {
        $this->validate();

        try {
            $website = $this->websites->first();
            // Using the corrected email spelling as your default fallback fallback
            $admin_email = config("app.email") ?? 'animashanua@gmail.com';

            $data = [
                'email' => $this->email,
                'name' => $this->name,
                'subject' => $this->subject,
                'body' => $this->userMessage,
            ];

            // Send message to admin
            Mail::send('emails.enquiry', $data, function ($message) use ($admin_email, $data) {
                $message->to($admin_email)
                        ->subject('Message from ' . $data['name']);
            });

            // Send auto reply to user
            Mail::send('emails.contact-auto-reply', [
                'name' => $this->name,
                'websiteName' => $website->name ?? 'Our Website',
                'adminEmail' => $admin_email,
            ], function ($message) use ($data) {
                $message->to($data['email'])
                        ->subject('We Received Your Message');
            });

            $this->reset(['name', 'email', 'subject', 'userMessage']);

            // Dispatched using standard Livewire 3 payload parameters for Butterup
            $this->dispatch('toast', [
                'title' => 'Message Sent!',
                'message' => 'Thanks for your message, we will get back to you soon.',
                'type' => 'success'
            ]);

        } catch (\Exception $e) {
            $this->dispatch('toast', [
                'title' => 'Error Occurred',
                'message' => $e->getMessage(),
                'type' => 'error'
            ]);
        }
    }
};
?>

<main class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">

    <div class="mb-6 text-sm text-gray-500 flex items-center space-x-2">
        <a href="/" class="hover:text-amber-600 transition">Home</a>
        <span class="text-amber-600">/</span>
        <span class="text-blue-900 font-medium">Contact</span>

    </div>

    <h2 class="text-4xl font-extrabold text-center mb-4">
        Get in <span class="text-amber-600">Touch</span>
    </h2>
    <p class="text-xl text-center max-w-3xl mx-auto mb-10 text-blue-900/90">
        Have a question about a book, a suggestion for the buffet, or just want to say hello? We'd love to hear from you!
    </p>


    <div class="lg:flex lg:space-x-12">

        {{-- Contact Form --}}
        <section class="lg:w-2/3 bg-white p-8 rounded-lg shadow-xl mb-10 lg:mb-0">
            <h3 class="text-2xl font-bold mb-6 border-b-2 border-gray-200 pb-2">Send Us a Message</h3>


            <form wire:submit="sendMessage" class="space-y-6">

                <div>
                    <label for="name" class="block text-sm font-medium text-blue-900">Your Full Name <span class="text-red-900">*</span></label>
                    <input type="text" wire:model="name" id="name" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 text-blue-900 input-focus">
                    @error('name') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                </div>

                <div>
                    <label for="email" class="block text-sm font-medium text-blue-900">Email Address <span class="text-red-900">*</span></label>
                    <input type="email" wire:model="email" id="email" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 text-blue-900 input-focus">
                    @error('email') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                </div>

                <div>
                    <label for="subject" class="block text-sm font-medium text-blue-900">Subject <span class="text-red-900">*</span></label>
                    <input type="text" wire:model="subject" id="subject" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 text-blue-900 input-focus">
                    @error('subject') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                </div>

                <div>
                    <label for="message" class="block text-sm font-medium text-blue-900">Your Message <span class="text-red-900">*</span></label>
                    <textarea wire:model="userMessage" id="message" rows="4" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 text-blue-900 input-focus"></textarea>
                    {{-- Fixed: Changed error key name from 'message' to match the public property 'userMessage' --}}
                    @error('userMessage') <span class="text-red-600 text-sm">{{ $message }}</span> @enderror
                </div>

                <div>
                    <button type="submit"
                        class="w-full inline-flex justify-center py-3 px-6 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-amber-600 hover:bg-amber-700 transition duration-300 ease-in-out focus:ring-2 focus:ring-offset-2 focus:ring-amber-600"
                        wire:loading.attr="disabled"
                        wire:loading.class="opacity-50 cursor-not-allowed"
                    >
                        <span wire:loading.remove>Send Message</span>
                        <span wire:loading>Sending...</span>
                    </button>
                </div>
            </form>
        </section>

        {{-- Contact Info --}}
        <section class="lg:w-1/3 space-y-8">
            <div class="bg-blue-900 text-white p-8 rounded-lg shadow-xl">
                <h3 class="text-2xl font-bold mb-4 border-b-2 border-amber-600 pb-2">Contact Details</h3>

                <ul class="space-y-4">
                    <li>
                        <p class="font-semibold text-amber-600">Email for Support:</p>
                        <a href="mailto:{{ optional($websites->first())->email }}" class="hover:underline">
                            {{ optional($websites->first())->email }}
                        </a>
                    </li>
                    <li>
                        <p class="font-semibold text-amber-600">Phone (Office Hours):</p>
                        <p>{{ optional($websites->first())->phone_number }}</p>
                    </li>
                    <li>
                        <p class="font-semibold text-amber-600">Mailing Address:</p>
                        <address class="not-italic">{{ optional($websites->first())->location }}</address>
                    </li>
                </ul>
            </div>

            <div class="bg-white p-6 rounded-lg shadow-xl text-center">
                <h3 class="text-xl font-bold mb-3">Our Location (Headquarters)</h3>
                <div class="h-40 bg-gray-200 rounded-md flex items-center justify-center border border-gray-300">
                    <span class="text-gray-500">📍 [Map Integration]</span>
                </div>
            </div>
        </section>

    </div>
       @script
    <script>
        // Butterup toast listener
        $wire.on('toast', ([data]) => {
            butterup.toast({
                title: data.title,
                message: data.message,
                type: data.type,
                location: 'top-right',
                icon: true
            });
        });
    </script>
    @endscript
</main>
