<?php

use Livewire\Volt\Component;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('FAQ | Book Buffet')]
 class extends Component {
    //
};
?>

<main class="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">


    <div class="mb-6 text-sm text-gray-500 flex items-center space-x-2">
        <a href="/" class="hover:text-amber-600 transition">Home</a>
        <span class="text-amber-600">/</span>
        <span class="text-blue-900 font-medium">FAQ</span>
    </div>


    <h2 class="text-4xl font-extrabold text-center mb-4">
        Frequently Asked <span class="text-amber-600">Questions</span>
    </h2>
    <p class="text-xl text-center max-w-3xl mx-auto mb-10 text-blue-900/90">
        Got questions about how the buffet works? Find quick, elegant answers here.
    </p>

    <div class="space-y-4">

        <h3 class="text-2xl font-bold pt-4 pb-2 text-blue-900 border-b-2 border-amber-600 mb-6">
            🍽️ Account & Membership
        </h3>

        <details class="faq-accordion-item">
            <summary>What are the benefits of creating a BookBuffet account?</summary>
            <div class="faq-content">
                <p>Creating an account is free and essential for a personalized experience. It allows you to <b>save books to custom reading lists</b> (like "To Read" or "Currently Reading"), post <b>reviews and ratings</b>, receive personalized book recommendations, and join our community discussions.</p>
            </div>
        </details>

        <details class="faq-accordion-item">
            <summary>Is BookBuffet free to use?</summary>
            <div class="faq-content">
                <p>Yes, <b>creating an account, browsing books, and posting reviews are completely free</b>. We sometimes feature links to external retailers, but we do not charge for access to our core discovery service.</p>
            </div>
        </details>

        <details class="faq-accordion-item">
            <summary>How can I reset my password?</summary>
            <div class="faq-content">
                <p>On the login screen, click "Forgot Password." Enter your registered email address, and we will send you a link to securely reset your credentials.</p>
            </div>
        </details>


        <h3 class="text-2xl font-bold pt-8 pb-2 text-blue-900 border-b-2 border-amber-600 mb-6">
            🔎 Discovering Books
        </h3>

         @if (faq())

            @foreach (faq() as $faq )
                <details class="faq-accordion-item">
                    <summary>{{ $faq->question }}?</summary>
                    <div class="faq-content">
                        <p>  {{ $faq->answer }}</p>
                    </div>
                </details>
            @endforeach
        @endif

        <details class="faq-accordion-item">
            <summary>How do you select the books featured on BookBuffet?</summary>
            <div class="faq-content">
                <p>Our selection is curated by a mix of factors: <b>Staff Picks</b>, current literary trends, high community ratings, and historical significance. We aim for variety, ensuring there is a dish for every literary palate.</p>
            </div>
        </details>

        <details class="faq-accordion-item">
            <summary>Where can I actually buy the books I find here?</summary>
            <div class="faq-content">
                <p>BookBuffet is a discovery platform, not a retailer. On every <b>Book Detail Page</b>, you will find a <b>"Where to Buy"</b> section with links directing you to major online booksellers and physical bookstores.</p>
            </div>
        </details>

        <details class="faq-accordion-item">
            <summary>What are "Reading Lists" and how do I use them?</summary>
            <div class="faq-content">
                <p>Reading Lists are custom collections in your profile. You can create lists like 'My Wishlist,' 'Currently Reading,' or 'Books for the Summer.' Click the 'Add to List' button on any book page to manage your personal collections.</p>
            </div>
        </details>

        <div class="pt-10 text-center">
            <p class="text-lg">
                Still hungry for answers? Please <b><a href="{{ route('contact') }}" class="text-amber-600 hover:underline font-bold">Contact Us</a></b> directly and we'll serve up a solution!
            </p>
        </div>

    </div>

</main>

