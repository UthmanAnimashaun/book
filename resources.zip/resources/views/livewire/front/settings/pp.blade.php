<?php

use Livewire\Volt\Component;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('Privacy Policy | Book Buffet')]
 class extends Component {
    //
};
?>


<main class="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">

    <div class="mb-6 text-sm text-gray-500 flex items-center space-x-2">
        <a href="/" class="hover:text-amber-600 transition">Home</a>
        <span class="text-amber-600">/</span>
        <span class="text-blue-900 font-medium">Privacy Policy</span>
    </div>


    <h2 class="text-4xl font-extrabold text-center mb-4">
        Our <span class="text-amber-600">Privacy Policy</span>
    </h2>
    <p class="text-center text-sm text-blue-900/70 mb-8">
        This Policy was last updated on: November 5, 2025
    </p>

    <section class="bg-white p-8 rounded-lg shadow-xl">
        <p class="mb-6">
            Your privacy is important to us. This Privacy Policy describes how  {{ optional($websites[0])->name }} collects, uses, and discloses your personal information when you visit and use our website. By using  {{ optional($websites[0])->name }}, you agree to the collection and use of information in accordance with this policy.
        </p>

        <h3 class="text-2xl font-bold mb-4 mt-6 border-b border-amber-600 pb-1">1. Information We Collect</h3>
        <p class="font-semibold text-blue-900 mb-2">
            We collect several types of information for various purposes to provide and improve our service to you:
        </p>
        <ul class="list-disc ml-6 policy-list text-blue-900/90">
            <li>
                <b>Personal Data:</b> While using our service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you ("Personal Data"). This may include, but is not limited to: <b>Email address</b>, <b>Name</b> (first and last), and <b>User Profile Photo</b>.
            </li>
            <li>
                <b>Usage Data:</b> We collect information about how the Service is accessed and used ("Usage Data"). This Usage Data may include information such as your computer's Internet Protocol address (IP address), browser type, pages visited, time and date of your visit, and time spent on those pages.
            </li>
            <li>
                <b>Reading Data:</b> We collect information related to your activity on the site, such as <b>books reviewed</b>, <b>books added to reading lists</b>, and <b>genre preferences</b>, to better personalize recommendations.
            </li>
        </ul>

        <h3 class="text-2xl font-bold mb-4 mt-6 border-b border-amber-600 pb-1">2. Use of Data</h3>
        <p class="font-semibold text-blue-900 mb-2">
             {{ optional($websites[0])->name }} uses the collected data for various purposes:
        </p>
        <ul class="list-disc ml-6 policy-list text-blue-900/90">
            <li>To provide and maintain the service (e.g., managing your account).</li>
            <li>To notify you about changes to our service.</li>
            <li>To allow you to participate in interactive features when you choose to do so.</li>
            <li>To provide customer support and respond to inquiries.</li>
            <li>To provide analysis or valuable information so that we can improve the Service (e.g., understanding popular genres).</li>
            <li>To monitor the usage of the service and prevent technical issues.</li>
        </ul>

        <h3 class="text-2xl font-bold mb-4 mt-6 border-b border-amber-600 pb-1">3. Disclosure of Data</h3>
        <p class="mb-4">
            We may disclose your Personal Data in the good faith belief that such action is necessary to:
        </p>
        <ul class="list-decimal ml-6 policy-list text-blue-900/90">
            <li>Comply with a legal obligation (e.g., government request).</li>
            <li>Protect and defend the rights or property of  {{ optional($websites[0])->name }}.</li>
            <li>Prevent or investigate possible wrongdoing in connection with the Service.</li>
            <li>Protect the personal safety of users of the Service or the public.</li>
        </ul>

        <h3 class="text-2xl font-bold mb-4 mt-6 border-b border-amber-600 pb-1">4. Security of Data</h3>
        <p class="mb-4">
            The security of your data is important to us, but remember that no method of transmission over the Internet or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.
        </p>

        <h3 class="text-2xl font-bold mb-4 mt-6 border-b border-amber-600 pb-1">5. Your Data Protection Rights</h3>
        <p class="mb-4">
            Depending on your location, you may have the right to access, update, or delete the Personal Data we have on you. To exercise these rights, please contact us at <a href="mailto:{{ optional($websites[0])->email }}" class="text-amber-600 hover:underline">{{ optional($websites[0])->email }}</a>.
        </p>

    </section>

</main>
