<?php

use Livewire\Volt\Component;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('Terms & Conditions | Book Buffet')]
 class extends Component {
    //
};
?>

<main class="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">

    <div class="mb-6 text-sm text-gray-500 flex items-center space-x-2">
        <a href="/" class="hover:text-amber-600 transition">Home</a>
        <span class="text-amber-600">/</span>
        <span class="text-blue-900 font-medium">TERMS & CONDITION</span>
    </div>


    <h2 class="text-4xl font-extrabold text-center mb-4">
        Our <span class="text-amber-600">Terms & Conditions</span>
    </h2>
    <p class="text-center text-sm text-blue-900/70 mb-8">
        Last Updated: {{ date_formatter(optional($websites[0])->updated_at) }}
    </p>

    <section class="bg-white p-8 rounded-lg shadow-xl">
        <p class="mb-6">
            Welcome to  {{ optional($websites[0])->name }}! These Terms and Conditions outline the rules and regulations for the use of  {{ optional($websites[0])->name }} 's Website, located at bookbuffet.shop
            By accessing this website, we assume you accept these terms and conditions. Do not continue to use  {{ optional($websites[0])->name }}  if you do not agree to take all of the terms and conditions stated on this page.
            {!! optional($websites[0])->tc !!}
        </p>

        <h3 class="text-2xl font-bold mb-4 mt-6 border-b border-amber-600 pb-1">1. User Accounts</h3>
        <ul class="list-disc ml-6 terms-list text-blue-900/90">
            <li>
                If you create an account on our website, you are responsible for maintaining the security of your account and you are fully responsible for all activities that occur under the account and any other actions taken in connection with it.
            </li>
            <li>
                You must immediately notify  {{ optional($websites[0])->name }}  of any unauthorized uses of your account or any other breaches of security.
            </li>
        </ul>

        <h3 class="text-2xl font-bold mb-4 mt-6 border-b border-amber-600 pb-1">2. Content & Intellectual Property</h3>
        <ul class="list-disc ml-6 terms-list text-blue-900/90">
            <li>
                All content on the  {{ optional($websites[0])->name }}  website, including text, graphics, logos, images, as well as the compilation thereof, and any software used on the Site, is the property of  {{ optional($websites[0])->name }}  or its suppliers and protected by copyright and intellectual property laws.
            </li>
            <li>
                You may not reproduce, distribute, modify, create derivative works of, publicly display, publicly perform, republish, download, store, or transmit any of the material on our Site without prior written consent from  {{ optional($websites[0])->name }} .
            </li>
            <li>
                User-submitted content (like book reviews or forum posts) must be original, respectful, and not violate any laws or third-party rights.  {{ optional($websites[0])->name }}  reserves the right to remove or edit any content it deems inappropriate.
            </li>
        </ul>

        <h3 class="text-2xl font-bold mb-4 mt-6 border-b border-amber-600 pb-1">3. Prohibited Uses</h3>
        <p class="mb-4">
            You may use the website only for lawful purposes and in accordance with these Terms and Conditions. You agree not to use the website:
        </p>
        <ul class="list-decimal ml-6 terms-list text-blue-900/90">
            <li>In any way that violates any applicable national or international law or regulation.</li>
            <li>To transmit, or procure the sending of, any advertising or promotional material, including any "junk mail," "chain letter," "spam," or any other similar solicitation.</li>
            <li>To engage in any other conduct that restricts or inhibits anyone's use or enjoyment of the website, or which, as determined by us, may harm  {{ optional($websites[0])->name }}  or users of the website.</li>
        </ul>

        <h3 class="text-2xl font-bold mb-4 mt-6 border-b border-amber-600 pb-1">4. Disclaimer and Liability</h3>
        <ul class="list-disc ml-6 terms-list text-blue-900/90">
            <li>
                The service and the content are provided on an "as is" basis without any warranties of any kind, express or implied.
            </li>
            <li>
                 {{ optional($websites[0])->name }}  does not warrant that the website will be uninterrupted, timely, secure, or error-free.
            </li>
            <li>
                In no event shall  {{ optional($websites[0])->name }} , nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from (i) your access to or use of or inability to access or use the Service.
            </li>
        </ul>

        <h3 class="text-2xl font-bold mb-4 mt-6 border-b border-amber-600 pb-1">5. Changes</h3>
        <p class="mb-4">
             {{ optional($websites[0])->name }}  reserves the right, at its sole discretion, to modify or replace these Terms at any time. If a revision is material, we will provide at least 30 days' notice prior to any new terms taking effect. By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms.
        </p>

    </section>

</main>

