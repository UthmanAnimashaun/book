<?php

use Livewire\Volt\Component;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('Your Cart | Book Buffet')]
 class extends Component {

    public $cartItems = [];

    public function mount(): void
    {
        $this->fetchCartItems();
    }

    public function fetchCartItems(): void
    {
        $session_id = Session::get('session_id');

        // Eager-load both the product and its nested vendor profile relationship chain securely
        $this->cartItems = Cart::with(['product.vendor'])
            ->where('session_id', $session_id)
            ->get();
    }

    public function increaseQuantity($cartId): void
    {
        $cartItem = Cart::find($cartId);
        if (!$cartItem) return;

        $product = Product::find($cartItem->product_id);

        if ($cartItem->quantity + 1 > $product->stock) {
            $this->dispatch('toast', [
                'title' => 'Stock Limit',
                'message' => 'Only ' . $product->stock . ' copies are available from this vendor.',
                'type' => 'info'
            ]);
            return;
        }

        $cartItem->update(['quantity' => $cartItem->quantity + 1]);
        $this->fetchCartItems();
        $this->dispatch('cartUpdated');
    }

    public function decreaseQuantity($cartId): void
    {
        $cartItem = Cart::find($cartId);
        if (!$cartItem) return;

        if ($cartItem->quantity > 1) {
            $cartItem->update(['quantity' => $cartItem->quantity - 1]);
            $this->fetchCartItems();
            $this->dispatch('cartUpdated');
        }
    }

    public function deleteConfirmed($cartId): void
    {
        Cart::where('id', $cartId)->delete();
        $this->fetchCartItems();
        $this->dispatch('cartUpdated');

        $this->dispatch('toast', [
            'title' => 'Removed',
            'message' => 'Book successfully removed from cart.',
            'type' => 'success'
        ]);
    }
}; ?>

<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">

    {{-- Breadcrumb Navigation Row --}}
    <div class="mb-6 text-sm text-gray-500 flex items-center space-x-2">
        <a href="/" class="hover:text-amber-600 transition">Home</a>
        <span class="text-amber-600">/</span>
        <a href="{{ route('product-shop') }}" class="hover:text-amber-600 transition">Shop</a>
        <span class="text-amber-600">/</span>
        <span class="text-blue-900 font-medium">Your Cart</span>
    </div>

    <h1 class="text-4xl font-extrabold text-blue-900 mb-8">Your Cart</h1>

    @if (count($cartItems) > 0)


        <div id="cart-content" class="grid grid-cols-1 lg:grid-cols-3 gap-8">

            {{-- Left Side: Cart Items Workspace Grid --}}
            <div id="cart-items-container" class="lg:col-span-2 space-y-4">

                {{-- Desktop Table Header row --}}
                <div class="hidden lg:grid grid-cols-[2fr_1fr_1fr_1fr_0.4fr] gap-4 py-3 px-6 bg-white rounded-t-xl shadow-sm text-sm font-semibold text-blue-900 border-b-2 border-amber-600/50">
                    <div>Item Details</div>
                    <div class="text-center">Unit Price</div>
                    <div class="text-center">Quantity</div>
                    <div class="text-right">Subtotal</div>
                    <div></div>
                </div>

                @php $totalPrice = 0; @endphp

                @foreach ($cartItems as $cart)
                    @php
                        $product = $cart->product;
                        $getDiscountPrice = Product::getDiscountPrice($cart->product_id);
                        $finalUnitPrice = $getDiscountPrice['discount'] > 0 ? $getDiscountPrice['final_price'] : $getDiscountPrice['price'];
                        $subtotal = $finalUnitPrice * $cart->quantity;
                        $totalPrice += $subtotal;

                        // Safely extract vendor state data variables
                        $vendorName = $product->vendor->name ?? 'Independent Seller';
                        $vendorState = $product->state ?? ($product->vendor->state ?? 'Unknown Location');
                    @endphp

                    <div class="cart-item-row bg-white p-4 rounded-xl shadow-md border border-gray-100 grid grid-cols-1 lg:grid-cols-[2fr_1fr_1fr_1fr_0.4fr] lg:gap-4 items-center transition-all">

                        {{-- Segment 1: Book Information & Vendor Origin Labels --}}
                        <div class="flex items-center space-x-4 mb-4 lg:mb-0">
                            <img src="{{ asset('storage/images/product_image/medium/' . ($product->image_url ?? 'default.jpg')) }}"
                                 alt="{{ $product->title }}"
                                 class="w-16 h-24 object-cover rounded-lg shadow-sm flex-shrink-0">
                            <div class="min-w-0 flex-1">
                                <h3 class="font-bold text-blue-900 text-base truncate" title="{{ $product->title }}">
                                    <a href="{{ url('product/'.$product->slug) }}" class="hover:text-amber-600 transition">{{ $product->title }}</a>
                                </h3>
                                <p class="text-xs text-gray-400 mt-0.5">Format: <span class="font-medium text-gray-600">{{ ucfirst($product->format ?? 'Unknown') }}</span></p>
                                <p class="text-xs text-gray-500">By: <span class="text-blue-900 font-medium">{{ $product->author ?? 'N/A' }}</span></p>

                                {{-- NEW: Dynamic Multi-Vendor Shipping Identification Tags --}}
                                <div class="mt-2 flex flex-wrap gap-1 items-center text-[11px]">
                                    <span class="bg-blue-50 text-blue-700 font-semibold px-2 py-0.5 rounded-md">🏬 {{ $vendorName }}</span>
                                    <span class="bg-amber-50 text-amber-800 font-medium px-2 py-0.5 rounded-md">📍 Hub: {{ $vendorState }}</span>
                                </div>
                            </div>
                        </div>

                        {{-- Segment 2: Unit Pricing --}}
                        <div class="flex justify-between items-center lg:justify-center text-sm font-medium mb-2 lg:mb-0">
                            <span class="lg:hidden text-gray-500 text-xs uppercase">Unit Price:</span>
                            <div class="text-blue-900 lg:text-center">
                                @if ($getDiscountPrice['discount'] > 0)
                                    <span class="font-bold">₦{{ number_format($getDiscountPrice['final_price'], 0) }}</span>
                                    <del class="text-red-500 text-xs ml-1">₦{{ number_format($getDiscountPrice['price'], 0) }}</del>
                                @else
                                    <span class="font-bold">₦{{ number_format($getDiscountPrice['price'], 0) }}</span>
                                @endif
                            </div>
                        </div>

                        {{-- Segment 3: Quantity Action Adders --}}
                        <div class="flex justify-between items-center lg:justify-center text-sm font-medium mb-2 lg:mb-0">
                            <span class="lg:hidden text-gray-500 text-xs uppercase">Quantity:</span>
                            <div class="flex items-center border border-gray-300 rounded-lg overflow-hidden bg-white shadow-xs">
                                <button type="button" wire:click="decreaseQuantity({{ $cart->id }})"
                                        class="qty-btn text-blue-900 font-bold px-3 py-1 bg-gray-50 hover:bg-gray-100 transition">–</button>
                                <span class="qty-input w-10 text-center font-bold text-blue-900 text-xs border-x border-gray-200 py-1">{{ $cart->quantity }}</span>
                                <button type="button" wire:click="increaseQuantity({{ $cart->id }})"
                                        class="qty-btn text-blue-900 font-bold px-3 py-1 bg-gray-50 hover:bg-gray-100 transition">+</button>
                            </div>
                        </div>

                        {{-- Segment 4: Line Item Subtotal calculations --}}
                        <div class="flex justify-between items-center lg:justify-end text-sm font-medium mb-3 lg:mb-0">
                            <span class="lg:hidden text-gray-500 text-xs uppercase">Subtotal:</span>
                            <span class="item-subtotal text-amber-600 font-extrabold text-base lg:text-right">
                                ₦{{ number_format($subtotal, 0) }}
                            </span>
                        </div>

                        {{-- Segment 5: Row Removal Trigger --}}
                        <div class="flex justify-end lg:justify-center border-t lg:border-t-0 pt-2 lg:pt-0">
                            <button type="button" wire:click="deleteConfirmed({{ $cart->id }})"
                                    wire:confirm="Are you sure you want to remove this book from your cart?"
                                    class="text-gray-400 hover:text-red-600 transition p-2"
                                    aria-label="Remove item">
                                🗑️
                            </button>
                        </div>
                    </div>
                @endforeach
            </div>

            {{-- Right Side: Sticky Checkout Pricing Parameters Overview --}}
            <div class="lg:col-span-1">
                <div class="bg-white p-6 rounded-xl shadow-lg border border-gray-100 space-y-5 sticky top-24">
                    <h2 class="text-2xl font-bold text-blue-900 border-b pb-3">Order Summary</h2>

                    <div class="flex justify-between text-base font-medium">
                        <span class="text-gray-500">Subtotal:</span>
                        <span class="text-blue-900 font-bold">₦{{ number_format($totalPrice, 0) }}</span>
                    </div>

                    <div class="flex flex-col space-y-1 bg-gray-50 p-3 rounded-xl border border-gray-100">
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-500 font-medium">Estimated Delivery:</span>
                            <span class="font-bold text-amber-600">Calculated Next</span>
                        </div>
                        <p class="text-[11px] text-gray-400 leading-normal">
                            Cross-state courier delivery rules apply based on each unique vendor shipping base location.
                        </p>
                    </div>

                    <div class="flex justify-between text-xl font-black border-t border-gray-200 pt-4 text-blue-900">
                        <span>Grand Total:</span>
                        <span class="text-amber-600 text-2xl font-black">₦{{ number_format($totalPrice, 0) }}</span>
                    </div>

                    <a href="{{ route('checkout') }}"
                       class="block w-full text-center bg-amber-600 hover:bg-amber-700 text-white font-bold py-3.5 rounded-xl transition duration-200 shadow-md transform active:scale-[0.99]">
                        Proceed to Checkout &rarr;
                    </a>
                </div>
            </div>
        </div>
    @else
        {{-- Empty State Template Fallback block --}}
        <div id="empty-cart-message" class="text-center py-20 bg-white rounded-xl shadow-lg border border-gray-100">
            <span class="text-6xl block mb-4">📦</span>
            <h2 class="text-2xl font-bold text-blue-900 mb-2">Your cart is empty.</h2>
            <p class="text-gray-500 text-sm mb-6 max-w-sm mx-auto">Browse our multi-vendor collections to discover your next favorite read!</p>
            <a href="{{ route('product-shop') }}"
               class="inline-block bg-blue-900 hover:bg-amber-600 text-white font-bold py-3 px-8 rounded-full transition duration-150 shadow-md">
                Go to Shop
            </a>
        </div>
    @endif

       @script
        <script>
            // Butterup toast listener
            $wire.on('toast', ([data]) => {
                butterup.toast({
                    title: data.title,
                    message: data.message,
                    type: data.type,
                    location: 'top-right',
                    icon: true
                });
            });

        </script>
        @endscript
</main>
