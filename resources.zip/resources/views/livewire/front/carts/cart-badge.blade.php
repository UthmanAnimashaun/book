<?php

use Livewire\Volt\Component;

use App\Models\Cart;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
new class extends Component {

    public $totalCartItems = 0;

    protected $listeners = ['cartUpdated' => 'updateCartCount'];

    public function mount()
    {
        $this->updateCartCount();

    }

    public function updateCartCount()
    {

        $this->totalCartItems = Cart::getCartItems()->sum('quantity');

    }


}; ?>


<div>
{{ $totalCartItems }}

</div>
