<?php

use Livewire\Volt\Component; // Ensure Volt component is used for SFCs
use Livewire\WithPagination;
use App\Models\Order;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session; // Fixed missing import
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Attributes\Lazy; // For native lazy loading

new #[Layout('layouts.front.app')]
#[Title('My Orders | Book Buffet')]
//#[Lazy] // Clean Livewire 3 lazy loading declaration
class extends Component {
    use WithPagination;

    // Fixed: Declaring the public property so it is accessible in your template
    public $orders = [];

    public function mount(): void
    {
        Session::put('page', 'Orders');

        // Fixed: Added 'product_image' to the select constraints so it renders in blade
        $this->orders = Order::with(['orders_products' => function($query) {
            $query->select('id', 'order_id', 'product_name', 'product_qty', 'product_format');
        }])
        ->where('user_id', Auth::id())
        ->latest()
        ->get();
    }
};
?>

<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
    <h1 class="text-4xl font-extrabold text-blue-900 mb-8">My Orders</h1>

    <section id="orders-list" class="space-y-6">
        {{-- Table Header for Large Screens --}}
        <div class="hidden lg:grid grid-cols-[1fr_1fr_1fr_2fr_1fr_0.5fr] gap-4 py-3 px-6 bg-white rounded-t-xl shadow-sm text-sm font-semibold text-blue-900 border-b-2 border-amber-600/50">
            <span>Order ID</span>
            <span>Date</span>
            <span>Total Amount</span>
            <span>Product Details</span>
            <span>Status</span>
            <span>Action</span>
        </div>

        @forelse ($orders as $index => $order)
            <div class="order-item bg-white p-4 rounded-xl shadow-md border border-gray-100 grid grid-cols-2 lg:grid-cols-[1fr_1fr_1fr_2fr_1fr_0.5fr] gap-y-3 lg:gap-4 items-center">

                {{-- Order ID --}}
                <div class="font-bold text-blue-900 col-span-1 lg:col-span-1" data-label="Order ID">
                    #{{ $index + 1 }}
                </div>

                {{-- Date --}}
                <div class="text-gray-600 text-sm col-span-1 lg:col-span-1" data-label="Date">
                    {{ $order->created_at->format('M d, Y') }}
                </div>

                {{-- Total Amount --}}
                <div class="text-lg font-bold text-amber-600 col-span-1 lg:col-span-1 flex justify-start" data-label="Total">
                    ₦{{ number_format($order->grand_total, 0) }}
                </div>

                {{-- Products Column --}}
                <div class="col-span-2 lg:col-span-1 space-y-2">
                    @foreach ($order->orders_products as $product)
                        <div class="p-3 bg-gray-50 rounded-lg border border-gray-200 shadow-sm flex items-center justify-between space-x-4">

                            {{-- Product Info --}}
                            <div class="flex-1 min-w-0">
                                <h4 class="font-semibold text-gray-800 text-sm line-clamp-2">
                                    {{ $product->product_name }}
                                </h4>
                                <p class="text-gray-500 text-xs mt-1">
                                    <span class="font-medium">Format:</span> {{ $product->product_format }}
                                </p>
                                <p class="text-gray-500 text-xs mt-0.5">
                                    <span class="font-medium">Qty:</span> {{ $product->product_qty }}
                                </p>
                            </div>

                            {{-- Product Image --}}
                            @if(!empty($product->product_image))
                                <div class="flex-shrink-0">
                                    <img src="/storage/images/product_image/small/{{ $product->product_image }}"
                                         alt="{{ $product->product_name }}"
                                         class="w-12 h-16 object-cover rounded-md shadow-sm border">
                                </div>
                            @endif
                        </div>
                    @endforeach
                </div>

                {{-- Status --}}
                <div class="col-span-1 lg:col-span-1 flex justify-start" data-label="Status">
                    @php
                        $statusColors = [
                            'Delivered' => 'bg-green-100 text-green-700',
                            'Shipped' => 'bg-indigo-100 text-indigo-700',
                            'Cancelled' => 'bg-red-100 text-red-700',
                            'Pending' => 'bg-yellow-100 text-yellow-700',
                        ];
                    @endphp
                    <span class="px-3 py-1 text-xs font-semibold rounded-full {{ $statusColors[$order->order_status] ?? 'bg-gray-100 text-gray-700' }}">
                        {{ $order->order_status }}
                    </span>
                </div>

                {{-- Action --}}
                <div class="col-span-1 lg:col-span-1 flex justify-end lg:justify-start">
                    <a href="{{ route('user.orders.show', $order->id) }}"
                       class="bg-amber-600 hover:bg-amber-700 text-white text-sm px-4 py-1.5 rounded-lg transition duration-150 shadow-sm whitespace-nowrap">
                        View Details
                    </a>
                </div>

            </div>
        @empty
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 py-12 text-center">
                <p class="text-gray-500 text-base">You haven’t placed any orders yet.</p>
            </div>
        @endforelse
    </section>
           @script
    <script>
        // Butterup toast listener
        $wire.on('toast', ([data]) => {
            butterup.toast({
                title: data.title,
                message: data.message,
                type: data.type,
                location: 'top-right',
                icon: true
            });
        });
    </script>
     @endscript
</main>
