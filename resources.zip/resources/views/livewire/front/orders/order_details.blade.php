<?php

use Livewire\Volt\Component;
use App\Models\Order;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('Order Details | Book Buffet')]
 class extends Component {
    // Livewire 3 automatically resolves route parameters (like {order})
    // and binds them straight into matching public type-hinted properties.
    public Order $order;

    public function mount(): void
    {
        // Eager load relationships right away to prevent N+1 query patterns
        $this->order->load(['orders_products.products']);
    }

    public function downloadInvoice()
    {
        return redirect()->route('user.orders.invoice', ['order' => $this->order->id]);
    }
}; ?>

<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">

    <div class="flex items-center justify-between mb-6">
        <h1 class="text-4xl font-extrabold text-blue-900">Order Details</h1>
        <a href="{{ route('user.orders') }}"
            class="text-amber-600 hover:underline font-medium flex items-center transition duration-150">
            <span class="mr-2">⬅️</span> Back to Orders
        </a>
    </div>

    {{-- Order Metadata Overview --}}
    <section id="order-info-card" class="bg-white shadow-lg rounded-xl p-6 mb-8 border border-gray-100">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 pb-4 border-b border-gray-200 mb-4">
            <div>
                <p class="text-sm text-gray-500">Order ID</p>
                <p class="font-bold text-blue-900 text-lg">#{{ $order->id }}</p>
            </div>
            <div>
                <p class="text-sm text-gray-500">Order Date</p>
                <p class="font-medium text-gray-700 text-lg">{{ date_formatter($order->created_at) }}</p>
            </div>
            <div>
                <p class="text-sm text-gray-500">Status</p>
                <p class="font-medium text-gray-700 text-lg">
                    @php
                        $statusColors = [
                            'Delivered' => 'bg-green-100 text-green-700',
                            'Shipped' => 'bg-indigo-100 text-indigo-700',
                            'Cancelled' => 'bg-red-100 text-red-700',
                            'Pending' => 'bg-yellow-100 text-yellow-700',
                        ];
                    @endphp
                    <span class="px-3 py-1 font-semibold rounded-full {{ $statusColors[$order->order_status] ?? 'bg-gray-100 text-gray-700' }}">
                        {{ $order->order_status }}
                    </span>
                </p>
            </div>
            <div>
                <p class="text-sm text-gray-500">Delivery State</p>
                <p class="font-medium text-gray-700 text-lg">{{ $order->state }}</p>
            </div>
        </div>

        <div class="relative pt-6">
            <div class="flex justify-between items-center relative text-xs md:text-sm">
                <div id="tracker-progress-line" class="tracker-line bg-gray-200"></div>
                <div id="tracker-steps" class="flex justify-between w-full">
                    {{-- Future tracking steps placeholder --}}
                </div>
            </div>
        </div>
    </section>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 space-y-6">

            {{-- Ordered Items Block --}}
            <section id="ordered-items-card" class="bg-white shadow-lg rounded-xl p-6 border border-gray-100">
                <h2 class="text-2xl font-bold text-blue-900 mb-4 border-b pb-3">📚 Ordered Items</h2>

                <div class="space-y-4">
                    @foreach ($order->orders_products as $item)
                        <div class="flex items-center border-b pb-4 last:border-b-0 last:pb-0">
                            @php
                                $product_image = $item->products && $item->products->image_url
                                    ? '/storage/images/product_image/medium/' . $item->products->image_url
                                    : '/storage/images/product_image/medium/default.jpg';
                            @endphp

                            @if($item->products)
                                <a href="{{ route('product.detail', $item->products->slug) }}">
                                    <img src="{{ asset($product_image) }}" alt="{{ $item->product_name }}"
                                        class="w-12 h-18 object-cover rounded shadow-sm mr-4">
                                </a>
                            @else
                                <img src="{{ asset($product_image) }}" alt="{{ $item->product_name }}"
                                    class="w-12 h-18 object-cover rounded shadow-sm mr-4">
                            @endif

                            <div class="flex-grow grid grid-cols-3 md:grid-cols-4 gap-2 items-center">
                                @if($item->products)
                                    <a href="{{ route('product.detail', $item->products->slug) }}"
                                        class="font-semibold text-blue-900 truncate col-span-3 md:col-span-1 hover:text-amber-600 transition">
                                        {{ $item->product_name }}
                                    </a>
                                @else
                                    <span class="font-semibold text-blue-900 truncate col-span-3 md:col-span-1">
                                        {{ $item->product_name }}
                                    </span>
                                @endif

                                <div class="text-sm text-gray-600 col-span-1">Qty: <span class="font-medium">{{ $item->product_qty }}</span></div>
                                <div class="text-sm text-gray-600 col-span-1">Price: <span class="font-medium">₦{{ number_format($item->product_price, 0) }}</span></div>

                                <div class="text-sm text-gray-600 col-span-1">Status:
                                    @php
                                        $itemStatusColors = [
                                            'Delivered' => 'bg-green-100 text-green-700',
                                            'Shipped' => 'bg-indigo-100 text-indigo-700',
                                            'Cancelled' => 'bg-red-100 text-red-700',
                                            'Pending' => 'bg-yellow-100 text-yellow-700',
                                        ];
                                    @endphp
                                    <span class="px-3 py-1 text-xs font-semibold rounded-full {{ $itemStatusColors[$item->item_status] ?? 'bg-gray-100 text-gray-700' }}">
                                        {{ $item->item_status ?? "New" }}
                                    </span>
                                </div>

                                <div class="text-base font-semibold text-amber-600 col-span-1 text-right">
                                    Total: ₦{{ number_format($item->product_price * $item->product_qty, 0) }}
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </section>

            {{-- Shipping Info Card --}}
            <section id="delivery-info-card" class="bg-white shadow-lg rounded-xl p-6 border border-gray-100">
                <h2 class="text-2xl font-bold text-blue-900 mb-4 border-b pb-3">🚚 Delivery Information</h2>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 text-gray-700">
                    <div>
                        <p class="text-sm text-gray-500">Recipient</p>
                        <p class="font-medium">{{ $order->name }}</p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Email</p>
                        <p class="font-medium">{{ $order->email }}</p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Phone</p>
                        <p class="font-medium">{{ $order->mobile }}</p>
                    </div>
                    <div class="md:col-span-2">
                        <p class="text-sm text-gray-500">Full Address</p>
                        <p class="font-medium">{{ $order->address }}, {{ $order->city }}, {{ $order->state }}</p>
                    </div>
                    @if (!empty($order->notes))
                        <div class="md:col-span-2 mt-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
                            <p class="text-sm text-gray-500 font-medium mb-1">Additional Notes</p>
                            <p class="text-sm italic">{{ $order->notes }}</p>
                        </div>
                    @endif
                </div>
            </section>
        </div>

        {{-- Payment/Pricing Summary --}}
        <div class="lg:col-span-1">
            <section id="summary-card" class="bg-white shadow-lg rounded-xl p-6 border border-gray-100 sticky top-24">
                <h2 class="text-2xl font-bold text-blue-900 mb-4 border-b pb-3">💰 Payment Summary</h2>

                <div class="space-y-3">
                    <div class="flex justify-between text-base">
                        <span>Subtotal:</span>
                        <span class="font-medium text-gray-700">
                            ₦{{ number_format($order->grand_total - $order->shipping_charges, 0) }}
                        </span>
                    </div>
                    <div class="flex justify-between text-base">
                        <span>Delivery Fee ({{ $order->state }}):</span>
                        <span class="font-medium text-gray-700">₦{{ number_format($order->shipping_charges, 0) }}</span>
                    </div>
                    <div class="flex justify-between text-xl font-bold border-t border-gray-300 pt-4">
                        <span>Total Amount:</span>
                        <span class="text-amber-600">₦{{ number_format($order->grand_total, 0) }}</span>
                    </div>
                </div>


                  <a href="{{ route('user.orders.invoice', $order->id) }}"
                    class="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 rounded-lg mt-6 transition duration-300 shadow-md flex items-center justify-center"
                    target="_blank">
                    <i class=" mr-2">📄</i> Download Invoice
                </a>
            </section>
        </div>
    </div>
</main>
