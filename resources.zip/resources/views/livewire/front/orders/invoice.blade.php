<?php

use Livewire\Volt\Component;

new class extends Component
{
    //
};
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice - #{{ $order->id }}</title>
    <style>
        @page {
            margin: 20px 30px;
        }
        body {
            font-family: 'DejaVu Sans', sans-serif; /* Ensures native currency symbol support (₦) */
            font-size: 12px;
            line-height: 1.4;
            color: #374151;
            background-color: #fff;
        }

        /* Structural Layout Table */
        .w-full {
            width: 100%;
        }
        table {
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        /* Header Details Styling */
        .invoice-title {
            font-size: 28px;
            font-weight: bold;
            color: #1e3a8a;
            line-height: 1;
        }
        .company-brand {
            font-size: 22px;
            font-weight: bold;
            color: #1e3a8a;
            text-align: right;
        }
        .company-tagline {
            font-size: 11px;
            color: #d97706;
            text-align: right;
        }

        .meta-box {
            background-color: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            padding: 12px;
        }
        .meta-label {
            font-size: 11px;
            color: #6b7280;
            text-transform: uppercase;
        }
        .meta-value {
            font-size: 14px;
            font-weight: bold;
            color: #1e3a8a;
        }

        /* Section Headings */
        .section-header {
            font-size: 14px;
            font-weight: bold;
            color: #1e3a8a;
            border-bottom: 2px solid #e5e7eb;
            padding-bottom: 5px;
            margin-bottom: 10px;
        }

        /* Data Tables styling */
        .table-items th {
            background-color: #1e3a8a;
            color: #ffffff;
            font-weight: bold;
            text-align: left;
            padding: 8px;
            font-size: 11px;
        }
        .table-items td {
            padding: 10px 8px;
            border-bottom: 1px solid #e5e7eb;
            vertical-align: middle;
        }
        .item-image {
            width: 40px;
            height: 55px;
            object-fit: cover;
            border-radius: 4px;
        }

        /* Calculation Blocks alignment */
        .totals-table {
            width: 250px;
            float: right;
        }
        .totals-table td {
            padding: 4px 0;
        }
        .total-row {
            font-size: 15px;
            font-weight: bold;
            color: #d97706;
            border-top: 1px solid #d1d5db;
            padding-top: 6px !important;
        }
        .clear {
            clear: both;
        }

        /* Badges status matching */
        .status-badge {
            padding: 2px 8px;
            font-weight: bold;
            font-size: 10px;
            border-radius: 10px;
            display: inline-block;
        }
        .status-Delivered { background-color: #d1fae5; color: #047857; }
        .status-Shipped   { background-color: #e0e7ff; color: #4338ca; }
        .status-Cancelled { background-color: #fee2e2; color: #b91c1c; }
        .status-Pending   { background-color: #fef3c7; color: #b45309; }

        .notes-box {
            background-color: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            padding: 10px;
            margin-top: 15px;
            font-style: italic;
        }
    </style>
</head>
<body>

    <table class="w-full">
        <tr>
            <td style="vertical-align: top;">
                <div class="invoice-title">INVOICE</div>
                <div style="color: #6b7280; margin-top: 4px;">Order Status:
                    <span class="status-badge status-{{ $order->order_status }}">{{ $order->order_status }}</span>
                </div>
            </td>
            <td style="vertical-align: top; text-align: right;">
                <div class="company-brand">BookBuffet</div>
                <div class="company-tagline">Where Readers Meet Knowledge</div>
            </td>
        </tr>
    </table>

    <br>

    <table class="w-full" style="margin-bottom: 25px;">
        <tr>
            <td width="48%" class="meta-box" style="vertical-align: top;">
                <div class="meta-label">Order Details</div>
                <div style="margin-top: 5px;">
                    <strong>Order ID:</strong> #{{ $order->id }}<br>
                    <strong>Date:</strong> {{ date_formatter($order->created_at) }}<br>
                    <strong>Delivery State:</strong> {{ $order->state }}
                </div>
            </td>
            <td width="4%"></td> <td width="48%" class="meta-box" style="vertical-align: top;">
                <div class="meta-label">Shipping Address</div>
                <div style="margin-top: 5px;">
                    <strong>{{ $order->name }}</strong><br>
                    {{ $order->address }}, {{ $order->city }}, {{ $order->state }}<br>
                    <strong>Phone:</strong> {{ $order->mobile }}<br>
                    <strong>Email:</strong> {{ $order->email }}
                </div>
            </td>
        </tr>
    </table>

    <div class="section-header">Ordered Items</div>
    <table class="w-full table-items">
        <thead>
            <tr>
                <th width="8%">Image</th>
                <th width="47%">Product Details</th>
                <th width="10%" style="text-align: center;">Qty</th>
                <th width="15%" style="text-align: right;">Unit Price</th>
                <th width="20%" style="text-align: right;">Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($order->orders_products as $item)
                <tr>
                    <td>
                        @php
                            // CRITICAL: Dompdf requires system path strings (public_path) rather than absolute HTTP asset urls
                            $imageName = ($item->products && $item->products->image_url) ? $item->products->image_url : 'default.jpg';
                            $imagePath = public_path('storage/images/product_image/medium/' . $imageName);
                        @endphp
                        @if(file_exists($imagePath))
                            <img src="{{ $imagePath }}" class="item-image" alt="Cover">
                        @else
                            <div style="width: 40px; height: 55px; background: #e5e7eb; border-radius: 4px;"></div>
                        @endif
                    </td>
                    <td>
                        <div style="font-weight: bold; color: #1e3a8a;">{{ $item->product_name }}</div>
                        @if($item->products && isset($item->products->author))
                            <div style="font-size: 11px; color: #6b7280;">by {{ $item->products->author }}</div>
                        @endif
                        <div style="font-size: 10px; margin-top: 3px;">
                            Status: <span style="font-weight: bold;">{{ $item->item_status ?? 'Processed' }}</span>
                        </div>
                    </td>
                    <td style="text-align: center;">{{ $item->product_qty }}</td>
                    <td style="text-align: right;">₦{{ number_format($item->product_price, 0) }}</td>
                    <td style="text-align: right; font-weight: bold; color: #1e3a8a;">
                        ₦{{ number_format($item->product_price * $item->product_qty, 0) }}
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <table class="w-full" style="margin-top: 15px;">
        <tr>
            <td width="55%" style="vertical-align: top;">
                @if (!empty($order->notes))
                    <div class="notes-box">
                        <div style="font-weight: bold; font-size: 11px; margin-bottom: 3px; color: #1e3a8a; font-style: normal;">
                            Customer Notes:
                        </div>
                        "{{ $order->notes }}"
                    </div>
                @endif
            </td>
            <td width="45%" style="vertical-align: top;">
                <table class="totals-table w-full">
                    <tr>
                        <td style="color: #6b7280;">Subtotal:</td>
                        <td style="text-align: right; font-weight: 500;">
                            ₦{{ number_format($order->grand_total - $order->shipping_charges, 0) }}
                        </td>
                    </tr>
                    <tr>
                        <td style="color: #6b7280;">Delivery Fee:</td>
                        <td style="text-align: right; font-weight: 500;">
                            ₦{{ number_format($order->shipping_charges, 0) }}
                        </td>
                    </tr>
                    <tr>
                        <td class="total-row">Total Paid:</td>
                        <td class="total-row" style="text-align: right;">
                            ₦{{ number_format($order->grand_total, 0) }}
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

</body>
</html>
