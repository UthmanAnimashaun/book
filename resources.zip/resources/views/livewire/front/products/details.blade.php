<?php

use Livewire\Volt\Component;
use App\Models\Product;
use App\Models\Admin;
use App\Models\Cart;
use App\Models\Category;
use App\Models\Rating;
use App\Models\DeliveryFee;
use App\Models\State;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('Book Details | Book Buffet')]
class extends Component {

    // Core parameters
    public $product;
    public $vendor;
    public $images = [];
    public $mainImage;
    public $quantity = 1;
    public $getCartItems = 0;

    // Delivery parameters
    public $states = [];
    public $selectedState = "";
    public $deliveryFeePerKg;
    public $estimatedFee;
    public $isLocationMismatched = false;

    // Recommendation collections
    public $categoryDetails;
    public $similarProducts = [];
    public $recentViewedProducts = [];

    public function mount($slug): void
    {
        $this->product = Product::with(['section', 'category', 'images'])->where('slug', $slug)->firstOrFail();
        $this->categoryDetails = Category::categoryDetails($this->product->category->category_slug);

        $this->vendor = Admin::find($this->product->admin_id ?? null);
        $this->images = $this->getProductImages();
        $this->mainImage = $this->images[0] ?? '/storage/images/product_image/large/' . $this->product->image_url;

        $this->states = State::orderBy('name')->pluck('name')->toArray();

        if (Auth::check() && $default = Auth::user()->defaultAddress) {
            $this->selectedState = $default->state;
        } else {
            $this->selectedState = "Abia State";
        }

        $this->calculateDelivery();

        // Load Slider Data Methods securely on mount
        $this->loadRecentlyViewedPipeline($this->product->id, $this->product->slug);
        $this->loadSimilarProductsPipeline();
    }

    private function getProductImages(): array
    {
        $images = [];
        if (!empty($this->product->image_url)) {
            $images[] = '/storage/images/product_image/large/' . $this->product->image_url;
        }
        if ($this->product->images && $this->product->images->count() > 0) {
            foreach ($this->product->images as $img) {
                $images[] = '/storage/images/product_image/additionals/_resized_' . $img->images;
            }
        }
        return $images;
    }

    public function switchImage($image): void
    {
        $this->mainImage = $image;
    }

    public function incrementQty(): void
    {
        $this->quantity++;
    }

    public function decrementQty(): void
    {
        if ($this->quantity > 1) {
            $this->quantity--;
        }
    }

    public function updatedSelectedState(): void
    {
        $this->calculateDelivery();
    }

    public function calculateDelivery(): void
    {
        $fee = DeliveryFee::where('vendor_id', $this->product->admin_id)
            ->where('state', $this->selectedState)
            ->first();

        $this->deliveryFeePerKg = $fee ? $fee->price_per_kg : null;
        $this->estimatedFee = $this->deliveryFeePerKg;

        $vendorState = $this->product->state ?? ($this->vendor->state ?? null);
        if (!empty($this->selectedState) && !empty($vendorState)) {
            $cleanCustomerState = str_replace('state', '', strtolower(trim($this->selectedState)));
            $cleanVendorState = str_replace('state', '', strtolower(trim($vendorState)));

            $this->isLocationMismatched = (trim(preg_replace('/\s+/', ' ', $cleanCustomerState)) !== trim(preg_replace('/\s+/', ' ', $cleanVendorState)));
        } else {
            $this->isLocationMismatched = false;
        }
    }

    /**
     * Pipeline handles logging the view event and fetching history records
     */
    private function loadRecentlyViewedPipeline($id, $slug): void
    {
        $sessionId = Session::get('session_id') ?? md5(uniqid(rand(), true));
        Session::put('session_id', $sessionId);

        // Update tracking matrix or log new history entry cleanly
        DB::table('recently_viewed_products')->updateOrInsert(
            ['product_id' => $id, 'session_id' => $sessionId],
            ['product_id' => $id, 'session_id' => $sessionId, 'product_slug' => $slug]
        );

        // Gather lookups omitting current focus item
        $ids = DB::table('recently_viewed_products')
            ->where('session_id', $sessionId)
            ->where('product_id', '!=', $id)
            ->latest('id')
            ->take(8)
            ->pluck('product_id');

        $this->recentViewedProducts = Product::with(['vendor'])->whereIn('id', $ids)->get();
    }

    /**
     * Pipeline populates relevant categorizations alternatives
     */
    private function loadSimilarProductsPipeline(): void
    {
        $this->similarProducts = Product::with(['vendor'])
            ->where('category_id', $this->product->category_id)
            ->where('id', '!=', $this->product->id)
            ->where('status', 1)
            ->inRandomOrder()
            ->take(8)
            ->get();
    }

    public function addToCart(): void
    {
        if ($this->isLocationMismatched) {
            $this->dispatch('toast', ['title' => 'Cart Blocked', 'message' => 'Vendor cannot deliver to this state.', 'type' => 'error']);
            return;
        }

        if ($this->quantity > $this->product->stock || $this->quantity <= 0) {
            $this->dispatch('toast', ['title' => 'Error', 'message' => 'Invalid quantity parameters requested.', 'type' => 'error']);
            return;
        }

        $session_id = Session::get('session_id') ?? Session::getId();
        Session::put('session_id', $session_id);
        $user_id = Auth::check() ? Auth::id() : 0;

        $exists = Cart::where('product_id', $this->product->id)
            ->when(Auth::check(), fn($q) => $q->where('user_id', $user_id))
            ->when(!Auth::check(), fn($q) => $q->where('session_id', $session_id))
            ->exists();

        if ($exists) {
            $this->dispatch('toast', ['title' => 'Already In Cart', 'message' => 'This book is already in your cart!', 'type' => 'info']);
            return;
        }

        Cart::create([
            'product_id' => $this->product->id,
            'user_id' => $user_id,
            'session_id' => $session_id,
            'quantity' => $this->quantity,
        ]);

        $this->getCartItems = Cart::getCartItems();
        $this->dispatch('cartUpdated');
        $this->dispatch('toast', ['title' => 'Added!', 'message' => 'Book successfully added to cart!', 'type' => 'success']);
    }

    public function with(): array
    {
        return [
            'reviews' => Rating::where('product_id', $this->product->id)->where('status', 1)->latest()->take(5)->get()
        ];
    }
}; ?>

<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">

    {{-- Breadcrumb Navigation Row --}}
    <div class="mb-8 text-sm text-gray-500 flex items-center space-x-2">
        <a href="/" class="hover:text-amber-600 transition">Home</a>
        <span class="text-amber-600">/</span>
        <a href="/shop" class="hover:text-amber-600 transition">Shop</a>
        <span class="text-amber-600">/</span>
        <span class="text-gray-400">{{ $product['section']['name'] }}</span>
        <span class="text-amber-600">/</span>
        <span class="text-gray-400">{{ $product['category']['category_name'] }}</span>
        <span class="text-amber-600">/</span>
        <span class="text-blue-900 font-medium truncate max-w-[180px] sm:max-w-full">{{ $product->title }}</span>
    </div>

    {{-- Product Workspace Grid Matrix --}}
    <div class="bg-white p-6 md:p-10 rounded-xl shadow-lg border border-gray-100 grid grid-cols-1 lg:grid-cols-2 gap-10">
        {{-- Left Column: Image Media Gallery Layout --}}
        <div class="space-y-6">
            <div class="h-96 md:h-[550px] bg-gray-50 rounded-lg shadow-md overflow-hidden border border-gray-100">
                <img src="{{ asset($mainImage) }}" alt="{{ $product->title }} Display Cover" class="w-full h-full object-cover">
            </div>
            <div class="flex flex-wrap gap-4 justify-start">
                @foreach ($images as $img)
                    <button wire:click="switchImage('{{ $img }}')" class="w-20 h-24 bg-gray-50 rounded-lg overflow-hidden border-2 {{ $mainImage == $img ? 'border-amber-600 shadow-sm' : 'border-gray-200' }} transition">
                        <img src="{{ asset($img) }}" alt="Thumbnail" class="w-full h-full object-cover">
                    </button>
                @endforeach
            </div>
        </div>

        {{-- Right Column: Information & Actions --}}
        <div class="space-y-6">
            <div>
                <h1 class="text-3xl md:text-4xl font-extrabold text-blue-900 leading-tight">
                    {{ $product->title }} <span class="text-lg font-medium text-gray-400">({{ ucfirst($product->format) }})</span>
                </h1>
                <p class="text-base font-semibold text-gray-700 mt-1">
                    By: <a href="{{ route('vendors') }}" class="text-amber-600 hover:underline">{{ $product->author }}</a>
                </p>
            </div>

            <div class="p-4 bg-blue-50/40 rounded-xl border border-blue-100 text-xs sm:text-sm text-gray-600 space-y-1.5">
                <p class="flex items-center space-x-2">
                    <span>🏬</span>
                    <span><strong>Sold by:</strong>
                        @if($vendor)
                            <a href="{{ url('vendor/'.$vendor->slug) }}" class="font-bold text-blue-900 hover:underline">{{ $vendor->name }}</a>
                        @else
                            <span class="font-bold text-gray-400">Unknown Vendor</span>
                        @endif
                    </span>
                </p>
                <p class="flex items-center space-x-2">
                    <span>📍</span>
                    <span><strong>Vendor Shipping Base:</strong> {{ $product->state ?? ($vendor->state ?? 'Unknown') }}</span>
                </p>
            </div>

            {{-- Inventory Status Badge --}}
            <div>
                @if ($product->stock > 0)
                    @if ($product->stock < 6)
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-700 uppercase tracking-wide animate-pulse">
                            🚨 Only {{ $product->stock }} copies remaining!
                        </span>
                    @else
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700 uppercase">✓ In Stock</span>
                    @endif
                @else
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-600 uppercase">❌ Out of Stock</span>
                @endif
            </div>

            {{-- Price Display --}}
            <div class="py-4 border-t border-b border-gray-100 flex items-baseline space-x-3">
                @if ($product->discount)
                    <span class="text-3xl font-black text-amber-600">₦{{ number_format($product->price - ($product->price * $product->discount / 100)) }}</span>
                    <span class="text-sm text-gray-400 line-through">₦{{ number_format($product->price, 0) }}</span>
                    <span class="text-xs font-bold text-red-600 bg-red-50 px-2.5 py-1 rounded-md">({{ $product->discount }}% OFF)</span>
                @else
                    <span class="text-3xl font-black text-blue-900">₦{{ number_format($product->price, 0) }}</span>
                @endif
            </div>

            {{-- Delivery Availability Scanner Caution Sign --}}
            <div class="p-4 rounded-xl border {{ $isLocationMismatched ? 'bg-red-50/60 border-red-300' : 'bg-gray-50 border-gray-200' }} space-y-3">
                <div class="flex items-center justify-between">
                    <label for="check-state" class="block text-xs font-bold uppercase text-gray-500">🚩 Check Delivery Availability:</label>
                    @if($isLocationMismatched)
                        <span class="text-[10px] font-bold bg-red-600 text-white px-2 py-0.5 rounded uppercase tracking-wider animate-pulse">Delivery Lock</span>
                    @elseif(!empty($selectedState))
                        <span class="text-[10px] font-bold bg-green-600 text-white px-2 py-0.5 rounded uppercase tracking-wider">Passes Check</span>
                    @endif
                </div>
                <select id="check-state" wire:model.live="selectedState" class="w-full text-sm rounded-xl border border-gray-300 px-3 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-amber-600">
                    <option value="">-- Choose Your Destination State --</option>
                    @foreach($states as $st)
                        <option value="{{ $st }}">{{ $st }}</option>
                    @endforeach
                </select>
                @if($isLocationMismatched)
                    <div class="text-xs text-red-700 font-semibold flex items-start space-x-1.5 pt-0.5">
                        <span>⚠️</span>
                        <span>Caution: This book ships from <strong>{{ $product->state ?? ($vendor->state ?? 'origin') }}</strong> and cannot be delivered to <strong>{{ $selectedState }}</strong> due to cross-state checkout limits.</span>
                    </div>
                @elseif(!empty($selectedState))
                    <div class="text-xs text-green-700 font-medium flex items-center space-x-1.5 pt-0.5">
                        <span>✅</span>
                        <span>Excellent! This item is available for standard delivery to <strong>{{ $selectedState }}</strong>.</span>
                    </div>
                @endif
            </div>

            @if ($product->stock > 0)
                <div class="flex items-center space-x-4 pt-1" wire:key="action-controls-{{ $selectedState }}">
                    <span class="font-bold text-sm text-blue-900">Quantity:</span>
                    <div class="flex items-center border border-gray-300 rounded-xl overflow-hidden bg-white">
                        <button type="button" wire:click="decrementQty" :disabled="$wire.isLocationMismatched" class="px-3 py-1.5 bg-gray-50 hover:bg-gray-100 font-bold text-gray-600 disabled:opacity-40">–</button>
                        <input type="text" value="{{ $quantity }}" readonly class="w-12 text-center border-none font-bold text-sm text-blue-900 focus:ring-0 bg-white">
                        <button type="button" wire:click="incrementQty" :disabled="$wire.isLocationMismatched" class="px-3 py-1.5 bg-gray-50 hover:bg-gray-100 font-bold text-gray-600 disabled:opacity-40">+</button>
                    </div>
                </div>

                <div class="pt-2">
                    <button wire:click="addToCart" @if($isLocationMismatched || empty($selectedState)) disabled @endif
                        class="w-full sm:w-2/3 font-bold py-3.5 px-8 rounded-xl transition shadow-md flex items-center justify-center space-x-2 text-white {{ ($isLocationMismatched || empty($selectedState)) ? 'bg-gray-300 cursor-not-allowed shadow-none text-gray-400' : 'bg-amber-600 hover:bg-amber-700' }}">
                        <span>
                            @if(empty($selectedState)) 📍 Choose Destination State
                            @elseif($isLocationMismatched) ❌ Delivery Unavailable
                            @else 🛒 Add to Cart @endif
                        </span>
                    </button>
                </div>
            @endif
        </div>
    </div>

    {{-- Core Specification Tabs Component Layout --}}
    <div x-data="{ currentTab: 'delivery' }" class="mt-12 bg-white p-6 md:p-10 rounded-xl shadow-lg border border-gray-100">
        <div class="flex border-b border-gray-200 mb-6 overflow-x-auto whitespace-nowrap scrollbar-none">
            <button @click="currentTab = 'delivery'" :class="currentTab === 'delivery' ? 'border-b-2 border-amber-600 text-amber-600 font-bold' : 'text-gray-400 hover:text-blue-900'" class="px-6 py-3 text-sm font-medium transition">Delivery & Shipping</button>
            <button @click="currentTab = 'description'" :class="currentTab === 'description' ? 'border-b-2 border-amber-600 text-amber-600 font-bold' : 'text-gray-400 hover:text-blue-900'" class="px-6 py-3 text-sm font-medium transition">About This Book</button>
            <button @click="currentTab = 'vendor'" :class="currentTab === 'vendor' ? 'border-b-2 border-amber-600 text-amber-600 font-bold' : 'text-gray-400 hover:text-blue-900'" class="px-6 py-3 text-sm font-medium transition">Vendor Info</button>
            <button @click="currentTab = 'reviews'" :class="currentTab === 'reviews' ? 'border-b-2 border-amber-600 text-amber-600 font-bold' : 'text-gray-400 hover:text-blue-900'" class="px-6 py-3 text-sm font-medium transition">Customer Reviews ({{ count($reviews) }})</button>
        </div>

        <div x-show="currentTab === 'delivery'" class="space-y-4 animate-fadeIn">
            <h3 class="text-xl font-bold text-blue-900">Delivery Details Overview</h3>
            <div class="p-4 bg-amber-50/50 rounded-xl border border-amber-200/40 text-blue-900 font-medium max-w-md text-sm">
                <strong>Delivery Fee to Selected Destination:</strong>
                <span class="text-amber-600 font-extrabold ml-1">{{ $deliveryFeePerKg !== null ? '₦' . number_format($deliveryFeePerKg, 2) : 'Logistics Route Unavailable' }}</span>
            </div>
        </div>

        <div x-show="currentTab === 'description'" x-cloak class="space-y-4 animate-fadeIn">
            <h3 class="text-xl font-bold text-blue-900">Detailed Description</h3>
            <div class="text-gray-600 text-sm leading-relaxed">{!! $product->description !!}</div>
        </div>

        <div x-show="currentTab === 'vendor'" x-cloak class="space-y-4 animate-fadeIn">
            <h3 class="text-xl font-bold text-blue-900">Seller Information</h3>
            <div class="p-5 bg-gray-50/50 border border-gray-200/60 rounded-xl space-y-2 text-sm text-gray-700 max-w-xl">
                <p class="text-base font-bold text-blue-900 flex items-center">
                    <span class="mr-2">🏬</span> Vendor Shop:
                    @if($vendor)
                        <a href="{{ url('vendor/'. $vendor->slug ) }}" class="text-amber-600 hover:underline ml-1">{{ $vendor->name }}</a>
                    @else
                        <span class="text-gray-400">Unknown Vendor</span>
                    @endif
                </p>
                <p><span class="font-medium text-gray-400">Logistics Hub Base:</span> {{ $product->state ?? ($vendor->state ?? '—') }}</p>
            </div>
        </div>

        <div x-show="currentTab === 'reviews'" x-cloak class="space-y-6 animate-fadeIn">
            <h3 class="text-xl font-bold text-blue-900">Customer Feedback</h3>
            @forelse ($reviews as $review)
                <div class="border-b border-gray-100 pb-4 last:border-0">
                    <div class="flex items-center text-amber-500 text-xs mb-1">
                        @for($i = 1; $i <= 5; $i++) <span>{{ $i <= $review->rating ? '⭐' : '☆' }}</span> @endfor
                    </div>
                    <p class="text-sm text-gray-700">"{{ $review->review }}"</p>
                </div>
            @empty
                <p class="text-sm text-gray-400 italic">No reviews recorded yet.</p>
            @endforelse
        </div>
    </div>

    {{-- ========================================================= --}}
    {{-- NEW ADDITION: SIMILAR PRODUCTS GRID SYSTEM LAYOUT MODULE   --}}
    {{-- ========================================================= --}}
    <section class="mt-16 space-y-6">
        <h3 class="text-2xl font-serif font-bold text-blue-900 pb-2 border-b border-gray-100">📚 Similar Books You May Enjoy</h3>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-6">
            @forelse ($similarProducts as $simPro)
                @php
                    $simImg = $simPro->image_url ? '/storage/images/product_image/medium/'.$simPro->image_url : '/storage/images/product_image/medium/default.jpg';
                    $simDiscount = Product::getDiscountPrice($simPro->id);
                @endphp
                <div class="bg-white rounded-xl shadow-sm p-4 border border-gray-100 hover:shadow-md transition text-center flex flex-col justify-between">
                    <div>
                        <div class="relative w-full h-40 sm:h-48 bg-gray-50 overflow-hidden rounded-lg mb-3">
                            <img src="{{ asset($simImg) }}" alt="{{ $simPro->title }}" class="w-full h-full object-cover">
                            @if($simPro->stock == 0)
                                <span class="absolute top-2 right-2 bg-gray-700 text-white text-[9px] font-bold px-2 py-0.5 rounded-full">SOLD OUT</span>
                            @endif
                        </div>
                        <h4 class="font-bold text-blue-900 truncate text-xs sm:text-sm mb-0.5"><a href="{{ url('product/'.$simPro->slug) }}" class="hover:text-amber-600">{{ Str::limit($simPro->title, 20) }}</a></h4>
                        <p class="text-[10px] text-gray-400 truncate mb-1">By {{ $simPro->author }}</p>
                        <p class="text-[9px] text-blue-800 font-semibold bg-blue-50/60 inline-block px-2 py-0.5 rounded-md truncate max-w-full">🏬 {{ $simPro->vendor->name ?? 'Merchant' }}</p>
                    </div>
                    <div class="mt-3 pt-2 border-t border-gray-50 text-amber-600 font-extrabold text-xs sm:text-sm">
                        ₦{{ number_format($simDiscount['final_price'], 0) }}
                    </div>
                </div>
            @empty
                <p class="col-span-full text-sm text-gray-400 italic">No similar cross-category recommendation suggestions found matching this item.</p>
            @endforelse
        </div>
    </section>

    {{-- ========================================================= --}}
    {{-- NEW ADDITION: RECENTLY VIEWED ROW SYSTEM LAYOUT MODULE   --}}
    {{-- ========================================================= --}}
    @if(count($recentViewedProducts) > 0)
        <section class="mt-16 space-y-6">
            <h3 class="text-2xl font-serif font-bold text-blue-900 pb-2 border-b border-gray-100">🕒 Your Recently Viewed Books</h3>
            <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-4">
                @foreach ($recentViewedProducts as $recPro)
                    @php
                        $recImg = $recPro->image_url ? '/storage/images/product_image/medium/'.$recPro->image_url : '/storage/images/product_image/medium/default.jpg';
                        $recDiscount = Product::getDiscountPrice($recPro->id);
                    @endphp
                    <div class="bg-white rounded-xl shadow-xs p-3 border border-gray-100 hover:shadow-sm transition text-center flex flex-col justify-between">
                        <div>
                            <div class="relative w-full h-32 bg-gray-50 overflow-hidden rounded-lg mb-2">
                                <img src="{{ asset($recImg) }}" alt="{{ $recPro->title }}" class="w-full h-full object-cover">
                            </div>
                            <h4 class="font-bold text-blue-900 truncate text-xs mb-0.5"><a href="{{ url('product/'.$recPro->slug) }}" class="hover:text-amber-600">{{ Str::limit($recPro->title, 16) }}</a></h4>
                        </div>
                        <div class="mt-2 text-amber-600 font-black text-xs">
                            ₦{{ number_format($recDiscount['final_price'], 0) }}
                        </div>
                    </div>
                @endforeach
            </div>
        </section>
    @endif
       @script
    <script>
        // Butterup toast listener
        $wire.on('toast', ([data]) => {
            butterup.toast({
                title: data.title,
                message: data.message,
                type: data.type,
                location: 'top-right',
                icon: true
            });
        });
    </script>
    @endscript
</main>
