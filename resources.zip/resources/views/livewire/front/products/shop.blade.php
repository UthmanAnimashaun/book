<?php

use Livewire\Volt\Component;
use Livewire\WithPagination;
use App\Models\Product;
use App\Models\Category;
use App\Models\Admin;
use App\Models\Cart;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Attributes\Url;
use Livewire\Attributes\Computed;

new #[Layout('layouts.front.app')]
#[Title('Explore Book Catalogue | Book Buffet')]
class extends Component {
    use WithPagination;

    #[Url(except: '')]
    public $search = '';

    #[Url(except: 'newest')]
    public $sortBy = 'newest';


    #[Url(as: 'categories')] // Keeps your URL clean
public array $selectedCategories = [];

    #[Url(except: null)]
    public $minPrice;

    #[Url(except: null)]
    public $maxPrice;

    #[Url(except: null)]
    public $selectedAuthor;

    #[Url(except: null)]
    public $selectedVendor;

    #[Url(except: '')]
    public $state = '';

    // Collections Cache Array Frameworks [cite: 60]
    public $cartItems = [];
    public $getCartItems = 0;
    public $states = [];
    public $vendors = [];
    public $categories = [];



    public function mount(): void
    {
            // Catch the single 'category' query parameter from the homepage link
        if (request()->has('category')) {
            $categoryId = request()->query('category');

            // Ensure it's not already in the array, then add it
            if (!in_array($categoryId, $this->selectedCategories)) {
                $this->selectedCategories[] = $categoryId;
            }
        }


        $this->categories = Category::where('status', 1)
            ->withCount(['products' => fn($q) => $q->where('status', 1)])
            ->having('products_count', '>', 0)
            ->pluck('category_name', 'id')
            ->toArray();

        $this->vendors = Admin::where('status', 1)
            ->withCount(['products' => fn($q) => $q->where('status', 1)])
            ->having('products_count', '>', 0)
            ->pluck('name', 'id')
            ->toArray();

        // Pull unique states from the admins (vendors) table instead of products [cite: 64]
        $this->states = Admin::whereNotNull('state')
//            ->where('is_admin', 2)
            ->distinct()
            ->pluck('state')
            ->sort()
            ->values()
            ->toArray();

        $session_id = Session::get('session_id') ?? Session::getId();
        Session::put('session_id', $session_id);

        $this->cartItems = Cart::where('session_id', $session_id)->pluck('product_id')->toArray();
    }

    public function updating($field): void
    {
        if ($field !== 'page') {
            $this->resetPage();
        }
    }

    public function addToCart($productId): void
    {
        $session_id = Session::get('session_id') ?? Session::getId();
        Session::put('session_id', $session_id);

        $exists = Cart::where('session_id', $session_id)->where('product_id', $productId)->exists();
        if ($exists) {
            $this->dispatch('toast', ['title' => 'Already Appended', 'message' => 'This book is already in your cart!', 'type' => 'info']);
            return;
        }

        $cart = new Cart();
        $cart->session_id = $session_id;
        $cart->product_id = $productId;
        $cart->quantity = 1;
        if (Auth::check()) {
            $cart->user_id = Auth::id();
        }
        $cart->save();

        $this->cartItems[] = $productId;
        $this->dispatch('toast', ['title' => 'Added!', 'message' => 'Item added to cart successfully!', 'type' => 'success']);
        $this->dispatch('cartUpdated');
        $this->getCartItems = Cart::getCartItems();
    }

    public function clearFilter(): void
    {
        $this->state = '';
        $this->search = '';
        $this->selectedCategories = [];
        $this->minPrice = null;
        $this->maxPrice = null;
        $this->selectedAuthor = null;
        $this->selectedVendor = null;
        $this->sortBy = 'newest';
        $this->resetPage();
    }

    // Livewire 3 Computed properties cache query iterations within the runtime request lifecycle
    #[Computed]
    public function books()
    {
        $query = Product::with(['ratings', 'vendor'])->where('status', 1);

        if (!empty($this->search)) {
            $query->where(function ($q) {
                $q->where('title', 'like', '%' . $this->search . '%')
                  ->orWhere('author', 'like', '%' . $this->search . '%')
                  ->orWhere('isbn', 'like', '%' . $this->search . '%');
            });
        }

        if (!empty($this->state)) {
            $query->whereHas('vendor', function ($q) {
                $q->where('state', $this->state);
            });
        }

        if (!empty($this->selectedCategories)) {
            $query->whereIn('category_id', $this->selectedCategories);
        }

        if ($this->minPrice) {
            $query->where('price', '>=', $this->minPrice);
        }

        if ($this->maxPrice) {
            $query->where('price', '<=', $this->maxPrice);
        }

        if ($this->selectedAuthor) {
            $query->where('author', 'like', '%' . $this->selectedAuthor . '%');
        }

        if ($this->selectedVendor) {
            $query->where('admin_id', $this->selectedVendor);
        }

        switch ($this->sortBy) {
            case 'low_to_high': $query->orderBy('price', 'asc'); break;
            case 'high_to_low': $query->orderBy('price', 'desc'); break;
            case 'title_asc':   $query->orderBy('title', 'asc'); break;
            default:            $query->latest();
        }

        return $query->paginate(15);
    }
};
?>

<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">

    {{-- FIX: Swapped lg:flex-row for md:flex-row to position the sidebar on the side at md screens --}}
    <div class="flex flex-col md:flex-row gap-8">

        {{-- FIX: Added 'hidden md:block' to hide the entire filter panel on mobile screens --}}
        <aside class="hidden md:block w-full md:w-64 flex-shrink-0 bg-white p-6 rounded-xl shadow-md border border-gray-100 h-fit space-y-6 md:sticky md:top-24">
            <div class="flex items-center justify-between border-b pb-3">
                <h2 class="text-xl font-bold text-blue-900">Filters Matrix</h2>
                <button wire:click="clearFilter" class="text-xs font-semibold text-amber-600 hover:underline">Clear All</button>
            </div>

            {{-- State Filtration --}}
            <div class="space-y-2">
                <label for="state-select" class="block text-xs font-bold uppercase text-gray-400">Courier Shipping Hub:</label>
                <select id="state-select" wire:model.live="state" class="w-full text-sm rounded-xl border border-gray-300 px-3 py-2 bg-white focus:ring-2 focus:ring-amber-600/40">
                    <option value="">All Regions (Nigeria)</option>
                    @foreach($states as $st)
                        <option value="{{ $st }}">{{ $st }}</option>
                    @endforeach
               </select>
            </div>

            {{-- Vendor Filtration --}}
            <div class="space-y-2">
                <label for="vendor-select" class="block text-xs font-bold uppercase text-gray-400">Filter By Seller:</label>
                <select id="vendor-select" wire:model.live="selectedVendor" class="w-full text-sm rounded-xl border border-gray-300 px-3 py-2 bg-white focus:ring-2 focus:ring-amber-600/40">
                    <option value="">All Sellers / Merchants</option>
                    @foreach($vendors as $id => $name)
                        <option value="{{ $id }}">{{ $name }}</option>
                    @endforeach
                </select>
            </div>

            {{-- Category Filtration --}}
            <div class="space-y-2">
                <span class="block text-xs font-bold uppercase text-gray-400 mb-2">Book Categories:</span>
                <div class="space-y-1.5 max-h-48 overflow-y-auto pr-1 text-sm">
                    @foreach($categories as $id => $catName)
                        <label class="flex items-center space-x-2.5 cursor-pointer text-gray-600 hover:text-blue-900">
                            <input type="checkbox" wire:model.live="selectedCategories" value="{{ $id }}" class="rounded text-amber-600 border-gray-300 focus:ring-amber-600/50">
                            <span class="text-xs font-medium">{{ $catName }}</span>
                        </label>
                    @endforeach
                </div>
            </div>
        </aside>

        {{-- Right Main Workspace Column --}}
        <div class="flex-grow space-y-6">

            {{-- Search Bar Top Panel: Layout scales cleanly on mobile, keeping only the bar --}}
            <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-4 items-center justify-between">
                <div class="relative w-full md:w-2/3">
                    <input type="text" wire:model.live.debounce.300ms="search" placeholder="Search books by title, author name, or ISBN parameters..."
                           class="w-full text-sm border border-gray-300 rounded-full py-2.5 pl-10 pr-4 focus:ring-2 focus:ring-amber-600/50 focus:outline-none">
                    <span class="absolute left-3.5 top-3 text-gray-400">🔍</span>
                </div>

                {{-- The sorting selector hides cleanly on small mobile viewports, leaving just the search input --}}
                <div class="hidden md:flex items-center space-x-2 w-full md:w-auto justify-end">
                    <label for="sort-select" class="text-xs font-medium text-gray-400 whitespace-nowrap">Sort By:</label>
                    <select id="sort-select" wire:model.live="sortBy" class="text-xs rounded-full border border-gray-300 px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-amber-600/50">
                        <option value="newest">Newest Releases</option>
                        <option value="low_to_high">Price: Low → High</option>
                        <option value="high_to_low">Price: High → Low</option>
                        <option value="title_asc">Title: A → Z</option>
                    </select>
                </div>
            </div>

            {{-- Product Grid Wrapper --}}
            <div wire:loading.class="opacity-40" wire:target="search, sortBy, selectedCategories, minPrice, maxPrice, selectedAuthor, selectedVendor, state">

                <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
                    @forelse($this->books as $book)
                        @php
                            $product_image = $book->image_url ? '/storage/images/product_image/medium/'.$book->image_url : '/storage/images/product_image/medium/default.jpg';
                            $bookVendorName = $book->vendor->name ?? 'Merchant';
                            $bookVendorHub = $book->state ?? ($book->vendor->state ?? 'Unknown');
                        @endphp

                        <div class="bg-white rounded-xl shadow-md p-3 sm:p-4 border border-gray-100 flex flex-col justify-between text-center group transition hover:shadow-lg">
                            <div>
                                <div class="relative w-full h-40 sm:h-48 bg-gray-50 overflow-hidden rounded-lg mb-3">
                                    <img src="{{ asset($product_image) }}" alt="{{ $book->title }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                                    @if($book->stock > 0 && $book->discount > 0)
                                        <span class="absolute top-2 right-2 bg-red-600 text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-sm">{{ $book->discount }}% OFF</span>
                                    @endif
                                </div>

                                <h3 class="font-bold text-blue-900 truncate text-sm sm:text-base mb-0.5" title="{{ $book->title }}">
                                    <a href="{{ url('product/'.$book->slug) }}" class="hover:text-amber-600 transition">{{ $book->title }}</a>
                                </h3>
                                <p class="text-[11px] text-gray-400 truncate mb-1">by {{ $book->author }}</p>

                                <div class="mb-3 flex flex-col space-y-0.5 text-[9px] sm:text-[10px] items-center">
                                    <span class="text-blue-800 font-semibold truncate max-w-full">🏢 {{ $bookVendorName }}</span>
                                    <span class="text-gray-400 font-medium">📍 Hub: <span class="text-gray-600 font-bold">{{ $bookVendorHub }}</span></span>
                                </div>
                            </div>

                            <div class="space-y-2 pt-2 border-t border-gray-50">
                                <div class="text-center font-black text-sm text-amber-600">
                                    @php $prices = Product::getDiscountPrice($book->id); @endphp
                                    ₦{{ number_format($prices['final_price'], 0) }}
                                </div>

                                @if ($book->stock > 0)
                                    @if(in_array($book->id, $this->cartItems))
                                        <button disabled class="w-full bg-green-50 text-green-700 py-1.5 rounded-full text-xs font-semibold cursor-not-allowed border border-green-200">Added ✓</button>
                                    @else
                                        <button wire:click="addToCart({{ $book->id }})" class="w-full bg-amber-600 hover:bg-amber-700 text-white py-1.5 rounded-full text-xs font-semibold transition shadow-xs">Add to Cart 🛒</button>
                                    @endif
                                @else
                                    <button disabled class="w-full bg-gray-100 text-gray-400 py-1.5 rounded-full text-xs font-medium cursor-not-allowed">Sold Out ❌</button>
                                @endif
                            </div>
                        </div>
                    @empty
                        <div class="col-span-full py-16 bg-white border border-dashed rounded-xl text-center text-gray-500 text-sm font-medium">
                            No books matched your active collection search filtering criteria.
                        </div>
                    @endforelse
                </div>
            </div>

            <div class="pt-6">
                {{ $this->books->links() }}
            </div>
        </div>
    </div>
           @script
    <script>
        // Butterup toast listener
        $wire.on('toast', ([data]) => {
            butterup.toast({
                title: data.title,
                message: data.message,
                type: data.type,
                location: 'top-right',
                icon: true
            });
        });
    </script>
     @endscript
</main>
