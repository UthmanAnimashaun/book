<?php

use Livewire\Volt\Component;
use App\Models\Product;
use App\Models\Admin;
use App\Models\Cart;
use App\Models\Category;
use App\Models\Rating;
use App\Models\DeliveryFee;
use App\Models\State;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('Book Details | Book Buffet')]
class extends Component {

    // Core parameters
    public $product;
    public $vendor;
    public $images = [];
    public $mainImage;
    public $quantity = 1;
    public $getCartItems = 0;

    // Delivery parameters
    public $states = [];
    public $selectedState = "Abia State";
    public $deliveryFeePerKg;
    public $estimatedFee;

    // Recommendation collections
    public $categoryDetails;
    public $similarProducts = [];

    public function mount($slug): void
    {
        $this->product = Product::with(['section', 'category', 'images'])->where('slug', $slug)->firstOrFail();
        $this->categoryDetails = Category::categoryDetails($this->product->category->category_slug);

        $this->similarProducts = Product::with('brand')
            ->where('category_id', $this->product->category_id)
            ->inRandomOrder()
            ->take(50)
            ->get();

        $this->vendor = Admin::find($this->product->admin_id ?? null);
        $this->images = $this->getProductImages();

        // Fallback calculation for initial main banner render
        $this->mainImage = $this->images[0] ?? '/storage/images/product_image/large/' . $this->product->image_url;
        $this->states = State::orderBy('name')->pluck('name')->toArray();

        // Safe profile recovery tracking fallback
        if (Auth::check() && $default = Auth::user()->defaultAddress) {
            $this->selectedState = $default->state;
        }

        $this->calculateDelivery();
    }

    private function getProductImages(): array
    {
        $images = [];

        if (!empty($this->product->image_url)) {
            $images[] = '/storage/images/product_image/large/' . $this->product->image_url;
        }

        if ($this->product->images && $this->product->images->count() > 0) {
            foreach ($this->product->images as $img) {
                $images[] = '/storage/images/product_image/additionals/_resized_' . $img->images;
            }
        }

        return $images;
    }

    public function switchImage($image): void
    {
        $this->mainImage = $image;
    }

    public function incrementQty(): void
    {
        $this->quantity++;
    }

    public function decrementQty(): void
    {
        if ($this->quantity > 1) {
            $this->quantity--;
        }
    }

    public function updatedSelectedState(): void
    {
        $this->calculateDelivery();
    }

    public function calculateDelivery(): void
    {
        $fee = DeliveryFee::where('vendor_id', $this->product->admin_id)
            ->where('state', $this->selectedState)
            ->first();

        if ($fee) {
            $this->deliveryFeePerKg = $fee->price_per_kg;
            $this->estimatedFee = $this->deliveryFeePerKg;
        } else {
            $this->deliveryFeePerKg = null;
            $this->estimatedFee = null;
        }
    }

    public function addToCart(): void
    {
        $stock = $this->product->stock;

        if ($this->quantity > $stock) {
            $this->dispatch('toast', [
                'title' => 'Stock Limit',
                'message' => 'Required quantity is not available',
                'type' => 'error'
            ]);
            return;
        }

        if ($this->quantity <= 0) {
            $this->dispatch('toast', [
                'title' => 'Invalid Qty',
                'message' => 'You cannot add 0 to your cart',
                'type' => 'error'
            ]);
            return;
        }

        $session_id = Session::get('session_id') ?? Session::getId();
        Session::put('session_id', $session_id);
        $user_id = Auth::check() ? Auth::id() : 0;

        $exists = Cart::where('product_id', $this->product->id)
            ->when(Auth::check(), fn($q) => $q->where('user_id', $user_id))
            ->when(!Auth::check(), fn($q) => $q->where('session_id', $session_id))
            ->exists();

        if ($exists) {
            $this->dispatch('toast', [
                'title' => 'Already Appended',
                'message' => 'This book is already in your cart!',
                'type' => 'info'
            ]);
            return;
        }

        $saveCart = Cart::create([
            'product_id' => $this->product->id,
            'user_id' => $user_id,
            'session_id' => $session_id,
            'quantity' => $this->quantity,
        ]);

        if ($saveCart) {
            $this->getCartItems = Cart::getCartItems();
            $this->dispatch('cartUpdated');
            $this->dispatch('toast', [
                'title' => 'Added!',
                'message' => 'Item added to cart successfully!',
                'type' => 'success'
            ]);
        }
    }

    public function with(): array
    {
        return [
            'reviews' => Rating::where('product_id', $this->product->id)
                ->where('status', 1)
                ->latest()
                ->take(5)
                ->get()
        ];
    }
}; ?>

<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">

    {{-- Breadcrumb Navigation Row --}}
    <div class="mb-8 text-sm text-gray-500 flex items-center space-x-2">
        <a href="/" class="hover:text-amber-600 transition">Home</a>
        <span class="text-amber-600">/</span>
        <a href="/shop" class="hover:text-amber-600 transition">Shop</a>
        <span class="text-amber-600">/</span>
        <span class="hover:text-amber-600 transition text-gray-400">{{ $product['section']['name'] }}</span>
        <span class="text-amber-600">/</span>
        <span class="hover:text-amber-600 transition text-gray-400">{{ $product['category']['category_name'] }}</span>
        <span class="text-amber-600">/</span>
        <span class="text-blue-900 font-medium truncate max-w-[200px] sm:max-w-full">{{ $product->title }}</span>
    </div>

    {{-- Product Workspace Grid Matrix --}}
    <div class="bg-white p-6 md:p-10 rounded-xl shadow-lg border border-gray-100 grid grid-cols-1 lg:grid-cols-2 gap-10">

        {{-- Left Column: Image Media Gallery Layout block --}}
        <div class="space-y-6">
            <div class="h-96 md:h-[550px] bg-gray-50 rounded-lg shadow-md overflow-hidden border border-gray-100">
                <img src="{{ asset($mainImage) }}" alt="{{ $product->title }} Display Cover"
                    class="w-full h-full object-cover transition duration-300">
            </div>

            <div class="flex flex-wrap gap-4 justify-start">
                @foreach ($images as $img)
                    <button wire:click="switchImage('{{ $img }}')"
                        class="w-20 h-24 bg-gray-50 rounded-lg overflow-hidden border-2 {{ $mainImage == $img ? 'border-amber-600 shadow-sm' : 'border-gray-200' }} transition duration-150">
                        <img src="{{ asset($img) }}" alt="Gallery Thumbnail Item" class="w-full h-full object-cover hover:opacity-100 transition">
                    </button>
                @endforeach
            </div>
        </div>

        {{-- Right Column: Information/Metadata Context Controls --}}
        <div class="space-y-6">
            <h1 class="text-3xl md:text-4xl font-extrabold text-blue-900 leading-tight">
                {{ $product->title }} <span class="text-lg font-medium text-gray-400">({{ ucfirst($product->format) }})</span>
            </h1>

            <div class="space-y-1 text-sm text-gray-600">
                <p class="text-base font-semibold text-gray-700">
                    By: <a href="{{ route('vendors') }}" class="text-amber-600 hover:underline">{{ $product->author }}</a>
                </p>
                <p class="text-sm">
                    Published: <span class="text-gray-500 font-medium">{{ date_formatter($product->publication_date) }}</span>
                </p>
                <p class="flex items-center space-x-1.5 pt-1">
                    <span>🏬</span>
                    <span>Sold by:
                        <a href="{{ url('vendor/'.$vendor->slug) }}" class="font-bold text-blue-900 hover:text-amber-600 transition">
                            {{ $vendor->name ?? 'Vendor' }}
                        </a> ({{ $product->state }})
                    </span>
                </p>
            </div>

            {{-- Inventory Stocks Alerts Badge Component --}}
            <div class="pt-1">
                @if ($product->stock > 0)
                    @if ($product->stock < 6)
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-700 uppercase tracking-wide animate-pulse">
                            🚨 Only {{ $product->stock }} copies remaining!
                        </span>
                    @else
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700 uppercase">
                            ✓ {{ $product->stock }} Pieces In Stock
                        </span>
                    @endif
                @else
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-600 uppercase">
                        ❌ Out of Stock
                    </span>
                @endif
            </div>

            {{-- Financial Adjustments / Reductions Calculation Panel --}}
            <div class="py-4 border-t border-b border-gray-100 flex items-baseline space-x-3">
                @if ($product->discount)
                    <span class="text-3xl font-black text-amber-600">
                        N₦{{ number_format($product->price - ($product->price * $product->discount / 100)) }}
                    </span>
                    <span class="text-sm text-gray-400 line-through">₦{{ number_format($product->price, 0) }}</span>
                    <span class="text-xs font-bold text-red-600 bg-red-50 px-2.5 py-1 rounded-md">({{ $product->discount }}% OFF)</span>
                @else
                    <span class="text-3xl font-black text-blue-900">₦{{ number_format($product->price, 0) }}</span>
                @endif
            </div>

            <p class="text-gray-600 leading-relaxed text-sm">
                {!! Str::limit($product->description, 250) !!}
            </p>

            {{-- Quantities Control Buttons Component Grid --}}
            @if ($product->stock > 0)
                <div class="flex items-center space-x-4 pt-2">
                    <span class="font-bold text-sm text-blue-900">Quantity:</span>
                    <div class="flex items-center border border-gray-300 rounded-xl overflow-hidden shadow-xs bg-white">
                        <button type="button" wire:click="decrementQty" class="px-3 py-1.5 bg-gray-50 hover:bg-gray-100 font-bold transition text-gray-600">–</button>
                        <input type="text" value="{{ $quantity }}" readonly class="w-12 text-center border-none font-bold text-sm text-blue-900 focus:ring-0 bg-white">
                        <button type="button" wire:click="incrementQty" class="px-3 py-1.5 bg-gray-50 hover:bg-gray-100 font-bold transition text-gray-600">+</button>
                    </div>
                </div>

                <div class="pt-4">
                    <button wire:click="addToCart"
                        class="w-full sm:w-2/3 bg-amber-600 hover:bg-amber-700 text-white font-bold py-3.5 px-8 rounded-xl transition duration-150 shadow-md flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
                        wire:loading.attr="disabled">
                        <span wire:loading.remove wire:target="addToCart">🛒 Add to Cart</span>
                        <span wire:loading wire:target="addToCart">Adding to Basket...</span>
                    </button>
                </div>
            @endif

            @include('admin.messages')
        </div>
    </div>

    {{-- ======================================================== --}}
    {{-- ALPINE.JS INSTANT DYNAMIC TAB SWITCHING PANEL COMPONENTS --}}
    {{-- ======================================================== --}}
    <div x-data="{ currentTab: 'delivery' }" class="mt-12 bg-white p-6 md:p-10 rounded-xl shadow-lg border border-gray-100">

        {{-- Interactive Tab Header Anchor Button Links Matrix --}}
        <div class="flex border-b border-gray-200 mb-6 overflow-x-auto whitespace-nowrap scrollbar-none">
            <button @click="currentTab = 'delivery'" :class="currentTab === 'delivery' ? 'border-b-2 border-amber-600 text-amber-600 font-bold' : 'text-gray-400 hover:text-blue-900'" class="px-6 py-3 text-sm font-medium transition duration-150">
                Delivery & Shipping
            </button>
            <button @click="currentTab = 'description'" :class="currentTab === 'description' ? 'border-b-2 border-amber-600 text-amber-600 font-bold' : 'text-gray-400 hover:text-blue-900'" class="px-6 py-3 text-sm font-medium transition duration-150">
                About This Book
            </button>
            <button @click="currentTab = 'vendor'" :class="currentTab === 'vendor' ? 'border-b-2 border-amber-600 text-amber-600 font-bold' : 'text-gray-400 hover:text-blue-900'" class="px-6 py-3 text-sm font-medium transition duration-150">
                Vendor Info
            </button>
            <button @click="currentTab = 'reviews'" :class="currentTab === 'reviews' ? 'border-b-2 border-amber-600 text-amber-600 font-bold' : 'text-gray-400 hover:text-blue-900'" class="px-6 py-3 text-sm font-medium transition duration-150">
                Customer Reviews ({{ count($reviews) }})
            </button>
        </div>

        {{-- Content Panel 1: Delivery Routing Fee Simulator Matrix --}}
        <div x-show="currentTab === 'delivery'" class="space-y-4 animate-fadeIn">
            <h3 class="text-xl font-bold text-blue-900">Check Delivery Options</h3>
            <div class="max-w-xs">
                <label for="delivery-state" class="block text-xs font-bold uppercase text-gray-400 mb-1.5">Select Destination State:</label>
                <select id="delivery-state" wire:model.live="selectedState"
                    class="block w-full py-2.5 px-3 border border-gray-300 bg-white rounded-xl shadow-xs text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-amber-600 transition">
                    <option value="">Select State</option>
                    @foreach($states as $st)
                        <option value="{{ $st }}">{{ $st }}</option>
                    @endforeach
                </select>
            </div>

            <div class="p-4 bg-amber-50/50 rounded-xl border border-amber-200/40 text-blue-900 font-medium max-w-md text-sm">
                <strong>Delivery Fee to {{ $selectedState }}:</strong>
                <span class="text-amber-600 font-extrabold ml-1">
                    {{ $deliveryFeePerKg !== null ? '₦' . number_format($deliveryFeePerKg, 2) : 'Logistics Route Unavailable' }}
                </span>
            </div>
            <p class="text-xs text-gray-400 italic">Note: Delivery times typically range from 2-7 working days depending on the vendor dispatch location context rules.</p>
        </div>

        {{-- Content Panel 2: Product Specifications Metadata List --}}
        <div x-show="currentTab === 'description'" x-cloak class="space-y-4 animate-fadeIn">
            <h3 class="text-xl font-bold text-blue-900">Detailed Description</h3>
            <div class="text-gray-600 text-sm leading-relaxed">{!! $product->description !!}</div>

            <h4 class="text-base font-bold text-blue-900 pt-4 border-t border-gray-50">Product Specifications</h4>
            <ul class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2 text-sm text-gray-600">
                <li><span class="font-semibold text-gray-400">ISBN Code:</span> {!! $product->isbn !!}</li>
                <li><span class="font-semibold text-gray-400">Book Format:</span> {{ $product->format }}</li>
                <li><span class="font-semibold text-gray-400">Publisher:</span> {{ $product->publisher }}</li>
                <li><span class="font-semibold text-gray-400">Language:</span> {{ $product->language }}</li>
                <li><span class="font-semibold text-gray-400">Total Pages:</span> {{ $product->pages }} Pages</li>
                <li><span class="font-semibold text-gray-400">Dimensions:</span> {{ $product->dimensions ?: '—' }}</li>
            </ul>
        </div>

        {{-- Content Panel 3: Seller Workspace Profiles Overview --}}
        <div x-show="currentTab === 'vendor'" x-cloak class="space-y-4 animate-fadeIn">
            <h3 class="text-xl font-bold text-blue-900">Seller Information</h3>
            <div class="p-5 bg-gray-50/50 border border-gray-200/60 rounded-xl space-y-2 text-sm text-gray-700 max-w-xl">
                <p class="text-base font-bold text-blue-900 flex items-center">
                    <span class="mr-2">🏬</span> Vendor Shop:
                    <a href="{{ url('vendor/'. $vendor->slug ) }}" class="text-amber-600 hover:underline ml-1">
                        {{ $vendor->name ?? 'Unknown Vendor'}}
                    </a>
                </p>
                <p><span class="font-medium text-gray-400">Logistics Hub Base:</span> {{ $product->state ?? '—' }}</p>
                <a href="{{ url('vendor/'. $vendor->slug ) }}" class="inline-block pt-2 text-amber-600 font-bold hover:underline">
                    View More Books by this Vendor &rarr;
                </a>
            </div>
        </div>

        {{-- Content Panel 4: Reviews Data Loop Matrix --}}
        <div x-show="currentTab === 'reviews'" x-cloak class="space-y-6 animate-fadeIn">
            <h3 class="text-xl font-bold text-blue-900">Customer Feedback</h3>
            @forelse ($reviews as $review)
                <div class="border-b border-gray-100 pb-4 last:border-0">
                    <div class="flex items-center text-amber-500 text-xs mb-1">
                        @for($i = 1; $i <= 5; $i++)
                            <span>{{ $i <= $review->rating ? '⭐' : '☆' }}</span>
                        @endfor
                    </div>
                    <p class="text-sm text-gray-700 leading-normal">"{{ $review->review }}"</p>
                </div>
            @empty
                <p class="text-sm text-gray-400 italic">No historical evaluations recorded for this item yet.</p>
            @endforelse
        </div>

    </div>
</main>
