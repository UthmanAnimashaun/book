<?php

use Livewire\Volt\Component;
use App\Models\Product;
use App\Models\DeliveryAddress;
use App\Models\Cart;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('Secure Checkout | Book Buffet')]
 class extends Component {

    public $addresses = [];
    public $cartItems = [];
    public $deliveryFees = [];

    // Form Tracking Properties
    public $delivery_id = null;
    public $name = '';
    public $address = '';
    public $mobile = '';
    public $pincode = '';
    public $state = '';
    public $city = '';
    public $editing = false;

    // Financial & Validation State Properties
    public $subtotal = 0;
    public $totalDeliveryFee = 0;
    public $grandTotal = 0;
    public $hasDeliveryClash = false; // Tracks if any book cannot be delivered here

    public function mount(): void
    {
        if (!Auth::check()) {
            $this->redirect(route('user.login'));
            return;
        }

        $this->loadAddresses();

        // Auto-select destination if a default address already exists
        $defaultAddr = collect($this->addresses)->firstWhere('isDefault', 1);
        if ($defaultAddr) {
            $this->state = $defaultAddr->state;
            $this->city = $defaultAddr->city;
        }

        $this->loadCartSummary();
    }

    public function loadAddresses(): void
    {
        $this->addresses = DeliveryAddress::where('user_id', Auth::id())
            ->orderByDesc('isDefault')
            ->orderByDesc('id')
            ->get();
    }

 public function loadCartSummary(): void
{
    $session_id = Session::get('session_id');

    $items = Cart::with(['product.vendor'])
        ->where('session_id', $session_id)
        ->get()
        ->toArray();

    $this->cartItems = $items;
    $this->subtotal = 0;
    $this->totalDeliveryFee = 0;
    $this->hasDeliveryClash = false;

    foreach ($items as $item) {
        $product = $item['product'];
        $productId = $item['product_id'];

        // 1. Calculate Book Subtotal
        $discountPrice = Product::getDiscountPrice($productId);
        $finalPrice = $discountPrice['final_price'] ?? $product['price'];
        $this->subtotal += ($finalPrice * $item['quantity']);

        // 2. Normalize customer chosen destination state text
        $targetDestinationState = $this->state;

        // 3. Extract vendor shipping origin state safely
        $vendorState = $product['state'] ?? ($product['vendor']['state'] ?? null);

        if (!empty($targetDestinationState) && !empty($vendorState)) {
            // Normalize strings: lowercase, remove "state", and strip extra white spaces
            $cleanCustomerState = str_replace('state', '', strtolower(trim($targetDestinationState)));
            $cleanVendorState = str_replace('state', '', strtolower(trim($vendorState)));

            // Clean up double spaces left after replacement
            $cleanCustomerState = trim(preg_replace('/\s+/', ' ', $cleanCustomerState));
            $cleanVendorState = trim(preg_replace('/\s+/', ' ', $cleanVendorState));

            // If they still don't match, trigger the delivery clash flag
            if ($cleanCustomerState !== $cleanVendorState) {
                $this->hasDeliveryClash = true;
            }
        }

        // 4. Calculate Delivery Fees (Only if route is valid)
        $fee = 0;
        if (!empty($targetDestinationState) && !$this->hasDeliveryClash) {
            $fee = 500;
        }

        $this->deliveryFees[$productId] = $fee;
        $this->totalDeliveryFee += $fee;
    }

    $this->grandTotal = $this->subtotal + $this->totalDeliveryFee;
}

    public function updatedState(): void
    {
        // Re-run checking loops instantly when destination selection drop-down modifications occur
        $this->loadCartSummary();
    }

    public function create(): void
    {
        $this->resetForm();
        $this->editing = false;
    }

    public function edit($id): void
    {
        $addr = DeliveryAddress::where('id', $id)->where('user_id', Auth::id())->firstOrFail();

        $this->delivery_id = $addr->id;
        $this->name = $addr->name;
        $this->address = $addr->address;
        $this->mobile = $addr->mobile;
        $this->pincode = $addr->pincode;
        $this->state = $addr->state;
        $this->city = $addr->city;

        $this->editing = true;
        $this->loadCartSummary();
    }

    public function save(): void
    {
        $this->validate([
            'name' => 'required|string|max:255',
            'address' => 'required|string|max:500',
            'mobile' => 'required|string|max:30',
            'state' => 'required|string',
            'city' => 'required|string',
        ]);

        DeliveryAddress::updateOrCreate(
            ['id' => $this->delivery_id, 'user_id' => Auth::id()],
            [
                'name' => $this->name,
                'address' => $this->address,
                'mobile' => $this->mobile,
                'pincode' => $this->pincode,
                'state' => $this->state,
                'city' => $this->city,
                'status' => 1
            ]
        );

        $this->resetForm();
        $this->loadAddresses();
        $this->loadCartSummary();

        $this->dispatch('toast', [
            'title' => 'Address Saved!',
            'message' => 'Your delivery credentials have updated successfully.',
            'type' => 'success'
        ]);
    }

    public function setDefault($id): void
    {
        DeliveryAddress::where('user_id', Auth::id())->update(['isDefault' => 0]);
        $addr = DeliveryAddress::where('id', $id)->where('user_id', Auth::id())->first();
        if ($addr) {
            $addr->update(['isDefault' => 1]);
            $this->state = $addr->state;
            $this->city = $addr->city;
        }

        $this->loadAddresses();
        $this->loadCartSummary();

        $this->dispatch('toast', [
            'title' => 'Default Changed',
            'message' => 'Default shipping address has been updated.',
            'type' => 'success'
        ]);
    }

    public function confirmDelete($id): void
    {
        $addr = DeliveryAddress::where('id', $id)->where('user_id', Auth::id())->first();
        if ($addr) {
            $addr->delete();
            $this->loadAddresses();
            $this->loadCartSummary();

            $this->dispatch('toast', [
                'title' => 'Address Deleted',
                'message' => 'The shipping profile was successfully removed.',
                'type' => 'success'
            ]);
        }
    }

    private function resetForm(): void
    {
        $this->delivery_id = null;
        $this->name = '';
        $this->address = '';
        $this->mobile = '';
        $this->pincode = '';
        $this->state = '';
        $this->city = '';
        $this->editing = false;
    }
}; ?>

<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">

    <div class="mb-8">
        <div class="text-sm text-gray-500 flex items-center space-x-2 mb-2">
            <a href="/" class="hover:text-amber-600 transition">Home</a>
            <span class="text-amber-600">/</span>
            <a href="/cart" class="hover:text-amber-600 transition">Cart</a>
            <span class="text-amber-600">/</span>
            <span class="text-blue-900 font-medium">Checkout</span>
        </div>
        <h1 class="text-4xl font-extrabold text-blue-900">Checkout</h1>
    </div>

@include("admin.messages")

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">

        {{-- LEFT COLUMN: Addresses Manager Form --}}
        <div class="lg:col-span-2 space-y-6">
            <section class="bg-white shadow-xl rounded-2xl p-6 border border-gray-100">
                <h2 class="text-xl font-bold text-blue-900 mb-4 border-b pb-3">🚚 Saved Delivery Addresses</h2>

                <button wire:click="create"
                        class="mb-6 bg-amber-600 hover:bg-amber-700 text-white text-sm font-medium py-2.5 px-4 rounded-xl transition shadow-sm"
                        wire:loading.attr="disabled">
                    <span>➕ Add New Address</span>
                </button>

                <div class="space-y-4">
                    @foreach ($addresses as $address)
                        <div class="p-4 bg-gray-50/50 rounded-xl border flex flex-col justify-between transition {{ $address->isDefault ? 'border-green-400 bg-green-50/10' : 'border-gray-200' }}">
                            <div class="mb-4">
                                <div class="flex items-center space-x-2">
                                    <p class="font-bold text-blue-900 text-base">{{ $address->name }}</p>
                                    @if ($address->isDefault)
                                        <span class="px-2.5 py-0.5 text-[10px] font-extrabold rounded-full bg-green-100 text-green-700 uppercase">Default ✓</span>
                                    @endif
                                </div>
                                <p class="text-sm text-gray-600 mt-1.5">{{ $address->address }}, {{ $address->city }}, {{ $address->state }}</p>
                            </div>

                            <div class="flex flex-wrap gap-2 pt-3 border-t border-gray-100 justify-end">
                                @if (!$address->isDefault)
                                    <button wire:click="setDefault({{ $address->id }})" class="border border-green-600 bg-green-600 hover:bg-green-700 text-white text-xs font-semibold py-1.5 px-3 rounded-lg transition shadow-xs">
                                        Ship to this Location
                                    </button>
                                @endif
                                <button wire:click="edit({{ $address->id }})" class="bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold py-1.5 px-3 rounded-lg transition shadow-xs">📝 Edit</button>
                                <button wire:confirm="Are you sure?" wire:click="confirmDelete({{ $address->id }})" class="bg-red-600 hover:bg-red-700 text-white text-xs font-semibold py-1.5 px-3 rounded-lg transition shadow-xs">🗑️ Delete</button>
                            </div>
                        </div>
                    @endforeach
                </div>
            </section>

            <section class="bg-white shadow-xl rounded-2xl p-6 border border-gray-100">
                <h2 class="text-xl font-bold text-blue-900 mb-4 border-b pb-3">🗺️ {{ $editing ? 'Edit Delivery Address' : 'Add New Delivery Address' }}</h2>

                <form wire:submit="save" class="space-y-4">
                    <div>
                        <label for="name" class="block text-xs font-bold uppercase text-gray-500 mb-1">Full Name *</label>
                        <input type="text" id="name" wire:model="name" class="w-full border border-gray-300 rounded-xl px-4 py-2.5 text-sm">
                        @error('name') <span class="text-red-600 text-xs mt-1 block">{{ $message }}</span> @enderror
                    </div>

                    <div>
                        <label for="address" class="block text-xs font-bold uppercase text-gray-500 mb-1">Street Delivery Address *</label>
                        <input type="text" id="address" wire:model="address" class="w-full border border-gray-300 rounded-xl px-4 py-2.5 text-sm">
                        @error('address') <span class="text-red-600 text-xs mt-1 block">{{ $message }}</span> @enderror
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label for="mobile" class="block text-xs font-bold uppercase text-gray-500 mb-1">Mobile Phone *</label>
                            <input type="tel" id="mobile" wire:model="mobile" class="w-full border border-gray-300 rounded-xl px-4 py-2.5 text-sm">
                            @error('mobile') <span class="text-red-600 text-xs mt-1 block">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label for="pincode" class="block text-xs font-bold uppercase text-gray-500 mb-1">Postal Code</label>
                            <input type="text" id="pincode" wire:model="pincode" class="w-full border border-gray-300 rounded-xl px-4 py-2.5 text-sm">
                        </div>
                    </div>

                    <div x-data="{
                       state: @entangle('state').live,
    city: @entangle('city').live,
                        lgas: @js(lgas()->map(fn($l) => ['name' => $l->name, 'state' => $l->state->name]))
                    }" class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label for="state" class="block text-xs font-bold uppercase text-gray-500 mb-1">State *</label>
                            <select id="state" x-model="state" wire:model.live="state" class="w-full border border-gray-300 bg-white rounded-xl px-4 py-2.5 text-sm">
                                <option value="">Select State</option>
                                @foreach(states() as $st)
                                    <option value="{{ $st->name }}">{{ $st->name }}</option>
                                @endforeach
                            </select>
                            @error('state') <span class="text-red-600 text-xs mt-1 block">{{ $message }}</span> @enderror
                        </div>

                        <div>
                            <label for="city" class="block text-xs font-bold uppercase text-gray-500 mb-1">LGA / City *</label>
                            <select id="city" x-model="city" wire:model="city" class="w-full border border-gray-300 bg-white rounded-xl px-4 py-2.5 text-sm">
                                <option value="">Select City</option>
                                <template x-for="lga in lgas.filter(l => l.state === state)" :key="lga.name">
                                    <option :value="lga.name" x-text="lga.name"></option>
                                </template>
                            </select>
                            @error('city') <span class="text-red-600 text-xs mt-1 block">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <button type="submit" class="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 rounded-xl shadow">
                        {{ $editing ? 'Update Address Details' : 'Save Delivery Address' }}
                    </button>
                </form>
            </section>
        </div>

        {{-- RIGHT COLUMN: Order Summary Matrix & Real-time Delivery Highlighting --}}
        <div class="lg:col-span-2 bg-white p-6 rounded-2xl shadow-xl border border-gray-100 space-y-6 lg:sticky lg:top-24">
            <h2 class="text-xl font-bold text-blue-900 border-b pb-3">📊 Order Summary</h2>

            {{-- Core Multi-vendor Location Conflict Warnings Block --}}
            @if ($hasDeliveryClash && !empty($state))
                <div class="p-4 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs sm:text-sm font-medium space-y-1">
                    <p class="font-bold flex items-center">⚠️ Delivery Clashes Detected!</p>
                    <p>Some items in your cart originate from vendors that cannot ship to <span class="underline font-bold">{{ $state }}</span>. Please see the highlighted items below.</p>
                </div>
            @endif

            <div class="space-y-3 max-h-80 overflow-y-auto border-b border-gray-100 pb-4 pr-1">
                @foreach ($cartItems as $item)
    @php
        $product = $item['product'];
        $price = Product::getDiscountPrice($item['product_id'])['final_price'] ?? $product['price'];
        $qty = $item['quantity'];
        $fee = $deliveryFees[$item['product_id']] ?? 0;

        // 1. Recover the raw vendor state string
        $vendorState = $product['state'] ?? ($product['vendor']['state'] ?? null);

        // 2. APPLY THE EXACT SAME NORMALIZATION TO THE BLADE CONDITIONAL LOOKUP
        $cleanCustomerState = str_replace('state', '', strtolower(trim($state)));
        $cleanVendorState = str_replace('state', '', strtolower(trim($vendorState)));

        $cleanCustomerState = trim(preg_replace('/\s+/', ' ', $cleanCustomerState));
        $cleanVendorState = trim(preg_replace('/\s+/', ' ', $cleanVendorState));

        // Re-evaluate the mismatch flag with the clean strings
        $isItemMismatched = (!empty($cleanCustomerState) && !empty($cleanVendorState) && $cleanCustomerState !== $cleanVendorState);
    @endphp

    {{-- CRITICAL FIX: Add a unique tracking wire:key to the item card wrapper --}}
    <div wire:key="cart-item-{{ $item['id'] }}-{{ $cleanCustomerState }}"
         class="flex flex-col p-3 rounded-xl border transition-all duration-200 shadow-xs
         {{ $isItemMismatched ? 'border-red-400 bg-red-50/40 relative' : 'border-gray-100 bg-gray-50/50' }}">

        <div class="flex items-center">
            <img src="/storage/images/product_image/small/{{ $product['image_url'] ?? 'default.jpg' }}" class="w-12 h-16 object-cover rounded-md shadow-sm border bg-white flex-shrink-0">

            <div class="ml-4 flex-1 min-w-0">
                <h4 class="font-bold text-blue-900 text-xs sm:text-sm truncate">{{ $product['title'] }}</h4>
                <p class="text-[11px] text-gray-400 mt-0.5">Quantity: <span class="font-semibold text-gray-700">{{ $qty }}</span></p>
                <p class="text-[11px] text-gray-500 mt-0.5">Vendor Location: <span class="text-blue-900 font-semibold">{{ $vendorState ?? 'Unknown' }}</span></p>
            </div>

            <div class="ml-3 text-right">
                <span class="font-extrabold text-amber-600 text-sm">₦{{ number_format($price * $qty, 0) }}</span>
            </div>
        </div>

        {{-- Dynamic Warning Toggle Block --}}
        @if ($isItemMismatched)
            <div class="mt-2 pt-2 border-t border-red-200/60 flex items-center justify-between text-[11px] text-red-700 font-bold bg-red-100/50 px-2 py-1 rounded-md">
                <span>❌ Vendor doesn't deliver from {{ $vendorState ?? 'origin' }} to {{ $state }}</span>
                <span class="text-[10px] uppercase bg-red-600 text-white px-1.5 py-0.2 rounded-sm">Clash</span>
            </div>
        @else
            @if (!empty($state))
                <div class="mt-1.5 text-[11px] text-green-700 font-medium flex items-center gap-1">
                    <span>✅ Available for courier drop-off to {{ $state }}</span>
                </div>
            @endif
        @endif
    </div>
@endforeach
            </div>

            <div class="space-y-2 text-sm border-b pb-4 border-gray-100">
                <div class="flex justify-between">
                    <span class="text-gray-500 font-medium">Subtotal Amount:</span>
                    <span class="font-bold text-blue-900">₦{{ number_format($subtotal, 0) }}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500 font-medium">Logistics Delivery Fee:</span>
                    <span class="font-bold text-blue-900">
                        {{ $hasDeliveryClash ? 'Unavailable' : '₦' . number_format($totalDeliveryFee, 0) }}
                    </span>
                </div>
            </div>

            <div class="flex justify-between items-center text-xl font-extrabold text-blue-900">
                <span>Grand Total:</span>
                <span class="text-2xl text-amber-600 font-black">
                    {{ $hasDeliveryClash ? '—' : '₦' . number_format($grandTotal, 0) }}
                </span>
            </div>

            {{-- Paystack Operational Inline Form Endpoint --}}
            <form action="{{ route('paystack.redirect') }}" method="POST" class="pt-2">
                @csrf
                <input type="hidden" name="email" value="{{ Auth::user()->email }}">
                <input type="hidden" name="amount" value="{{ round($grandTotal) }}">
                <input type="hidden" name="currency" value="NGN">
                <input type="hidden" name="order_id" value="{{ strtoupper('OR' . now()->timestamp . bin2hex(random_bytes(4))) }}">
                <input type="hidden" name="reference" value="{{ strtoupper('REF' . now()->timestamp . bin2hex(random_bytes(3))) }}">

                {{-- The button uses a structural conditional state toggle checking for clashes or empty values --}}
                <button type="submit"
                    @if($hasDeliveryClash || empty($state)) disabled @endif
                    class="w-full text-white font-extrabold py-3.5 rounded-xl transition duration-300 shadow-md text-center text-base tracking-wide
                    {{ ($hasDeliveryClash || empty($state)) ? 'bg-gray-300 cursor-not-allowed shadow-none text-gray-400' : 'bg-blue-900 hover:bg-blue-950' }}">

                    @if(empty($state))
                        📍 Select Delivery State to Proceed
                    @elseif($hasDeliveryClash)
                        ❌ Checkout Locked (Fix Clashes)
                    @else
                        💳 Secure Payment via Paystack
                    @endif
                </button>
            </form>
        </div>
    </div>
          @script
        <script>
            // Butterup toast listener
            $wire.on('toast', ([data]) => {
                butterup.toast({
                    title: data.title,
                    message: data.message,
                    type: data.type,
                    location: 'top-right',
                    icon: true
                });
            });

        </script>
        @endscript
</main>
