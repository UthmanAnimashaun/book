<?php

use Livewire\Volt\Component;
use App\Models\Product;
use App\Models\DeliveryAddress;
use App\Models\Cart;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
#[Title('Secure Checkout | Book Buffet')]
 class extends Component {

    // Core Collections
    public $addresses = [];
    public $cartItems = [];
    public $deliveryFees = [];

    // Form Tracking Properties
    public $delivery_id = null;
    public $name = '';
    public $address = '';
    public $mobile = '';
    public $pincode = '';
    public $state = '';
    public $city = '';
    public $editing = false;

    // Financial Overview Properties
    public $subtotal = 0;
    public $totalDeliveryFee = 0;
    public $grandTotal = 0;

    public function mount(): void
    {
        if (!Auth::check()) {
            $this->redirect(route('user.login'));
            return;
        }

        $this->loadAddresses();
        $this->loadCartSummary();
    }

    public function loadAddresses(): void
    {
        $this->addresses = DeliveryAddress::where('user_id', Auth::id())
            ->orderByDesc('isDefault')
            ->orderByDesc('id')
            ->get();
    }

 public function loadCartSummary(): void
{
    $session_id = Session::get('session_id');

    // FIX: Eager load 'product' singular to match the model relationship
    $items = Cart::with('product')
        ->where('session_id', $session_id)
        ->get()
        ->toArray();

    $this->cartItems = $items;
    $this->subtotal = 0;
    $this->totalDeliveryFee = 0;

    foreach ($items as $item) {
        $productId = $item['product_id'];

        $discountPrice = Product::getDiscountPrice($productId);
        // FIX: Change $item['products'] to $item['product']
        $finalPrice = $discountPrice['final_price'] ?? $item['product']['price'];

        $this->subtotal += ($finalPrice * $item['quantity']);

        $defaultAddr = collect($this->addresses)->firstWhere('isDefault', 1);
        $currentState = $this->state ?: ($defaultAddr->state ?? null);

        $fee = 0;
        if ($currentState) {
            $fee = 500; // Your fallback fee or dynamic calculation
        }

        $this->deliveryFees[$productId] = $fee;
        $this->totalDeliveryFee += $fee;
    }

    $this->grandTotal = $this->subtotal + $this->totalDeliveryFee;
}

    public function updatedState(): void
    {
        // Recompute localized multi-vendor shipping matrix values when user shifts state
        $this->loadCartSummary();
    }

    public function create(): void
    {
        $this->resetForm();
        $this->editing = false;
    }

    public function edit($id): void
    {
        $addr = DeliveryAddress::where('id', $id)->where('user_id', Auth::id())->firstOrFail();

        $this->delivery_id = $addr->id;
        $this->name = $addr->name;
        $this->address = $addr->address;
        $this->mobile = $addr->mobile;
        $this->pincode = $addr->pincode;
        $this->state = $addr->state;
        $this->city = $addr->city;

        $this->editing = true;
        $this->loadCartSummary();
    }

    public function save(): void
    {
        $this->validate([
            'name' => 'required|string|max:255',
            'address' => 'required|string|max:500',
            'mobile' => 'required|string|max:30',
            'state' => 'required|string',
            'city' => 'required|string',
        ]);

        DeliveryAddress::updateOrCreate(
            ['id' => $this->delivery_id, 'user_id' => Auth::id()],
            [
                'name' => $this->name,
                'address' => $this->address,
                'mobile' => $this->mobile,
                'pincode' => $this->pincode,
                'state' => $this->state,
                'city' => $this->city,
                'status' => 1
            ]
        );

        $this->resetForm();
        $this->loadAddresses();
        $this->loadCartSummary();

        $this->dispatch('toast', [
            'title' => 'Address Saved!',
            'message' => 'Your delivery credentials have updated successfully.',
            'type' => 'success'
        ]);
    }

    public function setDefault($id): void
    {
        DeliveryAddress::where('user_id', Auth::id())->update(['isDefault' => 0]);
        DeliveryAddress::where('id', $id)->where('user_id', Auth::id())->update(['isDefault' => 1]);

        $this->loadAddresses();
        $this->loadCartSummary();

        $this->dispatch('toast', [
            'title' => 'Default Changed',
            'message' => 'Default shipping address has been updated.',
            'type' => 'success'
        ]);
    }

    public function confirmDelete($id): void
    {
        $addr = DeliveryAddress::where('id', $id)->where('user_id', Auth::id())->first();
        if ($addr) {
            $addr->delete();
            $this->loadAddresses();
            $this->loadCartSummary();

            $this->dispatch('toast', [
                'title' => 'Address Deleted',
                'message' => 'The shipping profile was successfully removed.',
                'type' => 'success'
            ]);
        }
    }

    private function resetForm(): void
    {
        $this->delivery_id = null;
        $this->name = '';
        $this->address = '';
        $this->mobile = '';
        $this->pincode = '';
        $this->state = '';
        $this->city = '';
        $this->editing = false;
    }
}; ?>

<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">

    {{-- Breadcrumb Navigation Row --}}
    <div class="mb-8">
        <div class="text-sm text-gray-500 flex items-center space-x-2 mb-2">
            <a href="/" class="hover:text-amber-600 transition">Home</a>
            <span class="text-amber-600">/</span>
            <a href="/cart" class="hover:text-amber-600 transition">Cart</a>
            <span class="text-amber-600">/</span>
            <span class="text-blue-900 font-medium">Checkout</span>
        </div>
        <h1 class="text-4xl font-extrabold text-blue-900">Checkout</h1>
    </div>

    {{-- Alert Messages Core Layout Include --}}
    @include('admin.messages')

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">

        {{-- LEFT COLUMN: Shipping Addresses Management --}}
        <div class="lg:col-span-2 space-y-6">

            {{-- Saved Address Sub-Section Container Card --}}
            <section class="bg-white shadow-xl rounded-2xl p-6 border border-gray-100">
                <h2 class="text-xl font-bold text-blue-900 mb-4 border-b pb-3">🚚 Saved Delivery Addresses</h2>

                <button wire:click="create" href="#targetDiv"
                        class="mb-6 bg-amber-600 hover:bg-amber-700 text-white text-sm font-medium py-2.5 px-4 rounded-xl transition duration-150 shadow-sm disabled:opacity-50"
                        wire:loading.attr="disabled">
                    <span wire:loading.remove wire:target="create">➕ Add New Address</span>
                    <span wire:loading wire:target="create">Opening Form...</span>
                </button>

                <div class="space-y-4">
                    @forelse ($addresses as $address)
                        <div class="p-4 bg-gray-50/50 rounded-xl border flex flex-col justify-between transition {{ $address->isDefault ? 'border-green-400 bg-green-50/10' : 'border-gray-200' }}">
                            <div class="mb-4">
                                <div class="flex items-center space-x-2">
                                    <p class="font-bold text-blue-900 text-base">{{ $address->name }}</p>
                                    @if ($address->isDefault)
                                        <span class="px-2.5 py-0.5 text-[10px] font-extrabold rounded-full bg-green-100 text-green-700 uppercase tracking-wider">Default ✓</span>
                                    @endif
                                </div>
                                <p class="text-sm text-gray-600 mt-1.5">{{ $address->address }}, {{ $address->city }}, {{ $address->state }}</p>
                                <div class="text-xs text-gray-400 mt-2 space-y-0.5">
                                    <p>📞 Phone: <span class="text-gray-600 font-medium">{{ $address->mobile }}</span></p>
                                    @if($address->pincode)<p>📮 Pincode: <span class="text-gray-600 font-medium">{{ $address->pincode }}</span></p>@endif
                                </div>
                            </div>

                            <div class="flex flex-wrap gap-2 pt-3 border-t border-gray-100 justify-end">
                                @if (!$address->isDefault)
                                    <button wire:click="setDefault({{ $address->id }})" wire:loading.attr="disabled" class="border border-green-600 bg-green-600 hover:bg-green-700 text-white text-xs font-semibold py-1.5 px-3 rounded-lg transition shadow-xs">
                                        Make Default
                                    </button>
                                @endif
                                <button wire:click="edit({{ $address->id }})" wire:loading.attr="disabled" class="bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold py-1.5 px-3 rounded-lg transition shadow-xs">
                                        📝 Edit
                                </button>
                                <button wire:confirm="Are you sure you want to delete this address?" wire:click="confirmDelete({{ $address->id }})" wire:loading.attr="disabled" class="bg-red-600 hover:bg-red-700 text-white text-xs font-semibold py-1.5 px-3 rounded-lg transition shadow-xs">
                                        🗑️ Delete
                                </button>
                            </div>
                        </div>
                    @empty
                        <div class="p-6 bg-amber-50/40 text-amber-800 rounded-xl text-center border border-dashed border-amber-300 text-sm font-medium">
                            You don't have any saved delivery addresses yet. Use the action button above to append your first location profile.
                        </div>
                    @endforelse
                </div>
            </section>

            {{-- Interactive Input Form Entry Segment --}}
            <section id="targetDiv" class="bg-white shadow-xl rounded-2xl p-6 border border-gray-100">
                <h2 class="text-xl font-bold text-blue-900 mb-4 border-b pb-3">🗺️ {{ $editing ? 'Edit Delivery Address' : 'Add New Delivery Address' }}</h2>

                <form wire:submit="save" class="space-y-4">
                    <div>
                        <label for="name" class="block text-xs font-bold uppercase text-gray-500 mb-1">Full Name <span class="text-red-600">*</span></label>
                        <input type="text" id="name" wire:model="name" placeholder="John Doe" class="w-full border border-gray-300 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-amber-600 focus:outline-none text-sm transition" Logan-required>
                        @error('name') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                    </div>

                    <div>
                        <label for="address" class="block text-xs font-bold uppercase text-gray-500 mb-1">Street Delivery Address <span class="text-red-600">*</span></label>
                        <input type="text" id="address" wire:model="address" placeholder="House/Plot number, street name" class="w-full border border-gray-300 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-amber-600 focus:outline-none text-sm transition">
                        @error('address') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label for="mobile" class="block text-xs font-bold uppercase text-gray-500 mb-1">Mobile Phone <span class="text-red-600">*</span></label>
                            <input type="tel" id="mobile" wire:model="mobile" placeholder="e.g. +234" class="w-full border border-gray-300 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-amber-600 focus:outline-none text-sm transition">
                            @error('mobile') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label for="pincode" class="block text-xs font-bold uppercase text-gray-500 mb-1">Postal Code / Pincode</label>
                            <input type="text" id="pincode" wire:model="pincode" placeholder="Optional" class="w-full border border-gray-300 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-amber-600 focus:outline-none text-sm transition">
                        </div>
                    </div>

                    {{-- Alpine Managed Cascading States Dropdowns Core --}}
                    <div x-data="{
                        state: @entangle('state'),
                        city: @entangle('city'),
                        lgas: @js(lgas()->map(fn($l) => ['name' => $l->name, 'state' => $l->state->name]))
                    }" class="grid grid-cols-1 sm:grid-cols-2 gap-4">

                        <div>
                            <label for="state" class="block text-xs font-bold uppercase text-gray-500 mb-1">State <span class="text-red-600">*</span></label>
                            <select id="state" x-model="state" wire:model.live="state" class="w-full border border-gray-300 bg-white rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                                <option value="">Select State</option>
                                @foreach(states() as $st)
                                    <option value="{{ $st->name }}">{{ $st->name }}</option>
                                @endforeach
                            </select>
                            @error('state') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                        </div>

                        <div>
                            <label for="city" class="block text-xs font-bold uppercase text-gray-500 mb-1">LGA / City <span class="text-red-600">*</span></label>
                            <select id="city" x-model="city" wire:model="city" class="w-full border border-gray-300 bg-white rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-600">
                                <option value="">Select City</option>
                                <template x-for="lga in lgas.filter(l => l.state === state)" :key="lga.name">
                                    <option :value="lga.name" x-text="lga.name"></option>
                                </template>
                            </select>
                            @error('city') <span class="text-red-600 text-xs mt-1 block font-medium">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div class="flex items-start pt-2">
                        <input type="checkbox" id="terms" required class="h-4 w-4 mt-0.5 text-amber-600 border-gray-300 rounded focus:ring-amber-600/40">
                        <label for="terms" class="ml-2.5 text-xs text-gray-600 leading-normal">
                            I explicitly agree to the website's <a href="/tc" target="_blank" class="text-amber-600 font-medium hover:underline">Terms & Conditions</a> and <a href="/pp" target="_blank" class="text-amber-600 font-medium hover:underline">Privacy Policy</a> agreements.
                        </label>
                    </div>

                    <button type="submit" class="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 rounded-xl transition duration-300 shadow-md disabled:opacity-50" wire:loading.attr="disabled">
                        <span wire:loading.remove>{{ $editing ? 'Update Address Details' : 'Save Delivery Address' }}</span>
                        <span wire:loading>Processing Request...</span>
                    </button>
                </form>
            </section>
        </div>

        {{-- RIGHT COLUMN: Sticky Real-time Order Summary Matrix --}}
        <div class="lg:col-span-2 bg-white p-6 rounded-2xl shadow-xl border border-gray-100 space-y-6 lg:sticky lg:top-24">
            <h2 class="text-xl font-bold text-blue-900 border-b pb-3">📊 Order Summary</h2>

            {{-- Scrollable Checkout List Window --}}
            <div class="space-y-3 max-h-64 overflow-y-auto border-b border-gray-100 pb-4 pr-1">

@foreach ($cartItems as $item)
    @php
        // FIX: Change $item['products'] to $item['product']
        $product = $item['product'];
        $price = Product::getDiscountPrice($item['product_id'])['final_price'] ?? $product['price'];
        $qty = $item['quantity'];
        $fee = $deliveryFees[$item['product_id']] ?? 0;
    @endphp

    <div class="flex items-center p-3 bg-gray-50/50 rounded-xl border border-gray-100 shadow-xs">
        <img src="/storage/images/product_image/small/{{ $product['image_url'] ?? 'default.jpg' }}" class="w-12 h-16 object-cover rounded-md shadow-sm border bg-white flex-shrink-0">

        <div class="ml-4 flex-1 min-w-0">
            <h4 class="font-bold text-blue-900 text-xs sm:text-sm truncate" title="{{ $product['title'] }}">{{ $product['title'] }}</h4>
            <p class="text-[11px] text-gray-400 mt-0.5">Quantity: <span class="font-semibold text-gray-700">{{ $qty }}</span></p>
            <p class="text-[11px] text-gray-500 mt-1">Delivery Fee: <span class="text-blue-900 font-semibold">₦{{ number_format($fee, 0) }}</span></p>
        </div>

        <div class="ml-3 text-right">
            <span class="font-extrabold text-amber-600 text-sm">₦{{ number_format($price * $qty, 0) }}</span>
        </div>
    </div>
@endforeach
            </div>

            {{-- Summary Financial Matrix Metadata Records --}}
            <div class="space-y-2 text-sm border-b pb-4 border-gray-100">
                <div class="flex justify-between">
                    <span class="text-gray-500 font-medium">Subtotal Amount:</span>
                    <span class="font-bold text-blue-900">₦{{ number_format($subtotal, 0) }}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500 font-medium">Logistics Delivery Fee:</span>
                    <span class="font-bold text-blue-900">₦{{ number_format($totalDeliveryFee, 0) }}</span>
                </div>
            </div>

            <div class="flex justify-between items-center text-xl font-extrabold text-blue-900">
                <span>Grand Total:</span>
                <span class="text-2xl text-amber-600 font-black">₦{{ number_format($grandTotal, 0) }}</span>
            </div>

            {{-- Paystack Operational Inline Form Endpoint --}}
            <form action="{{ route('paystack.redirect') }}" method="POST" class="pt-2">
                @csrf
                <input type="hidden" name="email" value="{{ Auth::user()->email }}">
                <input type="hidden" name="amount" value="{{ round($grandTotal) }}">
                <input type="hidden" name="currency" value="NGN">
                <input type="hidden" name="order_id" value="{{ strtoupper('OR' . now()->timestamp . bin2hex(random_bytes(4))) }}">
                <input type="hidden" name="reference" value="{{ strtoupper('REF' . now()->timestamp . bin2hex(random_bytes(3))) }}">

                <button type="submit" class="w-full bg-blue-900 hover:bg-blue-950 text-white font-extrabold py-3.5 rounded-xl transition duration-300 shadow-md text-center text-base tracking-wide">
                    💳 Secure Payment via Paystack
                </button>
            </form>
        </div>
    </div>
</main>
