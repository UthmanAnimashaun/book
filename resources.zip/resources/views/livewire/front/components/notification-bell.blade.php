<?php

use Livewire\Volt\Component;
use App\Models\NotificationRead;
use App\Models\OrdersProduct;
use Illuminate\Support\Facades\Auth;

new class extends Component {

    // Listen for events to refresh the count instantly when items are marked as read
    protected $listeners = ['notification-updated' => '$refresh'];

    /**
     * Compute unread count dynamically for the current logged-in customer
     */
    public function with(): array
    {
        // Use the standard web guard for regular frontend users
        $user = Auth::guard('web')->user();

        if (!$user) {
            return ['unreadCount' => 0];
        }

        $unreadCount = 0;

        /**
         * Fetch recent orders belonging to this specific user.
         * Assuming your Order/OrdersProduct model links back to the customer's user_id.
         */
        $userOrders = OrdersProduct::whereHas('order', function ($query) use ($user) {
            $query->where('user_id', $user->id);
        })->latest()->take(30)->get();

        foreach ($userOrders as $order) {
            // Check if this user has already clicked/read this order notification
            $isRead = NotificationRead::where('user_id', $user->id)
                ->where('type', 'user_order')
                ->where('reference_id', $order->id)
                ->exists();

            if (!$isRead) {
                $unreadCount++;
            }
        }

        return [
            'unreadCount' => $unreadCount
        ];
    }
}; ?>

{{-- <li class="nav-item list-none"> --}}
    <a class="nav-link relative flex items-center justify-center p-2 text-gray-600 hover:text-gray-900 transition-colors"
        href="{{ route('user.notifications') }}"
        title="My Notifications">

        {{-- Clean Emoji Icon --}}
        <span class="text-xl">🔔</span>

        {{-- Reactive Count Badge in Tailwind --}}
        @if($unreadCount > 0)
            <span class="absolute top-1 right-1 flex items-center justify-center text-[10px] font-bold text-white bg-red-500 rounded-full h-4 min-w-[16px] px-1 ring-2 ring-white">
                {{ $unreadCount > 99 ? '99+' : $unreadCount }}
            </span>
        @endif
    </a>
{{-- </li> --}}
