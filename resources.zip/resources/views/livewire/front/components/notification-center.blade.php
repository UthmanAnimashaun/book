<?php

use Livewire\Volt\Component;
use Livewire\WithPagination;
use App\Models\NotificationRead;
use App\Models\OrdersProduct;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.front.app')]
    #[Title('My Notification Center')]
class extends Component {
    use WithPagination;

    public string $activeFilter = 'all';
    protected string $paginationTheme = 'tailwind';

    public function mount(): void
    {
        Session::put('page', 'user-notifications');
    }

    public function updatedActiveFilter(): void
    {
        $this->resetPage();
    }

    public function with(): array
    {
        $user = Auth::guard('web')->user();
        $notifications = collect();

        if (!$user) {
            return ['notifications' => new \Illuminate\Pagination\LengthAwarePaginator([], 0, 10)];
        }

        // 1. Gather Purchase Orders
        if ($this->activeFilter === 'all' || $this->activeFilter === 'order') {
            $ordersQuery = OrdersProduct::whereHas('order', function ($query) use ($user) {
                $query->where('user_id', $user->id);
            })->latest();

            foreach ($ordersQuery->take(50)->get() as $o) {
                $isRead = NotificationRead::where('user_id', $user->id)
                    ->where('type', 'user_order')
                    ->where('reference_id', $o->id)
                    ->exists();

                $notifications->push([
                    'id'         => $o->id,
                    'type'       => 'user_order',
                    'title'      => 'Order Progress Update',
                    'message'    => "Your purchase order for \"{$o->product_name}\" is being processed.",
                    'url'        => route('user.orders'),
                    'created_at' => $o->created_at,
                    'emoji'      => '🛍️', // Converted to emoji
                    'color'      => 'bg-indigo-50',
                    'border'     => 'border-indigo-600',
                    'is_read'    => $isRead
                ]);
            }
        }

        // 2. Account Status Milestones
        if ($this->activeFilter === 'all' || $this->activeFilter === 'account') {
            if ($user->created_at->gt(now()->subDays(7))) {
                $isRead = NotificationRead::where('user_id', $user->id)
                    ->where('type', 'account_welcome')
                    ->where('reference_id', $user->id)
                    ->exists();

                $notifications->push([
                    'id'         => $user->id,
                    'type'         => 'account_welcome',
                    'title'      => 'Account Security',
                    'message'    => "Welcome to BookBuffet! Your user profile activation loop has completed securely.",
                    'url'        => '#',
                    'created_at' => $user->created_at,
                    'emoji'      => '🛡️', // Converted to emoji
                    'color'      => 'bg-emerald-50',
                    'border'     => 'border-emerald-600',
                    'is_read'    => $isRead
                ]);
            }
        }

        $sortedNotifications = $notifications->sortByDesc('created_at');

        $currentPage = \Illuminate\Pagination\Paginator::resolveCurrentPage();
        $perPage = 10;
        $currentItems = $sortedNotifications->slice(($currentPage - 1) * $perPage, $perPage)->values()->all();

        $paginatedNotifications = new \Illuminate\Pagination\LengthAwarePaginator(
            $currentItems,
            $sortedNotifications->count(),
            $perPage,
            $currentPage,
            ['path' => \Illuminate\Pagination\Paginator::resolveCurrentPath()]
        );

        return [
            'notifications' => $paginatedNotifications
        ];
    }

    public function navigateAndRead(int $id, string $type, string $targetUrl)
    {
        $user = Auth::guard('web')->user();
        if ($user) {
            NotificationRead::firstOrCreate([
                'user_id'      => $user->id,
                'type'         => $type,
                'reference_id' => $id,
            ]);
        }

        $this->dispatch('notification-updated');

        if($targetUrl === '#') {
            return null;
        }

        return redirect()->to($targetUrl);
    }

    public function markFilteredAsRead(): void
    {
        $user = Auth::guard('web')->user();
        if (!$user) return;

        $data = $this->with();
        foreach ($data['notifications'] as $note) {
            if (!$note['is_read']) {
                NotificationRead::firstOrCreate([
                    'user_id'      => $user->id,
                    'type'         => $note['type'],
                    'reference_id' => $note['id'],
                ]);
            }
        }

        $this->dispatch('toast', message: 'Your alerts summary cleared.', type: 'success');
        $this->dispatch('notification-updated');
    }
}; ?>

<div class="max-w-4xl mx-auto my-12 px-4 text-gray-800 min-h-[70vh]">
    {{-- PAGE HEADER CAPTION ROW --}}
    <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-8">
        <div>
            <h3 class="text-2xl font-bold text-gray-900 mb-1">🔔 My Notifications</h3>
            <p class="text-sm text-gray-500">Track order modifications, delivery updates, and profile safety logs.</p>
        </div>
        <button type="button" wire:click="markFilteredAsRead" class="inline-flex items-center justify-center text-xs font-semibold px-4 py-2.5 rounded-lg border border-gray-300 bg-white text-gray-700 shadow-sm hover:bg-gray-50 transition-colors">
            Clear View Logs
        </button>
    </div>

    {{-- FILTER NAVIGATION PILLS LAYER --}}
    <div class="flex flex-wrap items-center gap-2 mb-6">
        <button wire:click="$set('activeFilter', 'all')"
            class="px-4 py-2 rounded-full text-xs font-medium transition-all shadow-sm {{ $activeFilter === 'all' ? 'bg-[#4B49AC] text-white' : 'bg-white text-gray-600 border border-gray-200 hover:border-gray-300' }}">
            All Logs
        </button>
        <button wire:click="$set('activeFilter', 'order')"
            class="px-4 py-2 rounded-full text-xs font-medium transition-all shadow-sm {{ $activeFilter === 'order' ? 'bg-[#4B49AC] text-white' : 'bg-white text-gray-600 border border-gray-200 hover:border-gray-300' }}">
            🛍️ Orders History
        </button>
        <button wire:click="$set('activeFilter', 'account')"
            class="px-4 py-2 rounded-full text-xs font-medium transition-all shadow-sm {{ $activeFilter === 'account' ? 'bg-[#4B49AC] text-white' : 'bg-white text-gray-600 border border-gray-200 hover:border-gray-300' }}">
            🔒 Account Alerts
        </button>
    </div>

    {{-- MAIN NOTIFICATIONS FEED DISPLAY FRAME --}}
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="divide-y divide-gray-100">
            @forelse($notifications as $note)
                <div wire:key="center-note-{{ $note['type'] }}-{{ $note['id'] }}"
                     wire:click="navigateAndRead({{ $note['id'] }}, '{{ $note['type'] }}', '{{ $note['url'] }}')"
                     class="flex items-center p-5 cursor-pointer transition-all hover:bg-gray-50/70 border-l-4 {{ $note['is_read'] ? 'border-transparent opacity-60' : 'bg-indigo-50/10 ' . $note['border'] }}">

                    {{-- Dynamic Emoji Icon Frame --}}
                    <div class="w-10 h-10 min-w-[40px] flex items-center justify-center rounded-full text-lg mr-4 {{ $note['color'] }}">
                        <span>{{ $note['emoji'] }}</span>
                    </div>

                    {{-- Core Text Content Column --}}
                    <div class="flex-grow min-w-0 pr-4">
                        <div class="flex items-center mb-0.5">
                            <span class="text-[10px] uppercase font-bold tracking-wider mr-2 text-gray-500">
                                {{ $note['title'] }}
                            </span>
                            @if(!$note['is_read'])
                                <span class="w-1.5 h-1.5 bg-red-500 rounded-full inline-block"></span>
                            @endif
                        </div>
                        <p class="text-sm font-semibold text-gray-900 truncate">
                            {{ $note['message'] }}
                        </p>
                    </div>

                    {{-- Time Context Suffix --}}
                    <div class="text-xs text-gray-400 text-nowrap pl-2 text-right sm:text-left">
                        {{ $note['created_at']->diffForHumans() }}
                    </div>
                </div>
            @empty
                {{-- BLANK STATE PANEL --}}
                <div class="text-center py-12 px-4 bg-white text-gray-400">
                    <div class="w-16 h-16 bg-gray-50 border border-dashed border-gray-300 text-xl mx-auto mb-3 flex items-center justify-center rounded-full">
                        <span>🔕</span>
                    </div>
                    <h5 class="font-bold text-gray-800 mb-1">No alerts found</h5>
                    <p class="text-xs max-w-[260px] mx-auto text-gray-500 leading-relaxed">
                        There are no logged actions matching your filter segment selection parameters.
                    </p>
                </div>
            @endforelse
        </div>
    </div>

    {{-- PAGINATION LINK FOOTER LAYOUT CONTROLS --}}
    <div class="mt-6 flex justify-center">
        {{ $notifications->links() }}
    </div>

    <script>
        document.addEventListener('livewire:init', () => {
            Livewire.on('toast', (event) => {
                if(typeof butterup !== 'undefined') {
                    butterup.toast({
                        message: event.message,
                        type: event.type,
                        icon: true
                    });
                }
            });
        });
    </script>
</div>
