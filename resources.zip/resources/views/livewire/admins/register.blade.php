<?php

use Livewire\Volt\Component;

use Illuminate\Support\Facades\Auth;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use App\Models\Website;
use App\Models\Admin;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

new #[Layout('layouts.admin.auth_layout')] // Ensure this layout exists and has {{ $slot }}[cite: 5]
    #[Title('Staff Registration')]
class extends Component {
    // 1. Define the properties as public so Blade can see them
    public $allStates = [];
    public $filteredLgas = [];

    // 2. Define your form fields[cite: 6]
    public $name = '';
    public $mobile = '';
    public $email = '';
    public $state = '';
    public $lga = '';
    public $password = '';
    public $password_confirmation = '';
    public $accept = false;

    public function mount()
    {
        // 3. Load the states when the page first loads
        $this->allStates = \App\Models\State::orderBy('name', 'asc')->get();
    }

    // 4. Update LGAs automatically when the state changes
    public function updatedState($value)
    {
        $this->filteredLgas = \App\Models\Lga::whereHas('state', function($query) use ($value) {
            $query->where('name', $value);
        })->orderBy('name', 'asc')->get();

        $this->lga = ''; // Reset lga selection
    }

public function register()
    {
        // 1. Basic Validation
        $this->validate([
            'name' => 'required|string|max:255',
            'mobile' => 'required|string|max:19',
            'email' => ['required', 'email', 'unique:admins,email'], //
            'state' => 'required',
            'lga' => 'required',
            'password' => 'required|min:8|confirmed',
            'accept' => 'accepted',
        ]);

        // 2. CHECK VENDOR LIMIT FOR THE SELECTED STATE
        $selectedState = \App\Models\State::where('name', $this->state)->first();

        if ($selectedState) {
            // Count existing vendors (is_admin = 2) in this state
            $currentVendorCount = \App\Models\Admin::where('state', $this->state)
                ->where('is_admin', 2)
                ->count();

            if ($currentVendorCount >= $selectedState->vendor_limit) {
                $this->addError('state', "Sorry, we have reached the maximum number of vendors for {$this->state}.");
                return;
            }
        } else {
            $this->addError('state', "Selected state is invalid.");
            return;
        }

        // 3. Prepare Data with Slug and Type
        $userData = [
            'name' => $this->name,
            'slug' => Str::slug($this->name), // Generates "John Doe" -> "john-doe"
            'email' => $this->email,
            'mobile' => $this->mobile,
            'state' => $this->state,
            'lga' => $this->lga,
            'image' => " ",
            'status' => 1,
            'is_admin' => 2, // Explicitly set to 2 so they count as vendors[cite: 6]
            'password' => Hash::make($this->password),
        ];

        try {
            // 3. Send Email First
            $email = $this->email;
            $messageData = [
                'email' => $this->email,
                'name' => $this->name,
                'code' => base64_encode($this->email)
            ];

            Mail::send('emails.admin.confirmation', $messageData, function ($message) use ($email) {
                $webName =  config('app.name');
                $message->to($email)->subject('Confirm your ' . $webName . " account");
            });

            // 4. Save Vendor to 'admins' table
            \App\Models\Admin::create($userData); //[cite: 6]

            return redirect()->route('admin.login')->with('success_message', 'A verification link has been sent to your email, please check to verify your email and activate your account.');

        } catch (\Exception $e) {
            session()->flash('admin_error_message', 'Failed to send verification email: ' . $e->getMessage());
        }
    }

    }; ?>

<div class="auth-wrapper d-flex align-items-center justify-content-center" style="min-height: 100vh; background: #f5f7fb;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="auth-form-light text-left py-5 px-4 px-sm-5 shadow-lg rounded-3 bg-white">

                    <div class="text-center brand-logo mb-4">
                        <h3 class="font-weight-bold text-primary">STAFF REGISTRATION</h3>
                    </div>

                    {{-- Error & Success Messages --}}
                    @if (session()->has('admin_error_message'))
                        <div class="alert alert-danger">{{ session('admin_error_message') }}</div>
                    @endif

                    <form wire:submit.prevent="register">
                        <div class="row">
                            {{-- Name --}}
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Name <span class="text-danger">*</span></label>
                                <input type="text" wire:model="name" class="form-control @error('name') is-invalid @enderror" placeholder="Full Name">
                                @error('name') <small class="text-danger">{{ $message }}</small> @enderror
                            </div>

                            {{-- Mobile --}}
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Mobile <span class="text-danger">*</span></label>
                                <input type="text" wire:model="mobile" class="form-control @error('mobile') is-invalid @enderror" placeholder="Mobile Number">
                                @error('mobile') <small class="text-danger">{{ $message }}</small> @enderror
                            </div>
                        </div>

                        {{-- Email --}}
                        <div class="mb-3">
                            <label class="font-weight-bold">Email <span class="text-danger">*</span></label>
                            <input type="email" wire:model="email" class="form-control @error('email') is-invalid @enderror" placeholder="email@example.com">
                            @error('email') <small class="text-danger">{{ $message }}</small> @enderror
                        </div>

                        <div class="row">
                            {{-- State Dropdown --}}
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">State <span class="text-danger">*</span></label>
                                <select wire:model.live="state" class="form-control @error('state') is-invalid @enderror">
                                    <option value="">Choose State</option>
                                    {{-- Use the $allStates property we defined in the PHP section --}}
                                    @foreach($allStates as $s)
                                        <option value="{{ $s->name }}">{{ $s->name }}</option>
                                    @endforeach
                                </select>
                                @error('state') <small class="text-danger">{{ $message }}</small> @enderror
                            </div>

                            {{-- City/LGA Dropdown --}}
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">LGA <span class="text-danger">*</span></label>
                                <select wire:model="lga" class="form-control @error('lga') is-invalid @enderror" {{ empty($state) ? 'disabled' : '' }}>
                                    <option value="">Choose LGA</option>
                                    @foreach($filteredLgas as $lga)
                                        <option value="{{ $lga->name }}">{{ $lga->name }}</option>
                                    @endforeach
                                </select>
                                @error('lga') <small class="text-danger">{{ $message }}</small> @enderror
                            </div>
                        </div>

                        <div class="row">
                            {{-- Password --}}
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Password <span class="text-danger">*</span></label>
                                <input type="password" wire:model="password" class="form-control @error('password') is-invalid @enderror">
                                @error('password') <small class="text-danger">{{ $message }}</small> @enderror
                            </div>

                            {{-- Confirm Password --}}
                            <div class="col-md-6 mb-3">
                                <label class="font-weight-bold">Confirm Password <span class="text-danger">*</span></label>
                                <input type="password" wire:model="password_confirmation" class="form-control @error('password_confirmation') is-invalid @enderror">
                                @error('password_confirmation') <small class="text-danger">{{ $message }}</small> @enderror

                            </div>
                        </div>

                        {{-- Accept T&C --}}
                        <div class="mb-4">
                            <div class="form-check">
                                <input type="checkbox" wire:model="accept" class="form-check-input" id="accept">
                                <label class="form-check-label" for="accept">
                                    I accept the <a href="{{ route('tc') }}" target="_blank" class="text-primary">Terms & Conditions</a>
                                </label>
                            </div>
                            @error('accept') <small class="text-danger d-block">{{ $message }}</small> @enderror
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg w-100 shadow-sm">
                            <span wire:loading.remove>REGISTER ACCOUNT</span>
                            <span wire:loading>
                                <i class="fa fa-spinner fa-spin mr-2"></i> PROCESSING...
                            </span>
                        </button>

                        <div class="mt-4 text-center">
                            Already have an account? <a href="{{ route('admin.login') }}" class="text-primary font-weight-bold">Login</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
