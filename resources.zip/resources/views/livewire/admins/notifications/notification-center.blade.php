<?php

use Livewire\Volt\Component;
use Livewire\WithPagination;
use App\Models\NotificationRead;
use App\Models\User;
use App\Models\Admin;
use App\Models\OrdersProduct;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Notification Center')]
class extends Component {
    use WithPagination;

    // Filtering State
    public string $activeFilter = 'all'; // 'all', 'order', 'user', 'admin'

    protected string $paginationTheme = 'bootstrap';

    public function mount(): void
    {
        // Highlight the correct sidebar link if needed, or clear it
        Session::put('page', 'Notifications-Center');
    }

    /**
     * Clear page query string when filters change to avoid empty pagination states
     */
    public function updatedActiveFilter(): void
    {
        $this->resetPage();
    }

    /**
     * Compute and stream notifications to the view with pagination
     */
    public function with(): array
    {
        $admin = Auth::guard('admin')->user();
        $notifications = collect();

        if (!$admin) {
            return ['notifications' => new \Illuminate\Pagination\LengthAwarePaginator([], 0, 10)];
        }

        // 1. Gather Orders (Accessible by Super Admin or scoped to Vendor)
        if ($this->activeFilter === 'all' || $this->activeFilter === 'order') {
            $ordersQuery = OrdersProduct::latest();
            if ((int)$admin->is_admin !== 1) {
                $ordersQuery->where('admin_id', $admin->id);
            }

            foreach ($ordersQuery->take(50)->get() as $o) {
                $isRead = NotificationRead::where('admin_id', $admin->id)->where('type', 'order')->where('reference_id', $o->id)->exists();
                $notifications->push([
                    'id'         => $o->id,
                    'type'       => 'order',
                    'title'      => (int)$admin->is_admin === 1 ? 'New Order' : 'Product Sold',
                    'message'    => (int)$admin->is_admin === 1 ? "Order placed for book: {$o->product_name}" : "Your book \"{$o->product_name}\" has been purchased.",
                    'url'        => route('admin.orders'),
                    'created_at' => $o->created_at,
                    'icon'       => 'fa fa-shopping-bag',
                    'color'      => '#f59e0b',
                    'is_read'    => $isRead
                ]);
            }
        }

        // 2. Gather Users & Admins (Super Admin Only metrics)
        if ((int)$admin->is_admin === 1) {
            if ($this->activeFilter === 'all' || $this->activeFilter === 'user') {
                foreach (User::latest()->take(50)->get() as $u) {
                    $isRead = NotificationRead::where('admin_id', $admin->id)->where('type', 'user')->where('reference_id', $u->id)->exists();
                    $notifications->push([
                        'id'         => $u->id,
                        'type'       => 'user',
                        'title'      => 'New Customer',
                        'message'    => "Account created by registration: {$u->name} ({$u->email})",
                        'url'        => route('admin.users'),
                        'created_at' => $u->created_at,
                        'icon'       => 'fa fa-user-plus',
                        'color'      => '#6366f1',
                        'is_read'    => $isRead
                    ]);
                }
            }

            if ($this->activeFilter === 'all' || $this->activeFilter === 'admin') {
                foreach (Admin::latest()->take(50)->get() as $a) {
                    if ($a->id === $admin->id) continue; // Skip self
                    $isRead = NotificationRead::where('admin_id', $admin->id)->where('type', 'admin')->where('reference_id', $a->id)->exists();
                    $notifications->push([
                        'id'         => $a->id,
                        'type'       => 'admin',
                        'title'      => 'Staff Update',
                        'message'    => "New administration profile authorized: {$a->name}",
                        'url'        => route('admin.admins'),
                        'created_at' => $a->created_at,
                        'icon'       => 'fa fa-shield',
                        'color'      => '#10b981',
                        'is_read'    => $isRead
                    ]);
                }
            }
        }

        // Sort combined collection by dynamic timestamps
        $sortedNotifications = $notifications->sortByDesc('created_at');

        // Manual Pagination slice for custom mapped array collections
        $currentPage = \Illuminate\Pagination\Paginator::resolveCurrentPage();
        $perPage = 10;
        $currentItems = $sortedNotifications->slice(($currentPage - 1) * $perPage, $perPage)->values()->all();

        $paginatedNotifications = new \Illuminate\Pagination\LengthAwarePaginator(
            $currentItems,
            $sortedNotifications->count(),
            $perPage,
            $currentPage,
            ['path' => \Illuminate\Pagination\Paginator::resolveCurrentPath()]
        );

        return [
            'notifications' => $paginatedNotifications,
            'adminRole'     => (int)$admin->is_admin
        ];
    }

    /**
     * Mark an alert item as read and route the user to its reference point
     */
    public function navigateAndRead(int $id, string $type, string $targetUrl)
    {
        $admin = Auth::guard('admin')->user();
        if ($admin) {
            NotificationRead::firstOrCreate([
                'admin_id'     => $admin->id,
                'type'         => $type,
                'reference_id' => $id,
            ]);
        }

        return redirect()->to($targetUrl);
    }

    /**
     * Mark all currently filtered visible alerts as read simultaneously
     */
    public function markFilteredAsRead(): void
    {
        $admin = Auth::guard('admin')->user();
        if (!$admin) return;

        // Loop through the processed listing to batch update matching items
        $data = $this->with();
        foreach ($data['notifications'] as $note) {
            if (!$note['is_read']) {
                NotificationRead::firstOrCreate([
                    'admin_id'     => $admin->id,
                    'type'         => $note['type'],
                    'reference_id' => $note['id'],
                ]);
            }
        }

        $this->dispatch('toast', message: 'Selected view marked as read.', type: 'success');


// Dispatch this to clear global layout counts instantly
$this->dispatch('notification-updated');
    }
}; ?>

<div class="content-wrapper text-dark">
    <div class="row">
        <div class="col-12 grid-margin">

            {{-- PAGE HEADER CAPTION ROW --}}
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="font-weight-bold text-dark mb-1">🔔 Notification Center</h3>
                    <p class="text-muted small mb-0">Review, sort, and manage system history updates and business operations triggers.</p>
                </div>
                <button type="button" wire:click="markFilteredAsRead" class="btn btn-sm btn-outline-primary shadow-sm px-3 py-2 font-weight-medium" style="border-radius: 6px;">
                    <i class="fas fa-check-double  mr-1">✅</i> Mark View as Read
                </button>
            </div>

            {{-- FILTER NAVIGATION PILLS LAYER --}}
            <div class="d-flex flex-wrap align-items-center mb-4 gap-2">
                <button wire:click="$set('activeFilter', 'all')" class="filter-pill {{ $activeFilter === 'all' ? 'active-pill' : '' }}">
                    All Activities
                </button>
                <button wire:click="$set('activeFilter', 'order')" class="filter-pill {{ $activeFilter === 'order' ? 'active-pill' : '' }}">
                    <i class="fa fa-shopping-bag  mr-1"></i> Orders
                </button>
                @if($adminRole === 1)
                    <button wire:click="$set('activeFilter', 'user')" class="filter-pill {{ $activeFilter === 'user' ? 'active-pill' : '' }}">
                        <i class="fa fa-user mr-1"></i> New Customers
                    </button>
                    <button wire:click="$set('activeFilter', 'admin')" class="filter-pill {{ $activeFilter === 'admin' ? 'active-pill' : '' }}">
                        <i class="fa fa-shield mr-1"></i> Staff Logs
                    </button>
                @endif
            </div>

            {{-- MAIN NOTIFICATIONS FEED DISPLAY FRAME --}}
            <div class="card shadow-sm border-0" style="border-radius: 12px; overflow: hidden;">
                <div class="card-body p-0 bg-white">
                    @forelse($notifications as $note)
                        <div wire:key="center-note-{{ $note['type'] }}-{{ $note['id'] }}"
                             wire:click="navigateAndRead({{ $note['id'] }}, '{{ $note['type'] }}', '{{ $note['url'] }}')"
                             class="center-notification-row d-flex align-items-center {{ $note['is_read'] ? 'row-read' : 'row-unread' }}">

                            {{-- Icon Category Frame --}}
                            <div class="notify-icon-box d-flex align-items-center justify-content-center rounded-circle mr-3"
                                 style="background-color: {{ $note['color'] }}12; color: {{ $note['color'] }};">
                                <i class="fas {{ $note['icon'] }}"></i>
                            </div>

                            {{-- Core Text Content Column --}}
                            <div class="flex-grow-1 min-w-0 pr-3">
                                <div class="d-flex align-items-center mb-1">
                                    <span class="text-uppercase tracking-wider font-weight-bold mr-2" style="font-size: 0.68rem; letter-spacing: 0.5px; color: {{ $note['color'] }};">
                                        {{ $note['title'] }}
                                    </span>
                                    @if(!$note['is_read'])
                                        <span class="unread-dot-indicator"></span>
                                    @endif
                                </div>
                                <p class="mb-0 text-dark font-weight-medium text-truncate-custom" style="font-size: 0.88rem;">
                                    {{ $note['message'] }}
                                </p>
                            </div>

                            {{-- Time Context Suffix --}}
                            <div class="text-right text-muted font-weight-normal text-nowrap pl-2" style="font-size: 0.8rem;">
                                <i class="far fa-clock mr-1" style="font-size: 0.75rem;"></i>{{ $note['created_at']->diffForHumans() }}
                            </div>
                        </div>
                    @empty
                        {{-- PREMIUM STYLED HOVERABLE BLANK STATE PANEL --}}
                        <div class="text-center py-5 px-4 bg-white text-muted">
                            <div class="empty-center-sphere mx-auto mb-3 d-flex align-items-center justify-content-center rounded-circle">
                                <i class="fa fa-bell-slash" style="font-size: 1.8rem; opacity: 0.4;"></i>
                            </div>
                            <h5 class="font-weight-bold text-dark mb-1">Your stream is empty</h5>
                            <p class="small mb-0 mx-auto text-secondary" style="max-width: 260px; line-height: 1.5;">
                                There are no logged actions matching this filter segment at the moment.
                            </p>
                        </div>
                    @endforelse
                </div>
            </div>

            {{-- PAGINATION LAYOUT WRAPPER FOOTER LINK CONTROLS --}}
            <div class="mt-4 d-flex justify-content-center standard-pagination">
                {{ $notifications->links() }}
            </div>

        </div>
    </div>

    {{-- DYNAMIC CUSTOM NOTIFICATION PAGE OVERRIDE STYLES --}}
    <style>
        .gap-2 { gap: 0.5rem; }
        .filter-pill {
            border: 1px solid #e2e8f0;
            background: #ffffff;
            color: #4a5568;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.82rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            outline: none !important;
        }
        .filter-pill:hover {
            background: #f8fafc;
            color: #1a202c;
            border-color: #cbd5e1;
        }
        .active-pill {
            background: #4B49AC !important;
            color: #ffffff !important;
            border-color: #4B49AC !important;
            box-shadow: 0 4px 12px rgba(75, 73, 172, 0.2);
        }
        .center-notification-row {
            padding: 18px 24px;
            border-bottom: 1px solid #f1f5f9;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .center-notification-row:last-child {
            border-bottom: 0;
        }
        .center-notification-row:hover {
            background-color: #f8fafc;
            transform: translateX(3px);
        }
        .row-unread {
            background-color: rgba(75, 73, 172, 0.02);
            border-left: 4px solid #4B49AC;
        }
        .row-read {
            border-left: 4px solid transparent;
            opacity: 0.8;
        }
        .notify-icon-box {
            width: 40px;
            height: 40px;
            min-width: 40px;
            font-size: 0.95rem;
        }
        .unread-dot-indicator {
            width: 6px;
            height: 6px;
            background-color: #ef4444;
            border-radius: 50%;
            display: inline-block;
        }
        .empty-center-sphere {
            width: 64px;
            height: 64px;
            background: #f8fafc;
            border: 1px dashed #cbd5e1;
        }
        .text-truncate-custom {
            white-space: nowrap;
            overflow: hidden;
            text-truncate: ellipsis;
        }
        @media(max-width: 576px) {
            .center-notification-row { padding: 14px 16px; flex-wrap: wrap; }
            .text-right { width: 100%; text-align: left !important; padding-left: 54px !important; margin-top: 4px; }
        }
    </style>

    {{-- BUTTERUP DYNAMIC MESSAGE INTEGRATIONS BRIDGE --}}
    <script>
        document.addEventListener('livewire:init', () => {
            Livewire.on('toast', (event) => {
                butterup.toast({
                    message: event.message,
                    type: event.type,
                    icon: true
                });
            });
        });
    </script>
</div>
