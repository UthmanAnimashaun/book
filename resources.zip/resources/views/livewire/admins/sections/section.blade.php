<?php

use Livewire\Volt\Component;
use App\Models\Section;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Manage Sections')]
class extends Component {
    public string $title = "Catalogue Sections";

    // Form Properties
    public $name;
    public $sectionId;
    public bool $isModalOpen = false;

    public function with(): array
    {
        Session::put('page', 'sections');
        return [
            'sections' => Section::withCount('categories')
                ->orderBy('id', 'desc')
                ->get()
        ];
    }

    // Opens modal for "Add"
    public function openModal()
    {
        $this->reset(['name', 'sectionId']);
        $this->isModalOpen = true;
    }

    // Opens modal for "Edit"
    public function editSection($id)
    {
        $section = Section::findOrFail($id);
        $this->sectionId = $id;
        $this->name = $section->name;
        $this->isModalOpen = true;
    }

    public function saveSection()
    {
        $this->validate(['name' => 'required|string|max:255']);

        Section::updateOrCreate(
            ['id' => $this->sectionId],
            ['name' => $this->name, 'status' => 1]
        );

        $message = $this->sectionId ? 'Section updated!' : 'Section added!';
        //session()->flash('admin_success_message', $message);

        $this->isModalOpen = false;
        $this->reset(['name', 'sectionId']);


           $this->dispatch('toast', message:  $message, type: 'success');
          return; // Exit early to prevent unnecessary re-rendering
    }



    public function updateSectionStatus($sectionId, $currentStatus)
    {
        $newStatus = $currentStatus == 1 ? 0 : 1;
        Section::where('id', $sectionId)->update(['status' => $newStatus]);
        //  session()->flash('admin_success_message', 'Status updated.');

           $this->dispatch('toast', message: 'Status updated.', type: 'success');
          return; // Exit early to prevent unnecessary re-rendering
    }


    public function deleteSection($sectionId)
    {
        Section::destroy($sectionId);
        //  session()->flash('admin_success_message', 'Deleted successfully!');
           $this->dispatch('toast', message: 'Section deleted.', type: 'success');
          return; // Exit early to prevent unnecessary re-rendering
    }
};  ?>


<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card shadow-sm border-0">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4 class="card-title text-primary font-weight-bold">
                            <i class="fa fa-th-large mr-2"></i> {{ $title }}
                        </h4>
                        <button wire:click="openModal" class="btn btn-primary">
            <i class="fa fa-plus"></i> Add New Section
        </button>
                    </div>


                  @include("pages.messages")

                    <div class="table-responsive pt-3">
                        <table id="sections" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-light">
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Categories Count</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($sections as $index => $section)
                                <tr wire:key="{{ $section->id }}">
                                    <td>{{ $index + 1 }}</td>
                                    <td>
                                        <div class="font-weight-bold">{{ $section->name }}</div>
                                    </td>
                                    <td>
                                        <span class="badge bg-info text-white">{{ $section->categories_count }}</span>
                                    </td>
                                    <td>
                                        <button
                                            wire:click="updateSectionStatus({{ $section->id }}, {{ $section->status }})"
                                            class="btn btn-link p-0 border-0"
                                            style="text-decoration: none;">
                                            @if ($section->status == 1)
                                                <span class="badge text-light bg-success" title="Click to Deactivate">Active</span>
                                            @else
                                                <span class="badge text-light bg-secondary" title="Click to Activate">Inactive</span>
                                            @endif
                                        </button>
                                    </td>
                                    <td>
                                        <button wire:click="editSection({{ $section->id }})" class="btn btn-sm btn-outline-warning p-2">
                            <i class="fa fa-edit"></i>
                        </button>


                                        @if ($section->categories_count > 0)
                                            <button type="button" class="btn btn-sm btn-outline-secondary p-2 ml-1" title="Cannot delete: Categories exist">
                                                <i class="fa fa-exclamation-triangle"></i>
                                            </button>
                                        @else
                                            <button
                                                wire:click="deleteSection({{ $section->id }})"
                                                wire:confirm="Are you sure you want to delete this section?"
                                                class="btn btn-sm btn-outline-danger p-2 ml-1"
                                                title="Delete Section">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        @endif
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">No sections found. Start by defining one!</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

       @if($isModalOpen)
    <div class="modal fade show d-block" style="background: rgba(0,0,0,0.5);">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ $sectionId ? 'Edit Section' : 'Add Section' }}</h5>
                    <button type="button" class="close" wire:click="$set('isModalOpen', false)">&times;</button>
                </div>
                <form wire:submit.prevent="saveSection">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Section Name</label>
                            <input type="text" wire:model="name" class="form-control" placeholder="Enter name">
                            @error('name') <span class="text-danger small">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" wire:click="$set('isModalOpen', false)">Close</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @endif
</div>
