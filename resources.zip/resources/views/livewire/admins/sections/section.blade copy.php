<?php

use Livewire\Volt\Component;
use App\Models\Section;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Manage Sections')]
class extends Component {
    public string $title = "Catalogue Sections";

    // Form Properties
    public $name;
    public $sectionId;
    public bool $isModalOpen = false;

    public function with(): array
    {
        Session::put('page', 'sections');
        return [
            'sections' => Section::withCount('categories')
                ->orderBy('id', 'desc')
                ->get()
        ];
    }

    // Opens modal for "Add"
    public function openModal()
    {
        $this->reset(['name', 'sectionId']);
        $this->isModalOpen = true;
    }

    // Opens modal for "Edit"
    public function editSection($id)
    {
        $section = Section::findOrFail($id);
        $this->sectionId = $id;
        $this->name = $section->name;
        $this->isModalOpen = true;
    }

    public function saveSection()
    {
        $this->validate(['name' => 'required|string|max:255']);

        Section::updateOrCreate(
            ['id' => $this->sectionId],
            ['name' => $this->name, 'status' => 1]
        );

        $message = $this->sectionId ? 'Section updated!' : 'Section added!';
        session()->flash('admin_success_message', $message);

        $this->isModalOpen = false;
        $this->reset(['name', 'sectionId']);
    }

    public function updateSectionStatus($sectionId, $currentStatus)
    {
        $newStatus = $currentStatus == 1 ? 0 : 1;
        Section::where('id', $sectionId)->update(['status' => $newStatus]);
        session()->flash('admin_success_message', 'Status updated.');
    }

    public function deleteSection($sectionId)
    {
        Section::destroy($sectionId);
        session()->flash('admin_success_message', 'Deleted successfully!');
    }
}; ?>

<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="card-title text-primary font-weight-bold">
            <i class="fa fa-th-large mr-2"></i> {{ $title }}
        </h4>
        <button wire:click="openModal" class="btn btn-primary">
            <i class="fa fa-plus"></i> Add New Section
        </button>
    </div>

    <div class="table-responsive pt-3">
        <table id="sections" class="table table-hover table-striped">
           <thead>
                                <tr class="bg-light">
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Categories Count</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                @forelse ($sections as $index => $section)
                <tr wire:key="{{ $section->id }}">
                    <td>
                        <button wire:click="editSection({{ $section->id }})" class="btn btn-sm btn-outline-warning p-2">
                            <i class="fa fa-edit"></i>
                        </button>

                        </td>
                </tr>
                @empty
                    @endforelse
            </tbody>
        </table>
    </div>

    @if($isModalOpen)
    <div class="modal fade show d-block" style="background: rgba(0,0,0,0.5);">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ $sectionId ? 'Edit Section' : 'Add Section' }}</h5>
                    <button type="button" class="close" wire:click="$set('isModalOpen', false)">&times;</button>
                </div>
                <form wire:submit.prevent="saveSection">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Section Name</label>
                            <input type="text" wire:model="name" class="form-control" placeholder="Enter name">
                            @error('name') <span class="text-danger small">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" wire:click="$set('isModalOpen', false)">Close</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @endif
</div>
