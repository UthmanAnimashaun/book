<?php

use Livewire\Volt\Component;
use App\Models\Product;
use App\Models\State;
use App\Models\DeliveryFee;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Attributes\Computed; // Imported the caching layer

new #[Layout('layouts.admin.app')]
    #[Title('Product Inventory Control')]
class extends Component {
    public string $title = "Product Inventory";

    // Authorization and configuration state flags
    public int $isAdminRole;
    public int $adminId;
    public bool $hasDeliverySetup = false;
    public ?string $vendorStateName = null;

    public function mount(): void
    {
        Session::put('page', 'products');

        $admin = Auth::guard('admin')->user();
        $this->isAdminRole = (int) $admin->is_admin;
        $this->adminId = (int) $admin->id;
        $this->vendorStateName = $admin->state ?? null;

        // Fast-fail check: Restrict raw access if vendor profile is unapproved
        if ($this->isAdminRole === 2 && $admin->confirm === 'No') {
            redirect()->route('admin.dashboard')
                ->with('admin_error_message', 'Your account is not yet approved. Please make sure to fill in your valid details.');
            return;
        }

        $this->verifyDeliveryConfiguration();
    }

    /**
     * Compute and enforce regional logistics setup checks
     */
    protected function verifyDeliveryConfiguration(): void
    {
        if ($this->isAdminRole === 1) {
            $this->hasDeliverySetup = true;
            return;
        }

        $this->hasDeliverySetup = DeliveryFee::where('vendor_id', $this->adminId)
            ->where('state', $this->vendorStateName)
            ->exists();
    }

    /**
     * COMPUTED PROPERTY: Caches the inventory dataset automatically.
     * This protects the network stream from executing duplicate queries during button clicks.
     */
    #[Computed]
    public function products()
    {
        $productsQuery = Product::with(['section:id,name', 'category:id,category_name']);

        if ($this->isAdminRole === 2) {
            $productsQuery->where('admin_id', $this->adminId);
        }

        return $productsQuery->orderBy('id', 'desc')->get();
    }

    /**
     * Toggle item active/inactive status dynamic cycles
     */
    public function toggleProductStatus(int $productId): void
    {
        $product = Product::find($productId);

        if (!$product) {
            $this->dispatch('toast', message: 'Product profile entries missing.', type: 'error');
            return;
        }



        $newStatus = $product->status == 1 ? 0 : 1;
        $product->update(['status' => $newStatus]);

        // Explicitly clear the computed cache so the visual row status updates immediately
        unset($this->products);

        $statusLabel = $newStatus === 1 ? 'Activated' : 'Suspended';
        $this->dispatch('toast',
            message: "{$product->title} status has been successfully toggled to {$statusLabel}.",
            type: 'success'
        );
    }

    /**
     * Permanently remove product lines and their image paths
     */
    public function deleteProduct(int $productId): void
    {
        $product = Product::find($productId);

        if (!$product) {
            $this->dispatch('toast', message: 'Target file removal failed. Record not found.', type: 'error');
            return;
        }



        if (!empty($product->image_url)) {
            $directories = ['small', 'medium', 'large'];
            foreach ($directories as $dir) {
                $filePath = "images/product_image/{$dir}/" . $product->image_url;
                if (Storage::disk('public')->exists($filePath)) {
                    Storage::disk('public')->delete($filePath);
                }
            }
        }

        $productName = $product->title;
        $product->delete();

        // Explicitly flush cache so the removed row instantly slides away out of view
        unset($this->products);

        $this->dispatch('toast',
            message: "Inventory listing for \"{$productName}\" was permanently removed.",
            type: 'success'
        );
    }
}; ?>

<div class="">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card shadow-sm border-0">
                <div class="card-body">

                    {{-- TOP ACTION ROW CONTROLS --}}
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4 class="card-title text-primary font-weight-bold mb-0">
                            <i class="fas fa-cubes mr-2"></i> {{ $title }}
                        </h4>

                        @if ($hasDeliverySetup)
                            <a href="{{ route('admin.add-edit-product') }}" class="btn btn-primary shadow-sm px-4 py-2">
                                <i class="fa fa-plus mr-1"></i> Add New Product
                            </a>
                        @else
                            <button class="btn btn-primary disabled px-4 py-2" disabled style="cursor: not-allowed;">
                                <i class="fa fa-lock mr-1"></i> Add Product
                            </button>
                        @endif
                    </div>

                    {{-- LOCAL DELIVERY REQUIREMENT WARNING BANNER --}}
                    @if (!$hasDeliverySetup && $isAdminRole === 2)
                        <div class="alert alert-warning border-0 shadow-sm p-4 mb-4" role="alert">
                            <h5 class="alert-heading font-weight-bold text-dark">
                                <i class="fa fa-exclamation-triangle mr-2 text-danger"></i> Verification Action Required!
                            </h5>
                            <p class="mb-3 text-dark">
                                You must define your within-state location delivery fee parameters for your assigned region
                                (<strong>{{ $vendorStateName ?? 'Unassigned' }}</strong>) before the system will allow you to list new products.
                            </p>

                            <div class="progress mb-2 rounded" style="height: 12px; background-color: rgba(0,0,0,0.08);">
                                <div class="progress-bar bg-danger progress-bar-striped progress-bar-animated"
                                     role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="small font-weight-medium mb-3 text-secondary">Logistics Profile Setup Progress: 0 / 1 Active Local Region Configured (0%)</p>

                            <a href="{{ route('admin.location') }}" class="btn btn-sm btn-dark text-white px-3 py-2">
                                <i class="fa fa-map-marker-alt mr-1"></i> Configure My Delivery Rates Now
                            </a>
                        </div>
                    @endif

                    {{-- DATA STORAGE DISPLAY TABLE --}}
                    <div class="table-responsive pt-2">
                        <table id="products" class="table table-hover table-striped align-middle">
                            <thead>
                                <tr class="bg-light">
                                    <th style="width: 5%;">#</th>
                                    <th>Title & Code</th>
                                    <th>Author</th>
                                    <th class="text-center">Product Image</th>
                                    <th>Availability</th>
                                    <th>Category/Section</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center" style="width: 12%;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {{-- MODIFIED: Access the loop data via the $this->products computed method array --}}
                                @forelse ($this->products as $index => $product)
                                    @php
                                        $isOwner = $product->admin_id === $adminId;
                                    @endphp
                                    <tr wire:key="product-row-{{ $product->id }}">
                                        <td class="text-secondary font-weight-medium">{{ $index + 1 }}</td>
                                        <td>
                                            <div class="font-weight-bold text-dark mb-1">{{ $product->title }}</div>
                                            <small class="text-muted font-weight-medium">Code: {{ $product->code }}</small>
                                        </td>
                                        <td class="text-secondary font-weight-medium">{{ $product->author }}</td>
                                        <td class="text-center">
                                            @if (!empty($product->image_url))
                                                <a target="_blank" href="{{ asset('storage/images/product_image/large/'.$product->image_url) }}">
                                                    <img class="img-thumbnail rounded shadow-sm"
                                                         src="{{ asset('storage/images/product_image/small/'.$product->image_url) }}"
                                                         alt="{{ $product->title }} Display Thumb"
                                                         style="width: 45px; height: 45px; object-fit: cover;">
                                                </a>
                                            @else
                                                 <img class="img-thumbnail rounded shadow-sm"
                                                         src="{{ asset('storage/images/product_image/large/default.jpg') }}"
                                                         alt="No image available placeholder"
                                                         style="width: 45px; height: 45px; object-fit: cover;">
                                            @endif
                                        </td>
                                        <td>
                                            @if ($product->stock > 0)
                                                <span class="badge badge-pill badge-success px-2 py-1">In Stock ({{ $product->stock }})</span>
                                            @else
                                                <span class="badge badge-pill badge-danger px-2 py-1">Out of Stock</span>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="font-weight-bold text-dark mb-1">{{ $product->category->category_name ?? 'N/A' }}</div>
                                            <small class="text-muted font-weight-normal">({{ $product->section->name ?? 'N/A' }})</small>
                                        </td>

                                        {{-- INTERACTIVE STATUS SWITCH COMPONENT --}}
                                        <td class="text-center">
                                           
                                                <button
                                                    wire:click="toggleProductStatus({{ $product->id }})"
                                                    wire:loading.attr="disabled"
                                                    wire:target="toggleProductStatus({{ $product->id }})"
                                                    class="btn p-0 border-0 bg-transparent"
                                                    style="outline: none; cursor: pointer;"
                                                    title="Click to toggle availability"
                                                >
                                                    <div wire:loading wire:target="toggleProductStatus({{ $product->id }})" class="spinner-border spinner-border-sm text-primary" role="status">
                                                        <span class="sr-only">Processing...</span>
                                                    </div>

                                                    <div wire:loading.remove wire:target="toggleProductStatus({{ $product->id }})">
                                                        @if ($product->status == 1)
                                                            <span class="badge badge-pill badge-success px-3 py-2" style="font-size: 0.75rem; letter-spacing: 0.3px;">Active</span>
                                                        @else
                                                            <span class="badge badge-pill badge-secondary px-3 py-2" style="font-size: 0.75rem; letter-spacing: 0.3px;">Inactive</span>
                                                        @endif
                                                    </div>
                                                </button>
                                           
                                        </td>

                                        {{-- ACTION CONTROLS --}}
                                        <td class="text-center">
                                           
                                                <a href="{{ route('admin.add-edit-product', $product->id) }}" class="btn btn-sm btn-outline-warning border-0 p-2 shadow-sm mr-1" style="border-radius: 5px;" title="Edit Product Specs">
                                                    <i class="fa fa-edit"></i>
                                                </a>

                                                <button
                                                    wire:click="deleteProduct({{ $product->id }})"
                                                    wire:confirm="Are you sure you want to permanently delete this product from the inventory ledger?"
                                                    wire:loading.attr="disabled"
                                                    class="btn btn-sm btn-outline-danger border-0 p-2 shadow-sm"
                                                    style="border-radius: 5px;"
                                                    title="Delete Product Profile Entry"
                                                >
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                          
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="8" class="text-center text-muted py-5">
                                            <i class="fas fa-boxes d-block mb-3 text-muted style-2x" style="font-size: 2rem; opacity: 0.4;"></i>
                                            No products match your current business index search criteria.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

    @include("pages.messages")
</div>
