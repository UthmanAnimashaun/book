<?php

use Livewire\Volt\Component;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

use Livewire\WithFileUploads;
use App\Models\Product;
use App\Models\Category;
use App\Models\Section;
use App\Models\State;
use App\Models\DeliveryFee;
use App\Models\ProductImage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

use Intervention\Image\ImageManager;
//use Intervention\Image\Drivers\Imagick\Driver;
use Intervention\Image\Drivers\Gd\Driver;



new #[Layout('layouts.admin.app')]
    #[Title('Add-Edit Product')]
class extends Component {

    use WithFileUploads;

    // Component State & Mode Configuration
    public $productId = null;
    public string $title = 'Add New Product';
    public bool $isVendorBlocked = false;

    // Form Binding Properties
    public $category_id;
    public $title_name;
    public $author;
    public $isbn;
    public $code; // Now optional on the frontend for auto-generation
    public $publisher;
    public $publication_date;
    public $description;
    public $price;
    public $discount;
    public $stock;
    public $format;
    public $language;
    public $pages;
    public $weight;
    public $dimensions;


    // File upload elements
    public $image_url;
    public $existingImage;
    public $additional_files = [];

    public function mount(?int $id = null): void
    {
        Session::put('page', 'products');
        $admin = Auth::guard('admin')->user();
     //     echo phpinfo();

        if ((int) $admin->is_admin === 2) {
            $hasDeliverySetup = DeliveryFee::where('vendor_id', $admin->id)
                ->where('state', $admin->state)
                ->exists();

            if (!$hasDeliverySetup) {
                $this->isVendorBlocked = true;
                return;
            }
        }

        if ($id) {
            $this->productId = $id;
            $this->title = 'Edit Product';
            $product = Product::find($id);

            if ($product) {
                $this->loadProductFields($product);
            }
        }
    }

    protected function loadProductFields(Product $product): void
    {
        $this->category_id = $product->category_id;
        $this->title_name = $product->title;
        $this->author = $product->author;
        $this->isbn = $product->isbn;
        $this->code = $product->code;
        $this->publisher = $product->publisher;
        $this->publication_date = $product->publication_date;
        $this->description = $product->description;
        $this->price = $product->price;
        $this->discount = $product->discount;
        $this->stock = $product->stock;
        $this->format = $product->format;
        $this->language = $product->language;
        $this->pages = $product->pages;
        $this->weight = $product->weight;
        $this->dimensions = $product->dimensions;

        $this->existingImage = $product->image_url;
    }

    public function with(): array
    {
        return [
            'categories' => Section::with('categories')->where('status', 1)->get(),
            'additionalImages' => $this->productId ? ProductImage::where('product_id', $this->productId)->get() : []
        ];
    }

    /**
     * Helper method to generate a clean, unique product code using title initials
     */
    protected function generateUniqueProductCode(string $title): string
    {
        // Gather the first letter of each word in uppercase (e.g., "The Great Gatsby" -> "TGG")
        $words = explode(' ', $title);
        $initials = '';
        foreach ($words as $word) {
            $initials .= strtoupper(substr($word, 0, 1));
        }

        // Sanitize to only alphanumeric characters
        $initials = preg_replace('/[^A-Za-z0-9]/', '', $initials);
        if (empty($initials)) {
            $initials = 'PRD';
        }

        // Combine initials with a shortened unique timestamp fraction
        $uniqueSuffix = substr(time(), -5);

        $generatedCode = $initials . '-' . $uniqueSuffix;

        // Loop safety guard check against rare collisions in the database table
        while (Product::where('code', $generatedCode)->exists()) {
            $generatedCode = $initials . '-' . rand(10000, 99999);
        }

        return $generatedCode;
    }

    public function saveProduct()
    {
        if ($this->isVendorBlocked) {
            $this->dispatch('toast', message: 'Unauthorized execution. Set up your delivery rate profile first.', type: 'error');
            return;
        }

        $this->validate([
            'category_id' => 'required',
            'title_name' => 'required|max:255',
            'author' => 'required|max:255',
            'price' => 'required|numeric|min:0.01',
            'stock' => 'required|integer|min:0',
            'format' => 'required',
            'language' => 'required|max:50',
            'pages' => 'required|integer|min:1',
           // FIX: If we are creating a new product ($this->productId is null), force the image to be required!
             'image_url' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', //
            // Code field is now physically validated as nullable here to permit fallback auto-generation logic
            'code' => 'nullable|max:50',
            'isbn' => 'nullable|max:50',
            'publisher' => 'nullable|max:255',
            'publication_date' => 'nullable|date',
            'weight' => 'nullable|max:50',
            'dimensions' => 'nullable|max:50',
        ]);

        $product = $this->productId ? Product::find($this->productId) : new Product();

        // Handle Main Image Processing
        if ($this->image_url) {
            if ($this->existingImage) {
                foreach (['small', 'medium', 'large'] as $size) {
                    Storage::disk('public')->delete("images/product_image/{$size}/" . $this->existingImage);
                }
            }

            $newFilename = time() . '_' . $this->image_url->getClientOriginalName();
            $manager = new ImageManager(new Driver());


            $sizes = ['small' => 250, 'medium' => 500, 'large' => 1000];
            foreach ($sizes as $folder => $pixels) {
                $path = "images/product_image/{$folder}/";
                if (!Storage::disk('public')->exists($path)) {
                    Storage::disk('public')->makeDirectory($path, 0755, true);
                }

                $imgObj = $manager->read($this->image_url->getRealPath());
                $imgObj->cover($pixels, $pixels)->save(Storage::disk('public')->path($path . $newFilename));
            }
            $product->image_url = $newFilename;
        }

        $categoryDetails = Category::find($this->category_id);
        $product->section_id = $categoryDetails->section_id;
        $product->category_id = $this->category_id;
        $product->admin_id = Auth::guard('admin')->user()->id;

        $product->title = $this->title_name;

        // FIX: The slug automatically tracks and overwrites itself on edits whenever the title alters
        $product->slug = Str::slug($this->title_name);

        // FIX: Assign custom input code value, or run auto-generator if field value remains empty
        $product->code = !empty($this->code) ? $this->code : $this->generateUniqueProductCode($this->title_name);

        $product->author = $this->author;
        $product->price = $this->price;
        $product->discount = $this->discount ?? 0;
        $product->stock = $this->stock;
        $product->format = $this->format;
        $product->language = $this->language;
        $product->pages = $this->pages;
        $product->description = $this->description ?? '';

        $product->isbn = $this->isbn;
        $product->publisher = $this->publisher;
        $product->publication_date = $this->publication_date;
        $product->weight = $this->weight;
        $product->dimensions = $this->dimensions;


        $product->status = 1;
        $product->save();

        $message = $this->productId ? 'Product details updated successfully!' : 'Product added successfully!';

        session()->flash('admin_success_message', $message);
        return redirect()->route('admin.products');
    }

    public function updatedAdditionalFiles(): void
    {
        if (!$this->productId) return;

        $this->validate([
            'additional_files.*' => 'image|max:2048'
        ]);

        $path = 'images/product_image/additionals/';
        if (!Storage::disk('public')->exists($path)) {
            Storage::disk('public')->makeDirectory($path, 0755, true);
        }

        $manager = new ImageManager(new Driver());

        foreach ($this->additional_files as $file) {
            $filename = 'APIMG_' . time() . uniqid() . '.' . $file->getClientOriginalExtension();
            Storage::disk('public')->put($path . $filename, file_get_contents($file->getRealPath()));

            $manager->read($file->getRealPath())
                ->scale(500, 500)
                ->save(Storage::disk('public')->path($path . '_resized_' . $filename));

            ProductImage::create([
                'product_id' => $this->productId,
                'images' => $filename
            ]);
        }

        $this->additional_files = [];
        $this->dispatch('toast', message: 'Additional gallery images added successfully.', type: 'success');
    }

    public function deleteAdditionalImage(int $imageId): void
    {
        $galleryItem = ProductImage::find($imageId);

        if ($galleryItem) {
            $basePath = 'images/product_image/additionals/';
            Storage::disk('public')->delete($basePath . $galleryItem->images);
            Storage::disk('public')->delete($basePath . '_resized_' . $galleryItem->images);

            $galleryItem->delete();
            $this->dispatch('toast', message: 'Product image has been successfully deleted.', type: 'success');
        }
    }
}; ?>

<div class="">
    @if ($isVendorBlocked)
        <div class="row justify-content-center pt-5">
            <div class="col-md-8 text-center">
                <div class="card shadow border-0 p-5">
                    <div class="card-body">
                        <i class="fas fa-lock text-warning mb-4" style="font-size: 4rem;"></i>
                        <h3 class="font-weight-bold text-dark mb-3">Fulfillment Configuration Required</h3>


                        <p class="text-secondary mb-4" style="font-size: 1.05rem; line-height: 1.6;">
                            You cannot add or manage products until you have configured your within-state shipping rate parameters.
                            Please complete your logistics parameters first.
                        </p>
                        <a href="{{ route('admin.location') }}" class="btn btn-primary px-4 py-2 shadow-sm">
                            <i class="fa fa-map-marker-alt mr-2"></i> Set Up Delivery Fees
                        </a>
                    </div>
                </div>
            </div>
        </div>
    @else
        <div class="row">
            <div class="col-12">
                <h3 class="font-weight-bold mb-2">Catalogue Management</h3>
                <h6 class="card-title text-muted mb-4">{{ $title }}</h6>
            </div>
        </div>

        <form wire:submit="saveProduct">
            <div class="row">
                {{-- LEFT COLUMN: CORE SPECIFICATIONS --}}
                <div class="col-md-7 grid-margin stretch-card">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h5 class="text-primary mb-4 border-bottom pb-2">General & Core Information</h5>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Category <span class="text-danger">*</span></label>
                                        <select wire:model="category_id" class="form-control @error('category_id') is-invalid @enderror">
                                            <option value="">Select Category</option>
                                            @foreach ($categories as $section)
                                                <optgroup label="{{ $section->name }}">
                                                    @foreach ($section->categories as $category)
                                                        <option value="{{ $category->id }}">-- {{ $category->category_name }}</option>
                                                    @endforeach
                                                </optgroup>
                                            @endforeach
                                        </select>
                                        @error('category_id') <span class="text-danger small">{{ $message }}</span> @enderror
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Title <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control @error('title_name') is-invalid @enderror" wire:model="title_name" placeholder="Book Title">
                                        @error('title_name') <span class="text-danger small">{{ $message }}</span> @enderror
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Author <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control @error('author') is-invalid @enderror" wire:model="author" placeholder="Author Name">
                                        @error('author') <span class="text-danger small">{{ $message }}</span> @enderror
                                    </div>
                               
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>ISBN <small class="text-success">(Optional)</small></label>
                                        <input type="text" class="form-control" wire:model="isbn" placeholder="e.g., 978-0123456789">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Product Code <small class="text-primary">(Leave blank to auto-generate)</small></label>
                                        <input type="text" class="form-control" wire:model="code" placeholder="e.g., SKU-12345">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Publisher <small class="text-success">(Optional)</small></label>
                                        <input type="text" class="form-control" wire:model="publisher" placeholder="Publisher Name">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Publication Date <small class="text-success">(Optional)</small></label>
                                        <input type="date" class="form-control" wire:model="publication_date">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Description</label>
                                <textarea class="form-control" wire:model="description" rows="6" placeholder="Enter product detailed overview description..."></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- RIGHT COLUMN: FINANCIALS, ASSETS & MARKETING --}}
                <div class="col-md-5">
                    <div class="card shadow-sm border-0 mb-4">
                        <div class="card-body">
                            <h5 class="text-success mb-4 border-bottom pb-2">Pricing & Stock</h5>

                            <div class="row">
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-group">
                                        <label>Price <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <div class="input-group-prepend"><span class="input-group-text">N</span></div>
                                            <input type="number" step="0.01" class="form-control text-right @error('price') is-invalid @enderror" wire:model="price" placeholder="0.00">
                                        </div>
                                        @error('price') <span class="text-danger small">{{ $message }}</span> @enderror
                                    </div>
                                </div>
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-group">
                                        <label>Discount (%) <small class="text-success">(Optional)</small></label>
                                        <div class="input-group">
                                            <input type="number" class="form-control text-right" wire:model="discount" placeholder="0">
                                            <div class="input-group-append"><span class="input-group-text">%</span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-group">
                                        <label>Stock Copies <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control @error('stock') is-invalid @enderror" wire:model="stock" placeholder="Qty">
                                        @error('stock') <span class="text-danger small">{{ $message }}</span> @enderror
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="card shadow-sm border-0 mb-4">
                        <div class="card-body">
                            <h5 class="text-info mb-4 border-bottom pb-2">Physical Attributes & Media</h5>

                            <div class="row">
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-group">
                                        <label>Format <span class="text-danger">*</span></label>
                                        <select wire:model="format" class="form-control @error('format') is-invalid @enderror">
                                            <option value="">Select Format</option>
                                            @foreach (['Hardcover', 'Paperback', 'E-book', 'Audiobook'] as $fmt)
                                                <option value="{{ $fmt }}">{{ $fmt }}</option>
                                            @endforeach
                                        </select>
                                        @error('format') <span class="text-danger small">{{ $message }}</span> @enderror
                                    </div>
                                </div>
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-group">
                                        <label>Language <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control @error('language') is-invalid @enderror" wire:model="language" placeholder="English, French, etc.">
                                        @error('language') <span class="text-danger small">{{ $message }}</span> @enderror
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Pages <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control @error('pages') is-invalid @enderror" wire:model="pages" placeholder="Number of pages">
                                        @error('pages') <span class="text-danger small">{{ $message }}</span> @enderror
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-group">
                                        <label>Weight <small class="text-success">(Optional)</small></label>
                                        <input type="text" class="form-control" wire:model="weight" placeholder="e.g., 0.5 kg">
                                    </div>
                                </div>
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-group">
                                        <label>Dimensions <small class="text-success">(Optional)</small></label>
                                        <input type="text" class="form-control" wire:model="dimensions" placeholder="e.g., 16.5x3.5x24.1 cm">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Main Product Image <span class="text-danger">*</span></label>
                                <input type="file" wire:model.live="image_url" class="form-control mb-3">

                                <div class="mt-2">
                                    @if ($image_url)
                                        <img src="{{ $image_url->temporaryUrl() }}" class="img-thumbnail" style="height:100px; width:100px; object-fit: cover;">
                                    @elseif ($existingImage)
                                        <img src="{{ asset('storage/images/product_image/medium/' . $existingImage) }}" class="img-thumbnail" style="height:100px; width:100px; object-fit: cover;">
                                    @else
                                        <small class="text-muted d-block font-italic">Requires a main image.</small>
                                    @endif
                                </div>
                                @error('image_url') <span class="text-danger small d-block mt-1">{{ $message }}</span> @enderror
                            </div>
                        </div>
                    </div>
                </div>

                {{-- FULL WIDTH MARKETING META FOOTER --}}
                <div class="col-12">
                    <div class="card shadow-sm border-0 mb-4">
                        <div class="card-body">




                            <div class="d-flex justify-content-end pt-4 border-top">
                                <a href="{{ route('admin.products') }}" class="btn btn-inverse-danger mr-2">Cancel</a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-save mr-1"></i> Save Product
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        {{-- ADDITIONAL IMAGE GALLERY --}}
        @if ($productId)
            <div class="row pt-2">
                <div class="col-12">
                    <div class="card shadow-sm border-0 p-4">
                        <h6 class="font-weight-bold text-dark mb-3">Additional Product Images Gallery</h6>

                        <div class="form-group border rounded p-3 bg-light">
                            <label class="font-weight-medium">Upload Image Attachments</label>
                            <input type="file" wire:model="additional_files" multiple class="form-control-file">
                            <small class="text-muted d-block mt-2">Upload one or multiple additional images for the product's view scroll.</small>
                            @error('additional_files.*') <span class="text-danger small d-block mt-1">{{ $message }}</span> @enderror
                        </div>

                        <div class="box-container mt-4">
                            @forelse ($additionalImages as $imgItem)
                                <div class="box-gallery" wire:key="additional-image-{{ $imgItem->id }}">
                                    <img src="{{ asset('storage/images/product_image/additionals/_resized_' . $imgItem->images) }}" alt="Additional Clip Asset">
                                    <button type="button" wire:click="deleteAdditionalImage({{ $imgItem->id }})"
                                            wire:confirm="Are you sure you want to delete this additional gallery image?"
                                            class="btn btn-danger btn-sm shadow-sm" title="Remove Image Asset">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </div>
                            @empty
                                <span class="text-muted font-italic py-2">No secondary additional image variants have been attached to this profile.</span>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>
        @endif
    @endif

    {{-- BUTTERUP TOAST POPUP BRIDGE CONFIGURATION --}}
                  <script>
        document.addEventListener('livewire:init', () => {
            Livewire.on('toast', (event) => {
                butterup.toast({
                    message: event.message,
                    type: event.type, // dynamic: 'success' or 'error'
                    icon: true
                });
            });
        });

       

    </script>


    {{-- CSS SPECIFICATIONS --}}
    <style>
        .box-container {
            width: 100%;
            display: flex;
            flex-direction: row;
            gap: 1.25rem;
            justify-content: flex-start;
            flex-wrap: wrap;
            padding: 10px 0;
        }
        .box-gallery {
            width: 110px;
            height: 110px;
            position: relative;
            overflow: hidden;
            border: 1px solid #e3e6f0;
            border-radius: 6px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        .box-gallery img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .box-gallery button {
            position: absolute;
            right: 4px;
            bottom: 4px;
            z-index: 10;
            padding: 4px 6px;
            font-size: 0.75rem;
            border-radius: 4px;
            line-height: 1;
        }
    </style>
</div>