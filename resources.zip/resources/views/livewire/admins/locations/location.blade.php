<?php

use Livewire\Volt\Component;

use App\Models\DeliveryFee;
use App\Models\State;
use Illuminate\Support\Facades\Auth;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Location Fee Settings')]
class extends Component {
    // Form Properties
    public $price_per_kg;
    public $vendorState;
    public $feeIdBeingEdited = null;

    public function mount(): void
    {
        // Fetch the active vendor record from the guard context
        $vendor = Auth::guard('admin')->user();

        // Target and lock the vendor's registered home state
        $this->vendorState = $vendor->state ?? null;

        // Auto-load any existing saved metric for this specific state
        $this->loadVendorFee();
    }

    /**
     * Data provider layout context tracking
     */
    public function with(): array
    {
        return [
            'existingFees' => DeliveryFee::where('vendor_id', Auth::guard('admin')->user()->id)
                ->where('state', $this->vendorState)
                ->get()
        ];
    }

    /**
     * Pre-populate form inputs if a rate has already been saved
     */
    public function loadVendorFee(): void
    {
        $fee = DeliveryFee::where('vendor_id', Auth::guard('admin')->user()->id)
            ->where('state', $this->vendorState)
            ->first();

        if ($fee) {
            $this->feeIdBeingEdited = $fee->id;
            $this->price_per_kg = $fee->price_per_kg;
        }
    }

    /**
     * Process validation and save state rate modifications
     */
    public function save(): void
    {
        if (!$this->vendorState) {
            $this->dispatch('toast', message: 'Error: Your admin account profile does not have an assigned state location.', type: 'error');
            return;
        }

        $this->validate([
            'price_per_kg' => 'required|numeric|min:0',
        ]);

        $vendorId = Auth::guard('admin')->user()->id;

        // Secure updateOrCreate loop explicitly bound to their home state limit matching rules
        $fee = DeliveryFee::updateOrCreate(
            ['vendor_id' => $vendorId, 'state' => $this->vendorState],
            ['price_per_kg' => $this->price_per_kg]
        );

        $this->feeIdBeingEdited = $fee->id;

        $this->dispatch('toast',
            message: "Within-state delivery fee for {$this->vendorState} updated successfully!",
            type: 'success'
        );
    }

    /**
     * Clear and delete regional delivery records
     */
    public function delete(int $id): void
    {
        $delivery = DeliveryFee::where('vendor_id', Auth::guard('admin')->user()->id)
            ->where('id', $id)
            ->first();

        if ($delivery) {
            $delivery->delete();
            $this->reset(['price_per_kg', 'feeIdBeingEdited']);
            $this->dispatch('toast', message: 'Delivery configuration removed successfully.', type: 'success');
        } else {
            $this->dispatch('toast', message: 'Error: Configuration records not found or unauthorized access attempt.', type: 'error');
        }
    }
}; ?>

<div class="content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-10 grid-margin stretch-card">
            <div class="card shadow-lg border-0">
                <div class="card-body p-4">

                    <div class="d-flex align-items-center mb-2">
                        <h4 class="card-title text-primary mb-0 font-weight-bold">
                            <i class="fas fa-truck-loading mr-2"></i> Within-State Delivery Management
                        </h4>
                        <span class="badge badge-pill badge-primary ml-3 px-3 py-1 font-weight-medium" style="font-size: 0.75rem;">
                            Local Routing Active
                        </span>
                    </div>
                    <p class="text-muted mb-4">
                        Set the per-kilogram delivery fulfillment rate for your specific location.
                        <strong class="text-dark">We are strictly doing within-state logistics delivery options for now.</strong>
                    </p>

                    <div class="row mt-4">
                        {{-- ========== LEFT FORM PANELS: LOCK DOWN INPUTS ========== --}}
                        <div class="col-md-5 border-right pr-md-4">
                            <h5 class="mb-3 font-weight-bold text-secondary border-bottom pb-2">Configure Local Rate</h5>

                            <div class="form-group mb-3">
                                <label class="font-weight-medium text-dark">Your Assigned Operational State</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-light text-muted">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </span>
                                    </div>
                                    <input type="text" class="form-control bg-light font-weight-bold text-dark"
                                           value="{{ $vendorState ?? 'Unassigned Location Profile' }}" readonly disabled>
                                </div>
                                <small class="text-muted mt-1 d-block">
                                    Locked to match your registered seller identity profile information automatically.
                                </small>
                            </div>

                            <div class="form-group mb-4">
                                <label for="price_per_kg" class="font-weight-medium text-dark">
                                    Price Per Kilogram (₦) <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-white font-weight-bold">₦</span>
                                    </div>
                                    <input type="number" step="0.01" wire:model="price_per_kg" id="price_per_kg"
                                           class="form-control text-right font-weight-bold @error('price_per_kg') is-invalid @enderror"
                                           placeholder="e.g., 500.00" />
                                </div>
                                @error('price_per_kg') <span class="text-danger small d-block mt-1">{{ $message }}</span> @enderror
                            </div>

                            <button wire:click="save" wire:loading.attr="disabled" class="btn btn-primary btn-block shadow-sm py-2">
                                <i class="fa fa-save mr-1"></i> Save Changes
                            </button>
                        </div>

                        {{-- ========== RIGHT SIDE DISPLAY LOGS ========== --}}
                        <div class="col-md-7 pl-md-4 mt-4 mt-md-0">
                            <h5 class="mb-3 font-weight-bold text-secondary border-bottom pb-2">Active Logistics Matrix</h5>

                            <div class="table-responsive">
                                <table class="table table-hover align-middle" id="deliveryFeesTable">
                                    <thead>
                                        <tr class="bg-light">
                                            <th style="width: 10%;">#</th>
                                            <th>Covered Zone</th>
                                            <th class="text-right">Price / Kg</th>
                                            <th class="text-center" style="width: 20%;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($existingFees as $index => $fee)
                                            <tr wire:key="fee-row-{{ $fee->id }}">
                                                <td class="text-secondary">{{ $index + 1 }}</td>
                                                <td>
                                                    <span class="font-weight-bold text-dark">{{ $fee->state }}</span>
                                                    <small class="text-success d-block" style="font-size: 0.7rem;">
                                                        <i class="fas fa-circle mr-1" style="font-size: 0.5rem;"></i> Active Zone
                                                    </small>
                                                </td>
                                                <td class="text-right font-weight-bold text-dark" style="font-size: 0.95rem;">
                                                    ₦{{ number_format($fee->price_per_kg, 2) }}
                                                </td>
                                                <td class="text-center">
                                                    <button wire:click="delete({{ $fee->id }})"
                                                            wire:confirm="Are you sure you want to permanently disable and delete the delivery fee rate configuration for {{ $fee->state }}?"
                                                            class="btn btn-sm btn-outline-danger border-0 p-2"
                                                            title="Delete Logistics Fee Setting Entry">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="4" class="text-center text-muted py-5">
                                                    <i class="fas fa-shipping-fast d-block mb-2 text-muted" style="font-size: 1.5rem; opacity: 0.5;"></i>
                                                    No shipping rates have been configured for your region yet.
                                                </td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('livewire:init', () => {
            Livewire.on('toast', (event) => {
                butterup.toast({
                    message: event.message,
                    type: event.type,
                    icon: true
                });
            });
        });
    </script>
</div>
