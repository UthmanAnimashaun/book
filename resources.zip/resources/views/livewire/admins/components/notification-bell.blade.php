<?php

use Livewire\Volt\Component;
use App\Models\NotificationRead;
use App\Models\Admin;
use App\Models\User;
use App\Models\OrdersProduct;
use Illuminate\Support\Facades\Auth;

new class extends Component {

    /**
     * Compute unread count dynamically for the current authenticated administrator
     */
    public function with(): array
    {
        $admin = Auth::guard('admin')->user();

        if (!$admin) {
            return ['unreadCount' => 0];
        }

        $unreadCount = 0;

        // 1. Check Unread Orders (Accessible by Super Admin or scoped to Vendor)
        $ordersQuery = OrdersProduct::latest()->take(50)->get();
        foreach ($ordersQuery as $o) {
            if ((int)$admin->is_admin !== 1 && $o->admin_id !== $admin->id) {
                continue; // Skip if vendor doesn't own this book record
            }

            $isRead = NotificationRead::where('admin_id', $admin->id)
                ->where('type', 'order')
                ->where('reference_id', $o->id)
                ->exists();

            if (!$isRead) {
                $unreadCount++;
            }
        }

        // 2. Check Unread Users & Admins (Super Admin Only metrics)
        if ((int)$admin->is_admin === 1) {
            // Unread Customers
            $usersQuery = User::latest()->take(50)->get();
            foreach ($usersQuery as $u) {
                $isRead = NotificationRead::where('admin_id', $admin->id)
                    ->where('type', 'user')
                    ->where('reference_id', $u->id)
                    ->exists();

                if (!$isRead) {
                    $unreadCount++;
                }
            }

            // Unread Staff Logs
            $adminsQuery = Admin::latest()->take(50)->get();
            foreach ($adminsQuery as $a) {
                if ($a->id === $admin->id) continue; // Skip self

                $isRead = NotificationRead::where('admin_id', $admin->id)
                    ->where('type', 'admin')
                    ->where('reference_id', $a->id)
                    ->exists();

                if (!$isRead) {
                    $unreadCount++;
                }
            }
        }

        return [
            'unreadCount' => $unreadCount
        ];
    }
}; ?>

<li class="nav-item">
    <a class="nav-link count-indicator position-relative d-flex align-items-center justify-content-center"
        href="{{ route('admin.notification-center') }}"
        title="View Notification Center">
        <i class="icon-bell mx-0" style="font-size: 1.25rem; color: #4a5568;"></i>

        {{-- Display Badge only if unread items are available --}}
        @if($unreadCount > 0)
            <span class="position-absolute badge rounded-pill bg-danger d-flex align-items-center justify-content-center"
                  style="font-size: 0.65rem; top: 2px; right: -2px; min-width: 16px; height: 16px; padding: 2px; font-weight: bold; line-height: 1; color: white; border: 2px solid #fff;">
                {{ $unreadCount > 99 ? '99+' : $unreadCount }}
            </span>
        @endif
    </a>
</li>
