<?php

use Livewire\Volt\Component;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use App\Models\Admin;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Session;
//use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;



new #[Layout('layouts.admin.auth_layout')]
    #[Title('Staff Reset Password')]
class extends Component {
    public $email = '';

    public function forgot_password(Request $request)
    {
            $this->validate(['email' =>  'required|email|exists:admins,email']);

            // Admin logic: Check for active status[cite: 4]
                    $admin = Admin::where('email', $this->email)->first();
            if ($admin && $admin->status == 0) {
                session()->flash('error', 'Your account has been banned.');
                return;
            }

        // Laravel's built-in password broker handles the token generation and emailing
        $status = Password::sendResetLink(['email' => $this->email]);

        if ($status === Password::RESET_LINK_SENT) {
            session()->flash('success', __($status));
            $this->email = '';
        } else {
            $this->addError('email', __($status));
        }
    }
}; ?>

<div class="auth-wrapper">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4"> {{-- Controlled width --}}
                <div class="auth-form-light text-left py-5 px-4 px-sm-5 shadow-lg rounded-3 bg-white">

                    <div class="text-center brand-logo mb-4">
                        <h3 class="font-weight-bold text-primary">STAFF FORGOT PASSWORD</h3>
            <p class="text-gray-600 mb-6">Please input your registered email address to reset your password.</p>

                    </div>


                @include("pages.messages")

                    <form wire:submit="forgot_password">
                        {{-- Your Inputs Here --}}
                        <div class="form-group mb-3">
                            <input type="email" wire:model="email" class="form-control" placeholder="Email">

                                              <span class="text-danger small">@error('email'){{ $message }}@enderror</span>

                        </div>

                        <button type="submit" class="btn btn-primary w-100 py-3">  Send me reset password link</button>

                         <div class="my-3 d-flex justify-content-end align-items-center">  Have Account?
                  <a href="{{ route('admin.login') }}" class="auth-link text-primary small font-weight-medium">
                   Login here
                  </a>
                </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
