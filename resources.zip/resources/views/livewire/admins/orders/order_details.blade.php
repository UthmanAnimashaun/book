<?php


use Livewire\Volt\Component;
use App\Models\Order;
use App\Models\User;
use App\Models\OrderStatuse;
use App\Models\OrderItemStatuse;
use App\Models\OrdersLog;
use App\Models\OrdersProduct;
use App\Models\Product;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Mail;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Order Details')]
class extends Component {
    // Structural Key Binding States
    public int $orderId;
    public string $title = "Order Details Profile Management";

    // Form Binding Parameters (Overall Order Status)
    public $order_status;
    public $courier_name;
    public $tracking_number;

    // Form Binding Arrays (Per-Item Operations Tracking)
    public array $item_statuses = [];
    public array $item_couriers = [];
    public array $item_tracking = [];

    /**
     * Set up initial hydration data maps
     */
    public function mount(int $id): void
    {
        Session::put('page', 'Orders');
        $this->orderId = $id;

        $order = Order::find($id);
        if ($order) {
            $this->order_status = $order->order_status;
            $this->courier_name = $order->courier_name;
            $this->tracking_number = $order->tracking_number;

            // Pre-populate per-item arrays to isolate live inputs across table iterations
            foreach ($order->orders_products as $item) {
                $this->item_statuses[$item->id] = $item->item_status;
                $this->item_couriers[$item->id] = '';
                $this->item_tracking[$item->id] = '';
            }
        }
    }

    /**
     * Compute and stream database records to view templates
     */
    public function with(): array
    {
        $orderRecord = Order::with(['orders_products.seller'])->find($this->orderId);

        return [
            'orderDetails'     => $orderRecord ? $orderRecord->toArray() : [],
            'OrderStatuse'     => OrderStatuse::where('status', 1)->get()->toArray(),
            'OrderItemStatuse' => OrderItemStatuse::where('status', 1)->get()->toArray(),
            'OrderLogs'        => OrdersLog::where('order_id', $this->orderId)->orderByDesc('id')->get()
        ];
    }

    /**
     * Update global order status profile metrics
     */
    public function updateOrderStatus(): void
    {
        // Enforce role authorization
        if ((int) auth('admin')->user()->is_admin !== 1) {
            $this->dispatch('toast', message: 'Action denied. Only main managers can alter global order indicators.', type: 'error');
            return;
        }

        // Conditional validation rules: Courier variables become strictly required if marked Shipped
        $this->validate([
            'order_status'    => 'required|string',
            'courier_name'    => $this->order_status === 'Shipped' ? 'required|string|max:255' : 'nullable|string|max:255',
            'tracking_number' => $this->order_status === 'Shipped' ? 'required|string|max:255' : 'nullable|string|max:255',
        ]);

        $order = Order::with('orders_products')->find($this->orderId);
        if (!$order) {
            $this->dispatch('toast', message: 'Order reference registry mismatch.', type: 'error');
            return;
        }

        // Write updates to database
        $updatePayload = ['order_status' => $this->order_status];
        if (!empty($this->courier_name) && !empty($this->tracking_number)) {
            $updatePayload['courier_name'] = $this->courier_name;
            $updatePayload['tracking_number'] = $this->tracking_number;
        }
        $order->update($updatePayload);

        // Append historical ledger audit entry
        OrdersLog::create([
            'order_id'     => $this->orderId,
            'order_status' => $this->order_status
        ]);

        // Route transactional customer notification emails
        $this->sendNotificationEmail(
            $order->email,
            $order->name,
            $this->order_status,
            $this->courier_name ?? 'Not Provided',
            $this->tracking_number ?? 'Not Provided',
            $order->toArray()
        );

        $this->dispatch('toast', message: 'Overall order status profile metrics updated successfully.', type: 'success');
    }

    /**
     * Update individual targeted items inside structural order tables
     */
    public function updateOrderItemStatus(int $itemId): void
    {
        $statusValue = $this->item_statuses[$itemId] ?? null;
        $courierValue = $this->item_couriers[$itemId] ?? null;
        $trackingValue = $this->item_tracking[$itemId] ?? null;

        if (!$statusValue) {
            $this->dispatch('toast', message: 'Please select a valid item status option.', type: 'error');
            return;
        }

        // Validate item-level shipping variables conditionally
        if ($statusValue === 'Shipped' && (empty($courierValue) || empty($trackingValue))) {
            $this->dispatch('toast', message: 'Courier and tracking entries are mandatory when an item is marked as Shipped.', type: 'error');
            return;
        }

        $orderItem = OrdersProduct::with('order')->find($itemId);
        if (!$orderItem) {
            $this->dispatch('toast', message: 'Item records not found.', type: 'error');
            return;
        }

        $order = $orderItem->order;

        // Perform transactional adjustments
        $orderItem->update(['item_status' => $statusValue]);

        if (!empty($courierValue) || !empty($trackingValue)) {
            $order->update([
                'courier_name'    => $courierValue ?? $order->courier_name,
                'tracking_number' => $trackingValue ?? $order->tracking_number,
            ]);
            $this->courier_name = $order->courier_name;
            $this->tracking_number = $order->tracking_number;
        }

        OrdersLog::create([
            'order_id'     => $order->id,
            'order_status' => $statusValue,
        ]);

        // Compute overall downstream order states dynamically based on sibling elements
        $this->recalculateOverallOrderStatus($order);

        // Dispatch transactional user alert logs
        $this->sendNotificationEmail(
            $order->email,
            $order->name,
            $statusValue,
            $courierValue ?? 'Not Provided',
            $trackingValue ?? 'Not Provided',
            $order->load('orders_products')->toArray()
        );

        $this->reset(["item_couriers.{$itemId}", "item_tracking.{$itemId}"]);
        $this->dispatch('toast', message: 'Item operational lifecycle updated. Client alert dispatched.', type: 'success');
    }

    /**
     * Evaluate macro status configurations dynamically across sub-item components
     */
    protected function recalculateOverallOrderStatus(Order $order): void
    {
        $orderItems = OrdersProduct::where('order_id', $order->id)->get();
        $statuses = OrderStatuse::where('status', 1)->pluck('name')->toArray();

        if ($orderItems->every(fn($item) => $item->item_status === 'Delivered')) {
            $overallStatus = 'Delivered';
        } elseif ($orderItems->every(fn($item) => $item->item_status === 'New')) {
            $overallStatus = 'New';
        } elseif ($orderItems->contains(fn($item) => $item->item_status === 'Delivered')) {
            $overallStatus = 'Partially Delivered';
        } elseif ($orderItems->contains(fn($item) => $item->item_status === 'Cancelled')) {
            $overallStatus = 'Cancelled';
        } elseif ($orderItems->contains(fn($item) => $item->item_status === 'Shipped')) {
            $overallStatus = 'Shipped';
        } elseif ($orderItems->contains(fn($item) => $item->item_status === 'In Process')) {
            $overallStatus = 'In Process';
        } else {
            $lastItemStatus = $orderItems->last()->item_status;
            $overallStatus = in_array($lastItemStatus, $statuses) ? $lastItemStatus : 'New';
        }

        $order->update(['order_status' => $overallStatus]);
        $this->order_status = $overallStatus;
    }

    /**
     * Dispatch notification email packages
     */
    protected function sendNotificationEmail($email, $name, $status, $courier, $tracking, array $details): void
    {
        $messageData = [
            'email'           => $email,
            'name'            => $name,
            'order_id'        => $this->orderId,
            'orderDetails'    => $details,
            'order_status'    => $status,
            'courier_name'    => $courier,
            'tracking_number' => $tracking
        ];

        try {
            Mail::send('emails.order_status', $messageData, function ($message) use ($email) {
                $message->to($email)->subject('Order Status Updated - Book Buffet');
            });
        } catch (\Exception $e) {
            // Log anomalies silently without disrupting database transaction states
        }
    }
}; ?>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">

                <a href="{{ route('admin.orders') }}" class="btn btn-sm btn-outline-secondary mb-4">
                    <i class="fa fa-arrow-left mr-1"></i> Back to Orders
                </a>

                <h2 class="font-weight-bold text-dark mb-4">{{ $title }} #{{ $orderId }}</h2>

                <div class="row justify-content-start">
                    <div class="col-xl-6 col-lg-7 col-md-10">
                        <div class="mb-4">
                            <h4 class="h5 font-weight-bold text-primary mb-2">Update Overall Order Status</h4>
                            <p class="text-muted small mb-3">
                                Controls the parent tracking classification parameters across all associated items.
                            </p>

                            @if((int) auth('admin')->user()->is_admin === 1)
                                <form wire:submit.prevent="updateOrderStatus" class="p-3 border rounded shadow-sm bg-light">
                                    <div class="form-group mb-3">
                                        <label for="order_status" class="font-weight-bold small text-dark">New Macro Classification</label>
                                        <select wire:model.live="order_status" id="order_status" class="form-control @error('order_status') is-invalid @enderror">
                                            <option value="" disabled>Select status...</option>
                                            @foreach ($OrderStatuse as $status)
                                                <option value="{{ $status['name'] }}">{{ $status['name'] }}</option>
                                            @endforeach
                                        </select>
                                        @error('order_status') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                    </div>

                                    {{-- CONDITIONAL SHIPPING FIELD ELEMENTS VIA REACTIVE WIRE:MODEL ASSIGNMENT --}}
                                    @if($order_status === 'Shipped')
                                        <div class="row fade-in-styles transition-all p-2 bg-white rounded border mb-3 mx-0">
                                            <div class="col-md-6 form-group pl-0 pr-md-2 mb-2 mb-md-0">
                                                <label class="small font-weight-medium">Courier Name <span class="text-danger">*</span></label>
                                                <input type="text" wire:model="courier_name" class="form-control @error('courier_name') is-invalid @enderror" placeholder="e.g., DHL Logistics">
                                                @error('courier_name') <div class="text-danger small mt-1" style="font-size:0.75rem;">{{ $message }}</div> @enderror
                                            </div>
                                            <div class="col-md-6 form-group pr-0 pl-md-2 mb-0">
                                                <label class="small font-weight-medium">Tracking Number <span class="text-danger">*</span></label>
                                                <input type="text" wire:model="tracking_number" class="form-control @error('tracking_number') is-invalid @enderror" placeholder="Ref/Waybill Code">
                                                @error('tracking_number') <div class="text-danger small mt-1" style="font-size:0.75rem;">{{ $message }}</div> @enderror
                                            </div>
                                        </div>
                                    @endif

                                    <div class="pt-2">
                                        <button type="submit" class="btn btn-success btn-block py-2 font-weight-bold" wire:loading.attr="disabled">
                                            <span wire:loading.remove>Commit Overall Upgrades</span>
                                            <span wire:loading>Syncing Status...</span>
                                        </button>
                                    </div>
                                </form>
                            @else
                                <div class="alert alert-light border p-3 small text-muted">
                                    <i class="fa fa-info-circle mr-1"></i> Macro order modifiers are restricted to primary administrator profile permissions.
                                </div>
                            @endif
                        </div>
                    </div>
                </div>

                <hr class="my-4">

                {{-- USER PROFILE METADATA DETAILS CARD GROUPS --}}
                <div class="row mb-4">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <div class="card h-100 border border-light shadow-none bg-white">
                            <div class="card-header bg-light font-weight-bold text-dark py-2">
                                <i class="fa fa-user-circle mr-2 text-secondary"></i> Personal Consignee Details
                            </div>
                            <div class="card-body p-3 text-dark">
                                <p class="mb-2"><strong>Recipient Name:</strong> {{ $orderDetails['name'] ?? 'N/A' }}</p>
                                <p class="mb-2"><strong>Delivery Destination Address:</strong><br>
                                    <span class="text-secondary">
                                        {{ $orderDetails['address'] ?? '' }}<br>
                                        {{ $orderDetails['city'] ?? '' }}, {{ $orderDetails['state'] ?? '' }}
                                    </span>
                                </p>
                                <p class="mb-2"><strong>Communication Line Email:</strong> {{ $orderDetails['email'] ?? 'N/A' }}</p>
                                <p class="mb-0"><strong>Mobile Endpoint contact:</strong> {{ $orderDetails['mobile'] ?? 'N/A' }}</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card h-100 border border-light shadow-none bg-white">
                            <div class="card-header bg-light font-weight-bold text-dark py-2">
                                <i class="fa fa-receipt mr-2 text-secondary"></i> Transaction Invoicing Breakdown
                            </div>
                            <div class="card-body p-3 text-dark">
                                <p class="mb-2"><strong>Fulfillment Timestamp:</strong> {{ !empty($orderDetails['created_at']) ? date_formatter($orderDetails['created_at']) : 'N/A' }}</p>
                                <p class="mb-2">
                                    <strong>Transactional State:</strong>
                                    @php $s = $order_status; @endphp
                                    <span class="badge badge-pill font-weight-bold {{ $s === 'Delivered' || $s === 'Paid' ? 'badge-success' : ($s === 'Cancelled' ? 'badge-danger' : 'badge-info') }} px-2 py-1">
                                        {{ $s ?? 'Pending' }}
                                    </span>
                                </p>
                                <p class="mb-2"><strong>Payment Gateway Integration:</strong> {{ $orderDetails['payment_gateway'] ?? '—' }}</p>
                                <p class="mb-0 text-primary font-weight-bold" style="font-size: 1.05rem;">
                                    <strong>Invoiced Grand Total:</strong> ₦{{ number_format($orderDetails['grand_total'] ?? 0, 2) }}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- DYNAMIC ROW CATALOG SPECIFICATIONS --}}
                <h5 class="font-weight-bold text-secondary mb-3 mt-4"><i class="fa fa-boxes mr-2"></i>Consolidated Items Ledger</h5>
                <div class="table-responsive border rounded bg-white">
                    <table class="table table-striped table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>Seller Account</th>
                                <th>Product Details</th>
                                <th class="text-center">Thumbnail</th>
                                <th>SKU Code</th>
                                <th>Format</th>
                                <th class="text-center">Qty</th>
                                <th style="min-width: 280px;">Item Workflow Status</th>
                                <th class="text-right">Unit Price</th>
                                <th class="text-right">Logistics Fee</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($orderDetails['orders_products'] as $product)
                                <tr wire:key="product-row-{{ $product['id'] }}">
                                    <td>
                                        <div class="font-weight-bold text-dark">{{ $product['seller']['name'] ?? 'Seller not found' }}</div>
                                        <small class="text-muted">{{ $product['seller']['email'] ?? '' }}</small>
                                    </td>
                                    <td class="font-weight-medium text-dark">{{ $product['product_name'] }}</td>
                                    <td class="text-center">
                                        @php
                                            $imgName = Product::getProductImage($product['product_id']);
                                            $imgUrl = asset("storage/images/product_image/small/{$imgName}");
                                        @endphp
                                        <a href="{{ route('product/', $product['product_id']) }}" target="_blank">
                                            <img src="{{ $imgUrl }}" alt="Asset Preview" class="img-thumbnail rounded shadow-sm" style="width: 50px; height: 50px; object-fit: cover;">
                                        </a>
                                    </td>
                                    <td class="text-monospace small">{{ $product['product_code'] }}</td>
                                    <td><span class="badge badge-light border text-secondary">{{ $product['product_format'] }}</span></td>
                                    <td class="text-center font-weight-bold text-dark">{{ $product['product_qty'] }}</td>

                                    {{-- SEPARATED INLINE LIVEWIRE ITEM UPDATER MODULE --}}
                                    <td>
                                        <div class="p-2 border rounded bg-white shadow-none">
                                            <div class="form-group mb-2">
                                                <select wire:model.live="item_statuses.{{ $product['id'] }}" class="form-control form-control-sm font-weight-medium">
                                                    <option value="" disabled>Select state...</option>
                                                    @foreach ($OrderItemStatuse as $status)
                                                        <option value="{{ $status['name'] }}">{{ $status['name'] }}</option>
                                                    @endforeach
                                                </select>
                                            </div>

                                            {{-- CONDITIONAL LOGISTICS EXTRA BLOCK SPECIFIC TO MATCH TARGETED ITEM ID MATRIX --}}
                                            @if(($item_statuses[$product['id']] ?? '') === 'Shipped')
                                                <div class="p-2 bg-light rounded border mb-2 mx-0 transition-all">
                                                    <input type="text" wire:model="item_couriers.{{ $product['id'] }}" class="form-control form-control-sm mb-1" placeholder="Courier Name">
                                                    <input type="text" wire:model="item_tracking.{{ $product['id'] }}" class="form-control form-control-sm mb-0" placeholder="Tracking Number">
                                                </div>
                                            @endif

                                            <button type="button" wire:click="updateOrderItemStatus({{ $product['id'] }})" wire:loading.attr="disabled" class="btn btn-primary btn-sm btn-block py-1 text-white font-weight-bold shadow-sm">
                                                <i class="fa fa-sync-alt mr-1"></i> Update Item
                                            </button>
                                        </div>
                                    </td>

                                    <td class="text-right font-weight-medium text-dark">₦{{ number_format($product['product_price'] ?? 0, 2) }}</td>
                                    <td class="text-right text-secondary">₦{{ number_format($product['shipping_charges'] ?? 0, 2) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                {{-- CHRONOLOGICAL TIMELINE TRACKING AUDIT ENTRIES --}}
                <h5 class="font-weight-bold text-secondary mb-3 mt-5"><i class="fa fa-history mr-2"></i>Historical Audit Lifecycle Logs</h5>
                <div class="border rounded bg-light p-4 shadow-none">
                    <div class="timeline-wrapper pl-3" style="border-left: 2px solid #e3e6f0;">
                        @forelse ($OrderLogs as $log)
                            @php
                                $status = $log->order_status;
                                $colorClass = 'text-secondary';
                                $iconClass = 'fa fa-info-circle';

                                if ($status == 'Delivered') { $colorClass = 'text-success'; $iconClass = 'fa fa-check-circle'; }
                                elseif ($status == 'Cancelled') { $colorClass = 'text-danger'; $iconClass = 'fa fa-times-circle'; }
                                elseif ($status == 'New') { $colorClass = 'text-primary'; $iconClass = 'fa fa-clipboard-list'; }
                                elseif (str_contains(strtolower($status), 'shipped')) { $colorClass = 'text-info'; $iconClass = 'fa fa-truck'; }
                            @endphp

                            <div class="timeline-item d-flex align-items-start mb-4 position-relative" style="margin-left: -33px;">
                                <div class="timeline-dot bg-white rounded-circle shadow-sm d-flex align-items-center justify-content-center border" style="width: 34px; height: 34px; min-width:34px;">
                                    <i class="{{ $iconClass }} {{ $colorClass }}" style="font-size: 0.95rem;"></i>
                                </div>

                                <div class="timeline-content flex-grow-1 pl-3 pt-1 text-dark">
                                    <span class="font-weight-bold {{ $colorClass }} d-block mb-1" style="font-size: 0.95rem;">
                                        {{ $status }}
                                    </span>
                                    <small class="text-muted d-block mb-2">{{ date_formatter($log->created_at) }}</small>

                                    @if (in_array($status, ['Shipped', 'Delivered']) && !empty($courier_name))
                                        <div class="p-2 border bg-white rounded small inline-block text-secondary" style="max-width: 320px; font-size:0.8rem; line-height:1.4;">
                                            <div><strong>Logistics Provider:</strong> {{ $courier_name }}</div>
                                            <div><strong>Tracking Reference:</strong> <span class="text-monospace text-dark font-weight-bold">{{ $tracking_number }}</span></div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        @empty
                            <div class="text-center text-muted py-3 small font-italic">
                                <i class="fa fa-folder-open d-block mb-1" style="font-size:1.25rem;"></i> No logged transition data available.
                            </div>
                        @endforelse
                    </div>
                </div>

            </div>
        </div>
    </div>

    {{-- SYSTEM BUTTERUP TOAST POPUP BRIDGE BINDINGS --}}
 @include('pages.messages')
</div>
