<?php

use Livewire\Volt\Component;
use App\Models\Order;
use App\Models\User;
use App\Models\Website;
use Barryvdh\DomPDF\PDF;
use Illuminate\Support\Facades\Session;

use Milon\Barcode\DNS1DFacade as DNS1D;
use Dompdf\Dompdf;
use Dompdf\Options;
use Dompdf\Adapter\CPDF as Driver;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Order Invoice')]
class extends Component {
    // State metrics binding parameters
    public int $orderId;
    public string $title = "Order Invoice Control Panel";

    // Dynamic tracking percentage tracking configurations
    public int $orderProgressPercentage = 0;

    /**
     * Component hydration cycle setup hooks
     */
    public function mount(int $id): void
    {
        Session::put('page', 'Orders');
        $this->orderId = $id;

        $this->calculateMacroProgress();
    }

    /**
     * Compute workflow milestone metrics visually
     */
    protected function calculateMacroProgress(): void
    {
        $order = Order::find($this->orderId);
        if (!$order) return;

        $this->orderProgressPercentage = match ($order->order_status) {
            'New' => 15,
            'In Process' => 40,
            'Shipped' => 70,
            'Delivered' => 100,
            'Cancelled' => 0,
            default => 25,
        };
    }

    /**
     * Data stream map provider pipeline
     */
    public function with(): array
    {
        $orderDetails = Order::with('orders_products.seller')->find($this->orderId);

        return [
            'order'    => $orderDetails ? $orderDetails->toArray() : [],
            'website'  => Website::first()
        ];
    }

    /**
     * Compile document structures dynamically to write A4 PDF attachments to browser stream
     */
   /**
 * Compile document structures dynamically to write A4 PDF attachments to browser stream
 */
public function downloadInvoicePDF()
{
    $orderDetails = Order::with('orders_products.seller')->find($this->orderId);
    $website = Website::first();

    if (!$orderDetails) {
        $this->dispatch('toast', message: 'Invoice print generation encountered anomalies.', type: 'error');
        return;
    }

    // FIX: Point this directly to the actual blade file path
    $htmlOutput = view()->file(resource_path('views/pages/admins/orders/⚡order_invoice.blade.php'), [
        'order'    => $orderDetails ? $orderDetails->toArray() : [],
        'website'  => $website,
        'orderId'  => $this->orderId,
        'orderProgressPercentage' => $this->orderProgressPercentage,
    ])->render();

    // Use Dompdf directly to avoid missing facade/class issues
    $dompdf = new \Dompdf\Dompdf();
    $dompdf->loadHtml($htmlOutput);
    $dompdf->setPaper('A4', 'landscape');
    $dompdf->render();

    return response()->streamDownload(
        fn () => print($dompdf->output()),
        "Invoice_Order_#{$this->orderId}.pdf"
    );
}
}; ?>

<div class="content-wrapper text-dark">
    {{-- TOP NAVIGATION HEADER ROW CONTROLS --}}
    <div class="d-flex justify-content-between align-items-center mb-4 no-print">
        <a href="{{ route('admin.orders') }}" class="btn btn-sm btn-outline-secondary">
            <i class="fa fa-arrow-left mr-1"></i> Orders Ledger
        </a>
        <div>
            <button type="button" class="btn btn-sm btn-info mr-2" onclick="window.print();">
                <i class="fa fa-print mr-1"></i> Print View
            </button>
            <button type="button" wire:click="downloadInvoicePDF" class="btn btn-sm btn-danger shadow-sm">
                <i class="fas fa-file-pdf mr-1"></i> Export PDF Document
            </button>
        </div>
    </div>

    {{-- INTERACTIVE COMPACT MACRO WORKFLOW TRACKING SUB-SYSTEM PANEL --}}
    @if(!empty($order))
        <div class="card shadow-sm border-0 mb-4 no-print" style="border-radius: 8px;">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="font-weight-bold text-primary mb-0">Fulfillment Milestone Progress</h5>
                    <span class="small text-muted font-weight-bold">Status Profile: {{ $order['order_status'] }}</span>
                </div>

                <div class="progress mb-2 rounded-pill" style="height: 10px; background-color: rgba(0,0,0,0.06);">
                    {{-- <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"
                         style="width: {{ $this->orderProgressPercentage }}%; background-color: #a8729a;"
                         aria-valuenow="{{ $this->orderProgressPercentage }}" aria-valuemin="0" aria-valuemax="100"></div> --}}

                         {{-- To this: --}}
<div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"
     style="width: {{ $orderProgressPercentage ?? 0 }}%; background-color: #a8729a;"
     aria-valuenow="{{ $orderProgressPercentage ?? 0 }}" aria-valuemin="0" aria-valuemax="100"></div>
                </div>

                <div class="d-flex justify-content-between small text-muted font-weight-medium px-1">
                    <span>Ordered</span>
                    <span>Processing</span>
                    <span>Out for Delivery</span>
                    <span>Delivered</span>
                </div>
            </div>
        </div>
    @endif

    {{-- STRUCTURAL STANDARD INVOICE DOCUMENT SHEET COMPONENT --}}
    <div class="invoice-document-sheet p-5 bg-white border rounded shadow-sm">
        <header class="clearfix mb-4">
            <div id="invoice-header-branding" class="d-flex justify-content-between align-items-start border-bottom pb-4 mb-4">
                {{-- Left: From Metadata Context Info --}}
                <div class="company-identity-block">
                    <h1 class="font-weight-bold text-uppercase tracking-wider mb-2 text-primary" style="font-size: 2.2rem; border:0; background:none; text-align:left; color:#a8729a !important;">
                        {{ $website->name ?? 'BOOK BUFFET' }}
                    </h1>
                    <div class="text-secondary small">
                        <div>{{ $website->location ?? 'Headquarters Routing Hub' }}</div>
                        @if(!empty($website->location2)) <div>{{ $website->location2 }}</div> @endif
                        <div><i class="fa fa-phone mr-1"></i> {{ $website->phone_number ?? 'N/A' }}</div>
                        <div><i class="fa fa-envelope mr-1"></i> {{ $website->email ?? 'N/A' }}</div>
                    </div>
                </div>

                {{-- Right: Document Invoicing Identifier Signatures --}}
                <div class="text-right">
                    <h2 class="text-muted font-weight-light text-uppercase mb-1" style="font-size: 1.8rem; letter-spacing:1px;">Invoice Document</h2>
                    <div class="font-weight-bold text-dark" style="font-size: 1.1rem;">Order #{{ $orderId }}</div>
                    <div class="small text-muted mt-1">Date: {{ !empty($order['created_at']) ? date_formatter($order['created_at']) : 'N/A' }}</div>

                    <div class="barcode-wrapper d-inline-block pt-2">
                        {!! Milon\Barcode\Facades\DNS1DFacade::getBarcodeHTML((string)$orderId, 'C39', 1.2, 38) !!}
                    </div>
                </div>
            </div>

            {{-- Client Destination Addresses Metadata Logs --}}
            <div id="invoice-routing-details" class="row mb-5">
                <div class="col-sm-6">
                    <div class="text-muted text-uppercase font-weight-bold small mb-2">Delivered Target Consignee:</div>
                    <div class="font-weight-bold text-dark mb-1" style="font-size: 1.05rem;">{{ $order['name'] ?? 'Guest Customer' }}</div>
                    <div class="text-secondary small pr-md-5" style="line-height: 1.5;">
                        {{ $order['address'] ?? '' }}<br>
                        {{ $order['city'] ?? '' }}, {{ $order['state'] ?? '' }}
                    </div>
                    <div class="text-secondary small mt-2">
                        <div><i class="fa fa-envelope mr-1" style="font-size:0.75rem;"></i> {{ $order['email'] ?? 'N/A' }}</div>
                        <div><i class="fa fa-phone mr-1" style="font-size:0.75rem;"></i> {{ $order['mobile'] ?? 'N/A' }}</div>
                    </div>
                </div>

                <div class="col-sm-6 text-sm-right mt-3 mt-sm-0">
                    <div class="text-muted text-uppercase font-weight-bold small mb-2">Payment Framework:</div>
                    <div class="font-weight-bold text-dark mb-1">{{ $order['payment_gateway'] ?? 'COD Mode' }}</div>
                    {{-- <div class="small text-secondary">Method: {{ $order['payment_method'] ?? 'Standard Route' }}</div> --}}

                    {{-- @if(($order['payment_status'] ?? '') === 'Paid')
                        <div class="mt-2"><span class="badge badge-success px-3 py-2 font-weight-bold">Transaction Paid</span></div>
                    @else
                        <div class="mt-2"><span class="badge badge-warning px-3 py-2 font-weight-bold text-dark">Payment Pending</span></div>
                    @endif --}}
                </div>
            </div>
        </header>

        {{-- INVOICED TRANSACTION ACCOUNTS DATA TABLE ITEMS --}}
        <main>
            <div class="table-responsive">
                <table class="table table-striped border-bottom mb-4">
                    <thead class="bg-light">
                        <tr class="text-secondary">
                            <th>Vendor Information</th>
                            <th>Product Reference Code</th>
                            <th class="text-left">Format Parameters</th>
                            <th class="text-right">Unit Net Price</th>
                            <th class="text-center">Quantity</th>
                            <th class="text-right">Fulfillment Handling</th>
                            <th class="text-right">Gross Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php $calculatedSubTotal = 0; @endphp
                        @if(!empty($order['orders_products']))
                            @foreach ($order['orders_products'] as $item)
                                @php
                                    $itemTotal = (float)$item['product_price'] * (int)$item['product_qty'];
                                    $calculatedSubTotal += $itemTotal;
                                @endphp
                                <tr class="text-dark">
                                    <td>
                                        <div class="font-weight-bold">{{ $item['seller']['name'] ?? 'Seller profile entry unassigned' }}</div>
                                        <small class="text-muted">{{ $item['seller']['email'] ?? '' }}</small>
                                    </td>
                                    <td>
                                        <div class="mb-1">{{ $item['product_code'] }}</div>
                                        <div class="d-inline-block bg-white border p-1 rounded">
                                            {!! Milon\Barcode\Facades\DNS1DFacade::getBarcodeHTML($item['product_code'], 'C39', 0.9, 24) !!}
                                        </div>
                                    </td>
                                    <td><span class="badge badge-light border">{{ $item['product_format'] }}</span></td>
                                    <td class="text-right font-weight-medium">₦{{ number_format($item['product_price'], 2) }}</td>
                                    <td class="text-center font-weight-bold">{{ $item['product_qty'] }}</td>
                                    <td class="text-right text-secondary">₦{{ number_format($item['shipping_charges'] ?? 0, 2) }}</td>
                                    <td class="text-right font-weight-bold text-dark">₦{{ number_format($itemTotal, 2) }}</td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>

            {{-- FINANCIAL ACCRUAL CALCULATION SIDEBAR ROW SUMMARY PANEL --}}
            <div class="row justify-content-end text-dark">
                <div class="col-md-5 col-sm-7">
                    <div class="p-3 bg-light rounded border">
                        <div class="d-flex justify-content-between mb-2 pb-2 border-bottom small text-secondary">
                            <span>Cumulative Net Subtotal:</span>
                            <span class="font-weight-bold text-dark">₦{{ number_format($calculatedSubTotal, 2) }}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2 pb-2 border-bottom small text-secondary">
                            <span>Regional Logistics Fee Summary:</span>
                            <span class="font-weight-bold text-dark">₦{{ number_format((float)($order['shipping_charges'] ?? 0), 2) }}</span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center pt-1 text-primary">
                            <span class="font-weight-bold text-uppercase" style="letter-spacing:0.5px;">Grand Total Due:</span>
                            <span class="h3 font-weight-bold mb-0 text-dark">₦{{ number_format((float)($order['grand_total'] ?? 0), 2) }}</span>
                        </div>

                        @if(($order['payment_method'] ?? '') === 'COD' || ($order['payment_status'] ?? '') === 'Paid')
                            <div class="text-right text-success font-weight-bold mt-3 small text-uppercase">
                                <i class="fa fa-check-circle mr-1"></i> Transaction Fully Liquidated
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            <div id="invoice-footer-notices" class="mt-5 pt-4 border-top text-muted small">
                <div class="font-weight-bold text-dark mb-1">Invoicing Guidelines & Notices:</div>
                <div class="font-italic">Thank you for patronizing {{ $website->name ?? 'Book Buffet' }}. All processed purchases fall under standardized account transaction profiles.</div>
            </div>
        </main>
    </div>

    {{-- GLOBAL DYNAMIC TOAST NOTIFICATION INITIALIZERS --}}
   @include("pages.messages")

    {{-- MEDIA LOGISTICS INLINE STYLES SHEET OVERRIDES FOR BROWSER PRINT ENGINE HOOKS --}}
    <style>
        @media print {
            .no-print, .main-panel footer, .sidebar, .navbar { display: none !important; }
            .content-wrapper { padding: 0 !important; background: #fff !important; }
            .invoice-document-sheet { border: 0 !important; box-shadow: none !important; padding: 0 !important; }
            body { background: #fff !important; color: #000 !important; }
        }

    </style>
</div>
