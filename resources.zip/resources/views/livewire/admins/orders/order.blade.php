<?php

use Livewire\Volt\Component;

use App\Models\Order;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Customer Orders Control')]
class extends Component {
    public string $title = "Customer Orders";

    /**
     * Compute and scope orders down dynamically depending on admin roles
     */
    public function with(): array
    {
        Session::put('page', 'Orders');

        $admin = Auth::guard('admin')->user();
        $isAdminRole = (int) $admin->is_admin;
        $adminId = $admin->id;

        $ordersQuery = Order::orderByDesc('id');

        if ($isAdminRole === 2) {
            // Vendor filtering protocol scope
            $ordersQuery->whereHas('orders_products', function ($query) use ($adminId) {
                $query->where('admin_id', $adminId);
            });

            $ordersQuery->with(['orders_products' => function ($query) use ($adminId) {
                 $query->where('admin_id', $adminId)->with('seller:id,name,email');
            }]);
        } else {
            // Super Admin unrestricted pipeline overview scope
            $ordersQuery->with('orders_products.seller:id,name,email');
        }

        return [
            'orders' => $ordersQuery->get()
        ];
    }
}; ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card shadow-sm border-0">
                <div class="card-body">

                    {{-- HEADER TITLE BANNER COMPONENTS --}}
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4 class="card-title text-primary font-weight-bold mb-0">
                            <i class="fa fa-shopping-basket mr-2"></i> {{ $title }}
                        </h4>
                        <a href="{{ route('admin.dashboard') }}" class="btn btn-sm btn-secondary shadow-sm">
                            <i class="fa fa-arrow-left mr-1"></i> Dashboard
                        </a>
                    </div>

                    {{-- RESPONSIBLE BALANCED DATA TABLE --}}
                    <div class="table-responsive pt-2">
                        <table id="orders" class="table table-hover table-striped align-middle">
                            <thead>
                                <tr class="bg-light">
                                    <th style="width: 8%;">Order ID</th>
                                    <th>Fulfillment Date</th>
                                    <th>Items Ordered</th>
                                    <th>Customer Info</th>
                                    <th>Assigned Seller</th>
                                    <th class="text-right">Total Payable</th>
                                    <th class="text-center">Order Status</th>
                                    <th class="text-center">Gateway Mode</th>
                                    <th class="text-center" style="width: 12%;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($orders as $order)
                                    <tr wire:key="order-row-{{ $order->id }}">
                                        {{-- Order Key ID Identifier --}}
                                        <td>
                                           <a href="{{ route('admin.orders.details', $order->id) }}" class="font-weight-bold text-primary">
    #{{ $order->id }}
</a>
                                        </td>

                                        {{-- Formatted Time Arrays Line Components --}}
                                        <td>
                                            <div class="font-weight-medium text-dark">
                                                {{ \Carbon\Carbon::parse($order->created_at)->format('M d, Y') }}
                                            </div>
                                            <small class="text-muted d-block mt-1">
                                                <i class="far fa-clock mr-1"></i>{{ \Carbon\Carbon::parse($order->created_at)->format('h:i A') }}
                                            </small>
                                        </td>

                                        {{-- Grouped Items Allocation Row Block --}}
                                        <td>
                                            <div class="d-flex flex-column">
                                                @foreach ($order->orders_products->take(2) as $product)
                                                    <span class="font-weight-medium text-dark mb-1" style="font-size: 0.88rem;">
                                                        {{ $product->product_name }}
                                                        <span class="text-primary font-weight-bold">(x{{ $product->product_qty }})</span>
                                                    </span>
                                                @endforeach
                                                @if ($order->orders_products->count() > 2)
                                                    <small class="text-muted font-weight-medium mt-1">
                                                        <i class="fas fa-plus-circle mr-1 text-secondary"></i>+{{ $order->orders_products->count() - 2 }} more item(s)
                                                    </small>
                                                @endif
                                            </div>
                                        </td>

                                        {{-- Buyer Identification Blocks --}}
                                        <td>
                                            <div class="font-weight-bold text-dark mb-1">{{ $order->name }}</div>
                                            <small class="text-secondary"><i class="far fa-envelope mr-1"></i>{{ $order->email }}</small>
                                        </td>

                                        {{-- Seller Profile Routing Pass loops --}}
                                        <td>
                                            <div class="d-flex flex-column">
                                                @foreach ($order->orders_products->unique('admin_id') as $product)
                                                    @if ($product->seller)
                                                        <span class="text-dark" style="font-size: 0.85rem;">
                                                            <i class="fas fa-store mr-1 text-muted" style="font-size: 0.75rem;"></i>{{ $product->seller->name }}
                                                        </span>
                                                    @else
                                                        <span class="text-danger font-italic small">
                                                            <i class="fas fa-exclamation-circle mr-1"></i>Seller N/A
                                                        </span>
                                                    @endif
                                                @endforeach
                                            </div>
                                        </td>

                                        {{-- Regional Currency Formatted Blocks --}}
                                        <td class="text-right font-weight-bold text-dark" style="font-size: 0.95rem;">
                                            ₦{{ number_format($order->grand_total, 2, '.', ',') }}
                                        </td>

                                        {{-- Dynamic Dynamic Status Badge Toggles --}}
                                        <td class="text-center">
                                            @php
                                                $orderStatus = $order->order_status;
                                                $statusClass = [
                                                    'Delivered' => 'badge-success',
                                                    'New'       => 'badge-info',
                                                    'Cancelled' => 'badge-danger',
                                                ][$orderStatus] ?? 'badge-warning text-dark';
                                            @endphp
                                            <span class="badge badge-pill {{ $statusClass }} px-3 py-2" style="font-size: 0.75rem; letter-spacing: 0.3px;">
                                                {{ $orderStatus }}
                                            </span>
                                        </td>

                                        {{-- Payment Processing Metadata Columns --}}
                                        <td class="text-center">
                                            @php
                                                $paymentStatus = $order->payment_status;
                                                $paymentClass = ($paymentStatus == 'Paid') ? 'badge-success' : 'badge-secondary';
                                            @endphp
                                            <span class="badge badge-pill {{ $paymentClass }} px-2 py-1" style="font-size: 0.7rem;">
                                                {{ $order->payment_gateway }} ({{ $paymentStatus }})
                                            </span>
                                        </td>

                                        {{-- Action Navigation Elements --}}
                                        <td class="text-center">
                                            <div class="btn-group" role="group">
                                                <a title="View Full Details" class="btn btn-sm btn-outline-primary p-2 border-0 shadow-sm mr-1" style="border-radius: 4px;" href="{{ route('admin.orders.details', $order->id) }}">
                                                    <i class="fa fa-search"></i>
                                                </a>

                                                <a title="Print Generated PDF Invoice" class="btn btn-sm btn-outline-secondary p-2 border-0 shadow-sm" style="border-radius: 4px;" href="{{ route('admin.orders.invoice', $order->id) }}">
                                                    <i class="fa fa-print"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="9" class="text-center text-muted py-5">
                                            <i class="fas fa-box-open d-block mb-3" style="font-size: 2rem; opacity: 0.4;"></i>
                                            No processing customer transaction orders found in ledger logs matching profile constraints.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

    {{-- SYSTEM BUTTERUP TOAST FLASH LISTENERS --}}
      @include("pages.messages")

</div>
