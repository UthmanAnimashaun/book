<?php

use Livewire\Volt\Component;
use App\Models\Website;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Livewire\WithFileUploads;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Website Settings')]
class extends Component {
    use WithFileUploads;

    // Track active tab completely within Livewire state
    public string $activeTab = 'general';

    // Form Properties
    public $websiteId;
    public $name, $email, $phone_number, $location, $location2;
    public $information, $tc, $website_description, $vendor_tc, $delivery_info;
    public $facebook, $twitter, $whatsapp, $logo, $existingLogo;

    public function mount()
    {
        Session::put('page', 'website');

        $website = Website::first();

        if ($website) {
            $this->setProperties($website);
        }
    }

    protected function setProperties($website)
    {
        $this->websiteId = $website->id;
        $this->name = $website->name;
        $this->email = $website->email;
        $this->phone_number = $website->phone_number;
        $this->location = $website->location;
        $this->location2 = $website->location2;
        $this->information = $website->information;
        $this->tc = $website->tc;
        $this->website_description = $website->website_description;
        $this->vendor_tc = $website->vendor_tc;
        $this->delivery_info = $website->delivery_info;
        $this->facebook = $website->facebook;
        $this->twitter = $website->twitter;
        $this->whatsapp = $website->whatsapp;
        $this->existingLogo = $website->logo;
    }

    /**
     * Change active tab without relying on Bootstrap JS
     */
    public function switchTab(string $tabName)
    {
        $this->activeTab = $tabName;
    }

    public function saveWebsite()
    {
      try {
        $this->validate([
            'name' => 'required',
            'email' => 'required|email',
            'phone_number' => 'required|max:20',
            'location' => 'required|max:255',
            'information' => 'required',
            'tc' => 'required',
            'website_description' => 'required|max:500',
            'vendor_tc' => 'required',
            'delivery_info' => 'required',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);
    } catch (\Illuminate\Validation\ValidationException $e) {
        // Option A: Dump and die to inspect the exact failing fields on your screen
        //dd($e->errors());

        // Option B: Or send them safely straight to your butterup toast if you prefer
         foreach($e->errors() as $field => $messages) {
             $this->dispatch('toast', message: $messages[0], type: 'error');
         }
         throw $e;

    }

        $logoFilename = $this->existingLogo;

        if ($this->logo) {
            if ($this->existingLogo && Storage::disk('public')->exists('images/logo/' . $this->existingLogo)) {
                Storage::disk('public')->delete('images/logo/' . $this->existingLogo);
            }

            $logoFilename = time() . '_' . $this->logo->getClientOriginalName();
            $this->logo->storeAs('images/logo', $logoFilename, 'public');
        }

        $website = Website::updateOrCreate(
            ['id' => $this->websiteId],
            [
                'name' => $this->name,
                'email' => $this->email,
                'phone_number' => $this->phone_number,
                'location' => $this->location,
                'location2' => $this->location2,
                'information' => $this->information,
                'tc' => $this->tc,
                'delivery_info' => $this->delivery_info,
                'vendor_tc' => $this->vendor_tc,
                'website_description' => $this->website_description,
                'facebook' => $this->facebook,
                'twitter' => $this->twitter,
                'whatsapp' => $this->whatsapp,
                'logo' => $logoFilename,
            ]
        );

        $this->setProperties($website);
        $this->logo = null;

        $this->dispatch('toast', message: 'Website details updated successfully.', type: 'success');
    }
};
?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12 grid-margin">
            <h3 class="font-weight-bold mb-4">⚙️ Website Settings & Configuration</h3>
            <div class="d-flex align-items-center">
                <i class="mdi mdi-cog-outline text-muted mr-2"></i>
                <p class="mb-0">Manage your website's core information, branding, and policies all in one place.</p>
                {{ asset('storage/images/logo.jpg') }}
                {{ asset('storage/images/logo/' . $existingLogo) }}
                 <img src="{{  asset('storage/images/logo/' . $existingLogo) }}" class="img-thumbnail" style="height:100px; width:100px; object-fit: contain;">
            </div>
        </div>
    </div>

    <div class="card shadow-lg border-0">
        <div class="card-body p-4">
            {{-- TAB NAVIGATION (Controlled by Livewire state) --}}
            <ul class="nav nav-tabs" id="websiteSettingsTab" role="tablist">
                <li class="nav-item">
                    <button type="button" class="nav-link {{ $activeTab === 'general' ? 'active' : '' }}" wire:click="switchTab('general')">
                        <i class="fa fa-info-circle mr-1"></i> General
                    </button>
                </li>
                <li class="nav-item">
                    <button type="button" class="nav-link {{ $activeTab === 'branding' ? 'active' : '' }}" wire:click="switchTab('branding')">
                        <i class="fa fa-paint-brush mr-1"></i> Branding & Social
                    </button>
                </li>
                <li class="nav-item">
                    <button type="button" class="nav-link {{ $activeTab === 'terms' ? 'active' : '' }}" wire:click="switchTab('terms')">
                        <i class="fa fa-file-contract mr-1"></i> T&Cs (Customer)
                    </button>
                </li>
                <li class="nav-item">
                    <button type="button" class="nav-link {{ $activeTab === 'vendor' ? 'active' : '' }}" wire:click="switchTab('vendor')">
                        <i class="fa fa-truck mr-1"></i> Vendor & Delivery
                    </button>
                </li>
            </ul>

            <form wire:submit="saveWebsite" class="forms-sample pt-4">
                <div class="tab-content" id="websiteSettingsTabContent">

                    {{-- TAB 1: GENERAL --}}
                    <div class="tab-pane fade {{ $activeTab === 'general' ? 'show active' : '' }}" id="general" role="tabpanel">
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label>Website Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" wire:model="name">
                                @error('name') <span class="text-danger small">{{ $message }}</span> @enderror
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Tagline/Description <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" wire:model="website_description">
                                @error('website_description') <span class="text-danger small">{{ $message }}</span> @enderror
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Website Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" wire:model="email">
                                @error('email') <span class="text-danger small">{{ $message }}</span> @enderror
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Contact Number <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" wire:model="phone_number">
                                @error('phone_number') <span class="text-danger small">{{ $message }}</span> @enderror
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Primary Address <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" wire:model="location">
                                @error('location') <span class="text-danger small">{{ $message }}</span> @enderror
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Secondary Address <span class="text-success">(Optional)</span></label>
                                <input type="text" class="form-control" wire:model="location2">
                            </div>
                            <div class="col-12 form-group">
                                <label>About Us/Company Information <span class="text-danger">*</span></label>
                                <textarea class="form-control" wire:model="information" rows="5"></textarea>
                                @error('information') <span class="text-danger small">{{ $message }}</span> @enderror
                            </div>
                        </div>
                    </div>

                    {{-- TAB 2: BRANDING & SOCIAL --}}
                    <div class="tab-pane fade {{ $activeTab === 'branding' ? 'show active' : '' }}" id="branding" role="tabpanel">
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label>Facebook Link</label>
                                <input type="text" class="form-control" wire:model="facebook">
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Twitter Link</label>
                                <input type="text" class="form-control" wire:model="twitter">
                            </div>
                            <div class="col-md-6 form-group">
                                <label>WhatsApp Contact Link</label>
                                <input type="text" class="form-control" wire:model="whatsapp">
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Website Logo</label>
                                <input type="file" class="form-control mb-2" wire:model="logo">
                                <div class="mt-2">
                                    <small class="text-muted d-block mb-1">Preview:</small>
                                    @if ($logo)
                                        <img src="{{ $logo->temporaryUrl() }}" class="img-thumbnail" style="height:100px; width:100px; object-fit: contain;">
                                    @elseif ($existingLogo)
                                        <img src="{{ asset('storage/images/logo/' . $existingLogo) }}" class="img-thumbnail" style="height:100px; width:100px; object-fit: contain;">
                                    @else
                                        <img src="{{ asset('storage/images/logo.jpg') }}" class="img-thumbnail" style="height:100px;">
                                    @endif
                                </div>
                                @error('logo') <span class="text-danger small">{{ $message }}</span> @enderror
                            </div>
                        </div>
                    </div>

                    {{-- TAB 3: CUSTOMER TERMS --}}
                    <div class="tab-pane fade {{ $activeTab === 'terms' ? 'show active' : '' }}" id="terms" role="tabpanel">
                        <div class="form-group">
                            <label>Customer Terms and Conditions <span class="text-danger">*</span></label>
                            <textarea class="form-control" wire:model="tc" rows="15"></textarea>
                            @error('tc') <span class="text-danger small">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    {{-- TAB 4: VENDOR & DELIVERY --}}
<div class="tab-pane fade {{ $activeTab === 'vendor' ? 'show active' : '' }}" id="vendor" role="tabpanel">

    <div class="form-group">
        <label>Vendor Terms and Conditions <span class="text-danger">*</span></label>
        <textarea class="form-control" wire:model="vendor_tc" rows="10"></textarea>
        @error('vendor_tc') <span class="text-danger small">{{ $message }}</span> @enderror
    </div>

    <div class="form-group">
        <label>Delivery Information & Policy <span class="text-danger">*</span></label>

        <textarea class="form-control" wire:model="delivery_info" rows="10"></textarea>

        @error('delivery_info') <span class="text-danger small d-block mt-1">{{ $message }}</span> @enderror
    </div>

</div>

                <div class="d-flex justify-content-end pt-4 border-top">
                    <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                        <i class="fa fa-save mr-1"></i>
                        <span wire:loading.remove>Update Website Settings</span>
                        <span wire:loading>Processing...</span>
                    </button>
                </div>
            </form>
        </div>
    </div>


                   @include("pages.messages")
</div>
