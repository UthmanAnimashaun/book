<?php

use Livewire\Volt\Component;


use App\Models\Faq;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Manage FAQs')]
class extends Component {

    // UI State
    public bool $isModalOpen = false;
    public string $modalTitle = "Add New FAQ";

    // Form Fields
    public $faqId;
    public $question;
    public $answer;

    public function with(): array
    {
        Session::put('page', 'faqs');

        return [
            'faqs' => Faq::orderBy('id', 'desc')->get()
        ];
    }

    // Toggle Status
    public function updateFaqStatus($id, $currentStatus)
    {
        $newStatus = $currentStatus == 1 ? 0 : 1;
        Faq::where('id', $id)->update(['status' => $newStatus]);
       // session()->flash('admin_success_message', 'Status updated successfully.');
           $this->dispatch('toast', message: 'Status updated successfully..', type: 'success');
          return; // Exit early to prevent unnecessary re-rendering
    }

    // Open Modal for Create
    public function openAddModal()
    {
        $this->reset(['faqId', 'question', 'answer']);
        $this->modalTitle = "Add New FAQ";
        $this->isModalOpen = true;
    }

    // Open Modal for Edit
    public function editFaq($id)
    {
        $faq = Faq::findOrFail($id);
        $this->faqId = $id;
        $this->question = $faq->question;
        $this->answer = $faq->answer;

        $this->modalTitle = "Edit FAQ";
        $this->isModalOpen = true;
    }

    // Save Data (Add or Update)
    public function saveFaq()
    {
        $this->validate([
            'question' => 'required|string|max:255',
            'answer' => 'required|string',
        ]);

        Faq::updateOrCreate(
            ['id' => $this->faqId],
            [
                'question' => $this->question,
                'answer' => $this->answer,
                'status' => 1
            ]
        );

        //session()->flash('admin_success_message', $this->faqId ? 'FAQ updated!' : 'FAQ added!');
        $this->isModalOpen = false;
        $message = $this->faqId ? 'FAQ updated!' : 'FAQ added!';
           $this->dispatch('toast', message: $message, type: 'success');
          return; // Exit early to prevent unnecessary re-rendering
    }

    public function deleteFaq($id)
    {
        Faq::destroy($id);
           $this->dispatch('toast', message: 'FAQ deleted.', type: 'success');
          return; // Exit early to prevent unnecessary re-rendering
    }
};

 ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4 class="card-title text-primary font-weight-bold">
                            <i class="fas fa-question-circle mr-2"></i> Catalogue Management: FAQs
                        </h4>
                        <button wire:click="openAddModal" class="btn btn-primary">
                            <i class="fa fa-plus"></i> Add New FAQ
                        </button>
                    </div>

                     @include("pages.messages")

                    <div class="table-responsive pt-3">
                        <table id="sections" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-light">
                                    <th>#</th>
                                    <th>Questions</th>
                                    <th>Answers</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($faqs as $index => $faq)
                                <tr wire:key="{{ $faq->id }}">
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ Str::limit($faq->question, 40) }}</td>
                                    <td>{{ Str::limit(strip_tags($faq->answer), 40) }}</td>
                                    <td>
                                        <button wire:click="updateFaqStatus({{ $faq->id }}, {{ $faq->status }})" class="btn p-0 border-0">
                                            @if($faq->status == 1)
                                                <span class="badge badge-success">Active</span>
                                            @else
                                                <span class="badge badge-secondary">Inactive</span>
                                            @endif
                                        </button>
                                    </td>
                                    <td>
                                        <button wire:click="editFaq({{ $faq->id }})" class="btn btn-sm btn-outline-warning p-2">
                                            <i class="fa fa-edit"></i>
                                        </button>

                                        <button wire:confirm="Are you sure you want to delete this FAQ?" wire:click="deleteFaq({{ $faq->id }})" class="btn btn-sm btn-outline-danger p-2 ml-1">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="5" class="text-center text-muted">No FAQs found.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @if($isModalOpen)
    <div class="modal fade show d-block" style="background: rgba(0,0,0,0.5); overflow-y: auto;" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">{{ $modalTitle }}</h5>
                    <button type="button" class="close text-white" wire:click="$set('isModalOpen', false)">&times;</button>
                </div>
                <form wire:submit.prevent="saveFaq">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="question">Question <span class="text-danger">*</span></label>
                            <input type="text" wire:model.blur="question" id="question" class="form-control @error('question') is-invalid @enderror" placeholder="Enter FAQ question">
                            @error('question') <span class="invalid-feedback">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group mt-3">
                            <label for="answer">Answer <span class="text-danger">*</span></label>
                            <textarea wire:model.blur="answer" id="answer" class="form-control @error('answer') is-invalid @enderror" rows="10" placeholder="Enter Answer"></textarea>
                            @error('answer') <span class="invalid-feedback">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" wire:click="$set('isModalOpen', false)">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fa fa-save mr-1"></i> Save FAQ
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @endif
</div>
