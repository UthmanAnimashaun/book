<?php

use Livewire\Volt\Component;


use App\Models\Website;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Terms, Conditions & About Us')]
class extends Component {
    public string $title = "Terms and Conditions";

    /**
     * Compute and provide configuration records to the view layout
     */
    public function with(): array
    {
        // Maintain dashboard sidebar navigation state mapping
        Session::put('page', 'TC');

        return [
            'website' => Website::first()
        ];
    }
}; ?>

<div class="main-panel">
    <div class="content-wrapper">

        {{-- SECTION 1: VENDOR TERMS & CONDITIONS --}}
        <div class="card mb-5 shadow-sm border-0">
            <div class="card-body">
                <h4 class="card-title text-primary font-weight-bold mb-3">
                    <i class="fas fa-truck-moving mr-2"></i> Vendor's {{ $title }}
                </h4>
                <hr class="mb-4">

                <div class="table-responsive pt-2 text-dark" style="line-height: 1.8;">
                    @if($website && $website->vendor_tc)
                        {!! $website->vendor_tc !!}
                    @else
                        <p class="text-muted italic py-3">
                            <i class="fas fa-info-circle mr-1"></i> No vendor terms and conditions have been configured yet.
                        </p>
                    @endif
                </div>
            </div>
        </div>

        {{-- SECTION 2: CUSTOMER TERMS & CONDITIONS --}}
        <div class="card mb-5 shadow-sm border-0">
            <div class="card-body">
                <h4 class="card-title text-primary font-weight-bold mb-3">
                    <i class="fas fa-user-shield mr-2"></i> User's Terms and Conditions
                </h4>
                <hr class="mb-4">

                <div class="table-responsive pt-2 text-dark" style="line-height: 1.8;">
                    @if($website && $website->tc)
                        {!! $website->tc !!}
                    @else
                        <p class="text-muted italic py-3">
                            <i class="fas fa-info-circle mr-1"></i> No customer terms and conditions have been configured yet.
                        </p>
                    @endif
                </div>
            </div>
        </div>

        {{-- SECTION 3: ABOUT US / COMPANY INFORMATION --}}
        <div class="card mb-3 shadow-sm border-0">
            <div class="card-body">
                <h4 class="card-title text-primary font-weight-bold mb-3">
                    <i class="fas fa-store-alt mr-2"></i> About Us & Company Information
                </h4>
                <hr class="mb-4">

                <div class="table-responsive pt-2 text-dark" style="line-height: 1.8;">
                    @if($website && $website->information)
                        {!! $website->information !!}
                    @else
                        <p class="text-muted italic py-3">
                            <i class="fas fa-info-circle mr-1"></i> No company information profile has been written yet.
                        </p>
                    @endif
                </div>
            </div>
        </div>

    </div>
</div>
