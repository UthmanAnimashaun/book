<?php

use Livewire\Volt\Component;

use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use App\Models\Admin;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('My Profile')]
class extends Component {


    use WithFileUploads;

    public $admin_name;
    public $admin_mobile;
    public $state;
    public $lga;
    public $admin_photos;
    public $current_image;
    public $email;

    public function mount()
    {
        $admin = Auth::guard('admin')->user();
        $this->admin_name = $admin->name;
        $this->admin_mobile = $admin->mobile;
        $this->state = $admin->state;
        $this->lga = $admin->lga;
        $this->current_image = $admin->image;
        $this->email = $admin->email;
    }

    public function updateDetails()
    {
        $this->validate([
            'admin_name' => 'required|string|max:255',
            'state' => 'required|string|max:255',
            'lga' => 'required|string|max:255',
            'admin_mobile' => 'required|numeric|digits:11',
            'admin_photos' => 'nullable|image|max:2048',
        ]);

        $admin = Admin::find(Auth::guard('admin')->user()->id);
        $filename = $this->current_image;

        if ($this->admin_photos) {
            // Delete old image
            if (!empty($admin->image)) {
                Storage::disk('public')->delete('images/admin_photos/' . $admin->image);
            }

            // Process new image
            $filename = time() . '_' . $this->admin_photos->getClientOriginalName();
            $path = 'images/admin_photos/' . $filename;

            $this->admin_photos->storeAs('images/admin_photos', $filename, 'public');

            // Resize using Intervention Image
            $manager = new ImageManager(new Driver());
            $img = $manager->read(storage_path('app/public/' . $path));
            $img->cover(200, 200)->save();
        }

        $admin->update([
            'name' => $this->admin_name,
            'mobile' => $this->admin_mobile,
            'state' => $this->state,
            'lga' => $this->lga,
            'image' => $filename,
        ]);

        $this->dispatch('toast', message: 'Admin details updated successfully!', type: 'success');
        return; // Exit early to prevent unnecessary re-rendering
    }

    public function deletePhoto()
    {
        $admin = Auth::guard('admin')->user();
        if (!empty($admin->image)) {
            Storage::disk('public')->delete('images/admin_photos/' . $admin->image);
            $admin->update(['image' => '']);
            $this->current_image = '';

            $this->dispatch('toast', message: 'Photo deleted successfully!', type: 'success');
            return; // Exit early to prevent unnecessary re-rendering
        }
    }
}; ?>

<div class="card shadow-sm border-0">
    <div class="card-body">
    @include("pages.messages")
        <h4 class="card-title text-primary mb-4 font-weight-bold">Personal Details</h4>
        <form wire:submit="updateDetails">
            <div class="row">
                <div class="col-md-10">
                    <div class="form-group">
                        <label>Admin Email</label>
                       <input type="email" class="form-control" wire:model="email" readonly>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="form-group">
                        <label>Full Name <span class="text-danger">*</span></label>
                       <input type="text" class="form-control" wire:model="admin_name">
                       @error('admin_name') <span class="text-danger small">{{ $message }}</span> @enderror
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Mobile <span class="text-danger">*</span></label>
                       <input type="text" class="form-control" wire:model="admin_mobile">
                        @error('admin_mobile') <span class="text-danger small">{{ $message }}</span> @enderror
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>State <span class="text-danger">*</span></label>
                       <input type="text" class="form-control" wire:model="state">
                        @error('state') <span class="text-danger small">{{ $message }}</span> @enderror
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Local Government <span class="text-danger">*</span></label>
                       <input type="text" class="form-control" wire:model="lga">
                        @error('lga') <span class="text-danger small">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>

            <h6 class="mb-3 text-secondary border-bottom pb-2 mt-4">Profile Picture</h6>
            <div class="form-group">
               <input type="file" class="form-control mb-3" wire:model="admin_photos">

                <div class="d-flex align-items-end mt-3">
                    <img class="img-thumbnail rounded-circle"
                         src="{{ $admin_photos ? $admin_photos->temporaryUrl() : ($current_image ? asset('storage/images/admin_photos/'.$current_image) : asset('images/default.jpg')) }}"
                         style="height:100px; width:100px; object-fit: cover;">

                    @if ($current_image)
                        <button type="button" class="btn btn-sm btn-outline-danger ml-3" wire:click="deletePhoto" wire:confirm="Are you sure?">
                            <i class="fa fa-trash"></i> Delete
                        </button>
                    @endif
                </div>
            </div>

            <div class="d-flex justify-content-end pt-3">
                <button type="submit" class="btn btn-primary">Save Details</button>
            </div>
        </form>
    </div>
</div>
