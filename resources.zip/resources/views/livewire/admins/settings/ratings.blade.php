<?php

use Livewire\Volt\Component;
use App\Models\Rating;
use App\Models\Product;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Ratings & Reviews Ledger')]
class extends Component {

    // UI Toggle States
    public bool $isModalOpen = false;
    public string $modalTitle = "Add Rating";

    // Form Binding Parameters
    public $ratingId;
    public $product_id;
    public $rating_value;
    public $review;

    /**
     * Set active tracking state on init
     */
    public function mount(): void
    {
        Session::put('page', 'rating');
    }

    /**
     * Compute data arrays dynamically based on authorized role levels
     */
    public function with(): array
    {
        $admin = Auth::guard('admin')->user();
        $ratingsQuery = Rating::with(['user', 'product'])->orderBy('id', 'desc');
        $productsQuery = Product::select('id', 'title');

        // ROLE CONSTRAINTS PIPELINE: Filter display data exclusively by vendor association or allow complete global access
        if ($admin && (int)$admin->is_admin === 2) {
            $ratingsQuery->whereHas('product', function ($query) use ($admin) {
                $query->where('admin_id', $admin->id);
            });

            $productsQuery->where('admin_id', $admin->id);
        }

        return [
            'ratings' => $ratingsQuery->get(),
            'products' => $productsQuery->get(),
            'isAdmin' => $admin && (int)$admin->is_admin === 1 // Added helper variable for view cleanup
        ];
    }

    /**
     * Toggle item listing active flag states
     */
    public function toggleStatus($id, $currentStatus)
    {
        // Backend Guard: Reject non-admins
        if ((int)Auth::guard('admin')->user()->is_admin !== 1) {
            $this->dispatch('toast', message: 'Unauthorized action.', type: 'error');
            return;
        }

        $newStatus = (int)$currentStatus === 1 ? 0 : 1;
        Rating::where('id', $id)->update(['status' => $newStatus]);

        $this->dispatch('toast', message: 'Visibility status modified.', type: 'success');
    }

    /**
     * Initialize create form fields inside modal block view
     */
    public function openAddModal()
    {
        if ((int)Auth::guard('admin')->user()->is_admin !== 1) return;

        $this->reset(['ratingId', 'product_id', 'rating_value', 'review']);
        $this->modalTitle = "Log New Asset Review Entry";
        $this->isModalOpen = true;
    }

    /**
     * Populate update form fields inside modal block view
     */
    public function editRating($id)
    {
        if ((int)Auth::guard('admin')->user()->is_admin !== 1) return;

        $rating = Rating::findOrFail($id);
        $this->ratingId = $id;
        $this->product_id = $rating->product_id;
        $this->rating_value = $rating->rating;
        $this->review = $rating->review;

        $this->modalTitle = "Modify Customer Feedback Parameters";
        $this->isModalOpen = true;
    }

    /**
     * Save form inputs (Add or Update)
     */
    public function saveRating()
    {
        if ((int)Auth::guard('admin')->user()->is_admin !== 1) {
            $this->dispatch('toast', message: 'Unauthorized action.', type: 'error');
            return;
        }

        $this->validate([
            'product_id'   => 'required|exists:products,id',
            'rating_value' => 'required|numeric|min:1|max:5',
            'review'       => 'required|string|min:5',
        ]);

        Rating::updateOrCreate(
            ['id' => $this->ratingId],
            [
                'product_id' => $this->product_id,
                'rating'     => $this->rating_value,
                'review'     => $this->review,
                'user_id'    => auth()->id() ?? 1,
                'status'     => 1
            ]
        );

        $this->isModalOpen = false;
        $this->dispatch('toast', message: $this->ratingId ? 'Feedback parameters updated.' : 'New review entry logged.', type: 'success');
    }

    /**
     * Purge single rating reference entry out of database storage
     */
    public function deleteRating($id)
    {
        if ((int)Auth::guard('admin')->user()->is_admin !== 1) {
            $this->dispatch('toast', message: 'Unauthorized action.', type: 'error');
            return;
        }

        Rating::destroy($id);
        $this->dispatch('toast', message: 'Review record fully purged.', type: 'success');
    }
}; ?>

<div class="content-wrapper text-dark">
    {{-- PAGE MASTER ACTIONS CAPTION BAR --}}
    <div class="d-flex justify-content-between align-items-center mb-4 px-1">
        <div>
            <h3 class="font-weight-bold text-dark mb-1">⭐ Ratings & Reviews Control</h3>
            <p class="text-muted small mb-0">Audit, modify, and track end-user product reviews, scores, and marketplace feedback records.</p>
        </div>
        {{-- Guarded Add Action Button --}}
        @if($isAdmin)
            <button wire:click="openAddModal" class="btn btn-primary shadow-sm px-3 font-weight-bold" style="border-radius: 6px;">
                <i class="fa fa-plus mr-1"></i> Add Custom Review
            </button>
        @endif
    </div>

    {{-- LEDGER DATA INDEX ROWS --}}
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card shadow-sm border-0" style="border-radius: 10px;">
                <div class="card-body p-4">

                    <div class="table-responsive pt-2">
                        <table class="table table-striped table-hover align-middle mb-0">
                            <thead class="bg-light text-secondary">
                                <tr>
                                    <th style="width: 5%;">#</th>
                                    <th style="width: 25%;">Product Catalog Item</th>
                                    <th style="width: 20%;">User Profile Identity</th>
                                    <th style="width: 25%;">Feedback/Review Text</th>
                                    <th style="width: 12%;" class="text-center">Score Metric</th>
                                    <th style="width: 8%;" class="text-center">State</th>
                                    {{-- Guarded Actions Column Header --}}
                                    @if($isAdmin)
                                        <th style="width: 10%;" class="text-center">Actions</th>
                                    @endif
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($ratings as $index => $rating)
                                    <tr wire:key="rating-item-row-{{ $rating->id }}">
                                        <td><span class="text-monospace font-weight-bold text-secondary">{{ $index + 1 }}</span></td>
                                        <td>
                                            @if($rating->product)
                                                <a href="{{ asset('product/'.$rating->product->id) }}" target="_blank" class="font-weight-bold text-primary text-decoration-none">
                                                    {{ $rating->product->title }}
                                                </a>
                                            @else
                                                <span class="text-danger font-italic small">Product Registry Missing</span>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="font-weight-medium text-dark">{{ $rating->user->name ?? 'Guest Buyer' }}</div>
                                            <small class="text-muted d-block mt-0.5"><i class="far fa-envelope mr-1" style="font-size:0.75rem;"></i>{{ $rating->user->email ?? 'N/A' }}</small>
                                        </td>
                                        <td>
                                            <span class="text-dark small d-block" title="{{ $rating->review }}" style="line-height:1.4; max-width: 280px; white-space: normal;">
                                                {{ Str::limit($rating->review, 85) }}
                                            </span>
                                        </td>
                                        <td class="text-center text-nowrap">
                                            @for($i = 1; $i <= 5; $i++)
                                                <i class="fa fa-star {{ $i <= $rating->rating ? 'text-warning' : 'text-muted' }}" style="font-size: 0.82rem; margin: 0 1px;"></i>
                                            @endfor
                                        </td>
                                        <td class="text-center">
                                            {{-- Conditioned Click Engine vs Static Badge Display --}}
                                            @if($isAdmin)
                                                <button type="button" wire:click="toggleStatus({{ $rating->id }}, {{ $rating->status }})" class="btn p-0 border-0 outline-none" title="Toggle Visibility Status">
                                                    @if((int)$rating->status === 1)
                                                        <span class="badge badge-pill badge-success px-3 py-1.5" style="font-size:0.7rem; letter-spacing:0.3px;">Active</span>
                                                    @else
                                                        <span class="badge badge-pill badge-secondary px-3 py-1.5" style="font-size:0.7rem; letter-spacing:0.3px;">Hidden</span>
                                                    @endif
                                                </button>
                                            @else
                                                @if((int)$rating->status === 1)
                                                    <span class="badge badge-pill badge-success px-3 py-1.5" style="font-size:0.7rem; letter-spacing:0.3px; cursor: default;">Active</span>
                                                @else
                                                    <span class="badge badge-pill badge-secondary px-3 py-1.5" style="font-size:0.7rem; letter-spacing:0.3px; cursor: default;">Hidden</span>
                                                @endif
                                            @endif
                                        </td>
                                        {{-- Guarded Actions Buttons Column --}}
                                        @if($isAdmin)
                                            <td class="text-center">
                                                <div class="btn-group" role="group">
                                                    <button type="button" wire:click="editRating({{ $rating->id }})" class="btn btn-sm btn-outline-info p-2 border-0 shadow-sm mr-1" style="border-radius:4px;" title="Edit Review Parameters">
                                                        <i class="fa fa-edit"></i>
                                                    </button>
                                                    <button type="button" wire:confirm="Are you certain you want to completely clear out this validation feedback?" wire:click="deleteRating({{ $rating->id }})" class="btn btn-sm btn-outline-danger p-2 border-0 shadow-sm" style="border-radius:4px;" title="Purge Record">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        @endif
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="{{ $isAdmin ? '7' : '6' }}" class="text-center text-muted py-5 font-italic">
                                            <i class="fas fa-star-half-alt d-block mb-2" style="font-size: 2.2rem; opacity: 0.3;"></i>
                                            No processing ledger review items logged matching profile constraints.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

    {{-- INTERACTIVE MODAL PANEL (Will stay unreachable since opening triggers are closed) --}}
    @if($isModalOpen && $isAdmin)
        <div class="modal fade show d-block elements-fade-in" style="background: rgba(15, 23, 42, 0.45); backdrop-filter: blur(4px); overflow-y: auto;" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow-lg" style="border-radius: 12px; overflow: hidden;">

                    <div class="modal-header bg-primary text-white border-0 py-3 px-4">
                        <h5 class="modal-title font-weight-bold mb-0" style="letter-spacing: 0.3px;">{{ $modalTitle }}</h5>
                        <button type="button" class="close text-white outline-none" wire:click="$set('isModalOpen', false)" style="opacity: 0.85;">&times;</button>
                    </div>

                    <form wire:submit.prevent="saveRating">
                        <div class="modal-body p-4 bg-white text-dark">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold text-secondary small mb-1">Target Marketplace Book Asset</label>
                                <select wire:model="product_id" class="form-control font-weight-medium @error('product_id') is-invalid @enderror" style="height: 42px; border-radius: 6px;">
                                    <option value="">-- Choose target catalog item --</option>
                                    @foreach($products as $prod)
                                        <option value="{{ $prod->id }}">{{ $prod->title }}</option>
                                    @endforeach
                                </select>
                                @error('product_id') <div class="invalid-feedback font-weight-bold mt-1" style="font-size:0.75rem;">{{ $message }}</div> @enderror
                            </div>

                            <div class="form-group mb-3">
                                <label class="font-weight-bold text-secondary small mb-1">Assigned Score Weight (1-5 Stars)</label>
                                <select wire:model="rating_value" class="form-control font-weight-medium @error('rating_value') is-invalid @enderror" style="height: 42px; border-radius: 6px;">
                                    <option value="">-- Select scale weight assignment --</option>
                                    <option value="1">⭐ 1 Star - Unsatisfactory</option>
                                    <option value="2">⭐⭐ 2 Stars - Mediocre</option>
                                    <option value="3">⭐⭐⭐ 3 Stars - Average</option>
                                    <option value="4">⭐⭐⭐⭐ 4 Stars - Commendable</option>
                                    <option value="5">⭐⭐⭐⭐⭐ 5 Stars - Exceptional</option>
                                </select>
                                @error('rating_value') <div class="invalid-feedback font-weight-bold mt-1" style="font-size:0.75rem;">{{ $message }}</div> @enderror
                            </div>

                            <div class="form-group mb-1">
                                <label class="font-weight-bold text-secondary small mb-1">Review Comment Narrative</label>
                                <textarea wire:model="review" class="form-control p-3 @error('review') is-invalid @enderror" rows="4" placeholder="Type verified user purchase statement logs or textual summaries here..." style="border-radius: 6px; line-height: 1.5; resize: none;"></textarea>
                                @error('review') <div class="invalid-feedback font-weight-bold mt-1" style="font-size:0.75rem;">{{ $message }}</div> @enderror
                            </div>
                        </div>

                        <div class="modal-footer bg-light border-top-0 py-3 px-4">
                            <button type="button" class="btn btn-light px-3 font-weight-medium" wire:click="$set('isModalOpen', false)" style="border-radius: 6px;">Cancel</button>
                            <button type="submit" class="btn btn-primary px-4 font-weight-bold" wire:loading.attr="disabled" style="border-radius: 6px; box-shadow: 0 4px 10px rgba(75,73,172,0.15);">
                                <span wire:loading.remove>Commit Modifications</span>
                                <span wire:loading>Syncing Records...</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endif

    @include("pages.messages")
</div>
