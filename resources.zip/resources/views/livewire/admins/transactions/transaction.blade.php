<?php

use Livewire\Volt\Component;
use App\Models\Payment;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use App\Models\OrdersProduct;
use App\Models\OrderStatuse;

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Payment Transactions Log')]
class extends Component {
    // Component page title state
    public string $title = "Payment Transactions Log";

    /**
     * Compute and load historical transaction lists reactively based on admin roles
     */
    public function with(): array
    {
        // Track the current page location in the dashboard sidebar
        Session::put('page', 'Transaction');

        $admin = Auth::guard('admin')->user();
        $query = Payment::orderBy('created_at', 'desc');

        // VENDOR POLICY PIPELINE: Scope records strictly to books belonging to their catalog
        if ($admin && (int)$admin->is_admin === 2) {
            // Assumes your Payment model has an associated order relation linking back to order products
            $query->whereHas('order.orders_products', function ($subQuery) use ($admin) {
                $subQuery->where('admin_id', $admin->id);
            });
        }

        return [
            'transactions' => $query->get()
        ];
    }
}; ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card shadow-sm border-0" style="border-radius: 10px;">
                <div class="card-body p-4">

                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4 class="card-title text-primary font-weight-bold mb-0">
                            <i class="fas fa-money-check-alt mr-2"></i> {{ $title }}
                        </h4>
                    </div>

                    <div class="table-responsive pt-2">
                        <table id="trans" class="table table-hover table-striped align-middle mb-0">
                            <thead class="bg-light text-secondary">
                                <tr>
                                    <th style="width: 5%;">#</th>
                                    <th>Payer Information</th>
                                    <th class="text-right" style="width: 20%;">Amount</th>
                                    <th class="text-center" style="width: 15%;">Status</th>
                                    <th style="width: 35%;">Transaction Audit IDs</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($transactions as $index => $transaction)
                                    <tr wire:key="transaction-row-{{ $transaction->id }}">
                                        <td class="text-secondary font-weight-medium">
                                            {{ $index + 1 }}
                                        </td>

                                        <td>
                                            <div class="d-flex flex-column">
                                                <span class="font-weight-bold text-dark mb-1" style="font-size: 0.92rem;">
                                                    {{ $transaction->email }}
                                                </span>
                                                <small class="text-muted d-flex align-items-center">
                                                    <i class="far fa-clock mr-1" style="font-size: 0.75rem;"></i>
                                                    {{ $transaction->created_at ? $transaction->created_at->format('M d, Y • h:i A') : 'N/A' }}
                                                </small>
                                            </div>
                                        </td>

                                        <td class="text-right font-weight-bold text-dark" style="font-size: 1rem;">
                                            ₦{{ number_format($transaction->amount, 2, '.', ',') }}
                                        </td>

                                        <td class="text-center">
                                            @if ($transaction->status == 'success')
                                                <span class="badge badge-pill badge-success px-3 py-2" style="font-size: 0.72rem; letter-spacing: 0.3px;">Successful</span>
                                            @elseif ($transaction->status == 'failed')
                                                <span class="badge badge-pill badge-danger px-3 py-2" style="font-size: 0.72rem; letter-spacing: 0.3px;">Failed</span>
                                            @else
                                                <span class="badge badge-pill badge-warning text-dark px-3 py-2" style="font-size: 0.72rem; letter-spacing: 0.3px;">
                                                    {{ ucfirst($transaction->status) }}
                                                </span>
                                            @endif
                                        </td>

                                        <td>
                                            <div class="d-flex flex-column text-monospace" style="font-size: 0.78rem; gap: 2px;">
                                                <span class="text-dark">
                                                    <span class="text-muted font-weight-normal">TXID:</span> {{ $transaction->trans_id }}
                                                </span>
                                                <span class="text-secondary">
                                                    <span class="text-muted font-weight-normal">REF:</span> {{ $transaction->ref_id }}
                                                </span>
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-5">
                                            <i class="fas fa-receipt d-block mb-3" style="font-size: 2.2rem; opacity: 0.3;"></i>
                                            No payment transactions recorded matching your scope parameters.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
