<?php

use Livewire\Volt\Component;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use App\Models\Website;
use App\Models\Admin;
use Illuminate\Support\Facades\Mail;

use Illuminate\Support\Facades\Hash;


new #[Layout('layouts.admin.auth_layout')]
    #[Title('Staff Login')]

class extends Component {
    public $email = '';
    public $password = '';
    public $remember = false;


    // Validation rules[cite: 4]
    protected $rules = [
        'email' => 'required|email|max:255',
        'password' => 'required',
    ];

    public function mount($code = null)
    {
        // Fetch the first website record to get the logo for the login page
        $this->websites = Website::first();


     // If there is a code in the URL, try to verify the user

        if ($code) {
        $this->verifyAccount($code);
            session()->flash('success', 'Account activated successfully.');
                return redirect('staff-portal/login');

        }
    }
protected function verifyAccount($code)
    {
        try {
            $email = base64_decode($code);
            $admin = Admin::where('email', $email)->first();

            if (!$admin) {
                session()->flash('error', 'Invalid activation link.');
                return;
            }

            // If already verified, just redirect
            if ($admin->hasVerifiedEmail()) {
                session()->flash('info', 'Account already activated. Please login.');
                return;
            }

            // 1. Activate account
            $admin->update(['email_verified_at' => now()]);

            // 2. Prepare Data for Emails
            $admin_email = config('app.email') ?? 'booksbuffets@gmail.com';
            $messageData = [
                'email' => $user->email,
                'name' => $user->name,
                'created_at' => $user->created_at,
                'email_verified_at' => $user->email_verified_at,
            ];

            // 3. Send "Welcome" message to user
            Mail::send('emails.welcome', $messageData, function ($message) use ($email) {
                $message->to($email)->subject('Welcome to ' . config('app.name'));
            });

            // 4. Send "Alert" message to admin
             Mail::send('emails.admin.new-user-deployment-confirmed', $messageData, function ($message) use ($admin_email, $messageData) {
                 $message->to($admin_email)->subject('New User Joined: ' . $messageData['name']);
             });

            // Find the admin user
             //   $admin = User::where('is_admin', '1')->get();

              //  if ($admin) {
             //       $admin->notify(new \App\Notifications\NewUserVerified($user));
             //   }

            session()->flash('info', 'Your account is activated. You can login now.');

            // Set the email field automatically for them
            $this->email = $email;

        } catch (\Exception $e) {
            session()->flash('error', 'Verification failed. The link might be broken.');
        }
    }

public function login()
{
    $this->validate();

    $admin = Admin::where('email', $this->email)->first();

    // 1. Check if Admin exists
    if (!$admin) {
        session()->flash('error', 'The provided credentials do not match our records.');
        return;
    }

    // 2. Check Verification
    if (!$admin->hasVerifiedEmail()) {
        session()->flash('error', 'Please check your email to activate your account.');
        return;
    }

    // 3. Check Status
    if ($admin->status == 0) {
        session()->flash('error', 'Your admin account is not active.');
        return;
    }

    // 4. Attempt Login using the specific guard
    if (Auth::guard('admin')->attempt(['email' => $this->email, 'password' => $this->password], $this->remember)) {
        session()->regenerate();

        // Use a direct redirect if intended() is failing to find the path
        return redirect()->intended(route('admin.dashboard'));
    }

    session()->flash('error', 'The provided credentials do not match our records.');
}

}; ?>

<div class="auth-wrapper">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4"> {{-- Controlled width --}}
                <div class="auth-form-light text-left py-5 px-4 px-sm-5 shadow-lg rounded-3 bg-white">

                    <div class="text-center brand-logo mb-4">
                        <h3 class="font-weight-bold text-primary">STAFF LOGIN</h3>
                    </div>

                    <h5 class="mb-1 text-center">👋 Welcome Back!</h5>
                    <p class="text-muted text-center mb-4">Please sign in to continue.</p>

                   @include('pages.messages')


                    <form wire:submit="login">
                        {{-- Your Inputs Here --}}
                        <div class="form-group mb-3">
                            <input type="text" wire:model="email" class="form-control" placeholder="Email">

                                              <span class="text-danger small">@error('email'){{ $message }}@enderror</span>

                        </div>
                        <div class="form-group mb-4">
                            <input type="password" wire:model="password" class="form-control" placeholder="Password">
                            <span class="text-danger small">@error('password'){{ $message }}@enderror</span>
                        </div>


                         {{-- Remember Me --}}
            <div class="flex items-center">
                <input wire:model="remember" type="checkbox" id="remember"
                    class="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500 cursor-pointer">
                <label for="remember" class="ml-2 text-xs text-slate-600 font-medium cursor-pointer">
                    Remember my session
                </label>
            </div>


                        <button type="submit" class="btn btn-primary w-100 py-3">LOGIN SECURELY</button>

                         <div class="my-3 d-flex justify-content-start align-items-center">
                  <a href="{{ route('admin.register') }}" class="auth-link text-primary small font-weight-medium">
                    Don't have  and account?
                  </a>
                </div>
                         <div class="my-3 d-flex justify-content-end align-items-center">
                  <a href="{{ route('admin-forgot-password') }}" class="auth-link text-primary small font-weight-medium">
                    Forgot password?
                  </a>
                </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
