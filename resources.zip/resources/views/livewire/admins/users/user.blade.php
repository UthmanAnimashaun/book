<?php

use Livewire\Volt\Component;


use App\Models\User;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Users')]
class extends Component {
    // Component state
    public string $title = 'Users';

    public function mount(): void
    {
        // Keep your original session page tracking
        Session::put('page', 'users');
    }

    /**
     * Computed property to fetch users reactively
     */
    public function with(): array
    {
        return [
            'users' => User::all()
        ];
    }

    /**
     * Toggle the user status dynamically
     */
    public function toggleStatus(int $userId): void
    {
        $user = User::find($userId);

        if (!$user) {
            $this->dispatch('toast', message: 'User not found!', type: 'error');
            return;
        }

        // Toggle status: If 1 (Active) -> 0 (Inactive), If 0 -> 1
        $newStatus = $user->status == 1 ? 0 : 1;
        $user->update(['status' => $newStatus]);

        // Status label for the toast notification
        $statusLabel = $newStatus == 1 ? 'Active' : 'Inactive';

        // Dispatch browser event for Butterup toast
        $this->dispatch('toast',
            message: "Status updated to {$statusLabel} for {$user->name}.",
            type: 'success'
        );
    }
}; ?>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">{{ $title }} table</h4>


                   @include("pages.messages")

                <div class="table-responsive pt-3">
                    <table id="users" class="table table-bordered">
                       <thead>
    <tr>
        <th style="width: 5%;">#</th>
        <th>User Details</th>
        <th class="text-center" style="width: 15%;">Status</th>
    </tr>
</thead>
                        <tbody>
                          @foreach ($users as $index => $user)
    <tr wire:key="user-row-{{ $user->id }}" class="align-middle">
        <td class="text-secondary font-weight-medium">{{ $index + 1 }}</td>

        <td>
            <div class="d-flex flex-column">
                <span class="font-weight-bold text-dark mb-1" style="font-size: 1rem;">
                    {{ $user->name }}
                </span>

                <small class="text-muted mb-1 d-flex align-items-center">
                    <i class="mdi mdi-map-marker-outline mr-1"></i>
                    {{ $user->state }} &middot; {{ $user->city ?? 'Not Found' }}
                </small>

                <small class="text-secondary d-flex align-items-center">
                    <span class="mr-3">
                        <i class="mdi mdi-phone-outline mr-1"></i> {{ $user->mobile }}
                    </span>
                    <span>
                        <i class="mdi mdi-email-outline mr-1"></i> {{ $user->email }}
                    </span>
                </small>
            </div>
        </td>

        <td class="text-center">
            <button
                wire:click="toggleStatus({{ $user->id }})"
                wire:loading.attr="disabled"
                wire:target="toggleStatus({{ $user->id }})"
                class="btn p-0 border-0 bg-transparent transition-all"
                style="cursor: pointer; outline: none;"
                title="Click to toggle status"
            >
                <div wire:loading wire:target="toggleStatus({{ $user->id }})" class="spinner-border spinner-border-sm text-primary" role="status">
                    <span class="sr-only">Updating...</span>
                </div>

                <div wire:loading.remove wire:target="toggleStatus({{ $user->id }})">
                    @if ($user->status == 1)
                        <span class="badge badge-pill badge-success px-3 py-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">Active</span>
                    @else
                        <span class="badge badge-pill badge-secondary px-3 py-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">Inactive</span>
                    @endif
                </div>
            </button>
        </td>
    </tr>
@endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


</div>
