<?php

use Livewire\Volt\Component;

use App\Models\Category;
use App\Models\Section;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Manage Categories')]
class extends Component {

    // UI State
    public bool $isModalOpen = false;
    public string $modalTitle = "Add New Category";

    // Form Fields
    public $categoryId;
    public $category_name;
    public $section_id;
    public $url;
    public $parent_id = 0;

    public function with(): array
    {
        Session::put('page', 'categories');

        return [
            'categories' => Category::with('section')
                ->withCount('products')
                ->orderBy('id', 'desc')
                ->get(),
            'sections' => Section::where('status', 1)->get(),
            'parentCategories' => $this->section_id
                ? Category::where('section_id', $this->section_id)
                    ->where('id', '!=', $this->categoryId)
                    ->where('status', 1)
                    ->get()
                : []
        ];
    }

    // Toggle Status
    public function updateCategoryStatus($id, $currentStatus)
    {
        $newStatus = $currentStatus == 1 ? 0 : 1;
        Category::where('id', $id)->update(['status' => $newStatus]);
       // session()->flash('admin_success_message', '');
          $this->dispatch('toast', message: 'Status updated successfully..', type: 'success');
          return; // Exit early to prevent unnecessary re-rendering
    }

    // Open Modal for Create
    public function openAddModal()
    {
        $this->reset(['categoryId', 'category_name', 'section_id', 'url', 'parent_id']);
        $this->modalTitle = "Add New Category";
        $this->isModalOpen = true;
    }

    // Open Modal for Edit
    public function editCategory($id)
    {
        $category = Category::findOrFail($id);
        $this->categoryId = $id;
        $this->category_name = $category->category_name;
        $this->section_id = $category->section_id;
        $this->url = $category->category_slug;
        $this->parent_id = $category->parent_id;

        $this->modalTitle = "Edit Category";
        $this->isModalOpen = true;
    }

    // Save Data (Add or Update)
    public function saveCategory()
    {
        $this->validate([
            'category_name' => 'required|max:255',
            'section_id' => 'required|numeric',
        ]);

        Category::updateOrCreate(
            ['id' => $this->categoryId],
            [
                'category_name' => $this->category_name,
                'section_id' => $this->section_id,
                'parent_id' => $this->parent_id ?? 0,
                'category_slug' => Str::slug($this->url ?: $this->category_name),
                'status' => 1
            ]
        );


        $this->isModalOpen = false;
        $message = $this->categoryId ? 'Category updated!' : 'Category added!';

           $this->dispatch('toast', message:  $message, type: 'success');
          return; // Exit early to prevent unnecessary re-rendering
    }

    public function deleteCategory($id)
    {
        Category::destroy($id);
        $this->dispatch('toast', message: 'Deleted successfully!', type: 'success');
    }
}; ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4 class="card-title text-primary font-weight-bold">
                            <i class="fas fa-tags mr-2"></i> Product Categories
                        </h4>
                        <button wire:click="openAddModal" class="btn btn-primary">
                            <i class="fa fa-plus"></i> Add New Category
                        </button>
                    </div>

                     @include("pages.messages")

                    <div class="table-responsive pt-3">
                        <table class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-light">
                                    <th>#</th>
                                    <th>Category Name</th>
                                    <th>Section</th>
                                    <th>Products</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($categories as $index => $category)
                                <tr wire:key="{{ $category->id }}">
                                    <td>{{ $index + 1 }}</td>
                                    <td>
                                        <div class="font-weight-bold">{{ $category->category_name }}</div>
                                        <small class="text-muted">{{ $category->category_slug }}</small>
                                    </td>
                                    <td>{{ $category->section->name ?? 'N/A' }}</td>
                                    <td>
                                        <span class="badge bg-info text-white">{{ $category->products_count }}</span>
                                    </td>
                                    <td>
                                        <button wire:click="updateCategoryStatus({{ $category->id }}, {{ $category->status }})" class="btn p-0 border-0">
                                            @if($category->status == 1)
                                                <span class="badge bg-success text-light">Active</span>
                                            @else
                                                <span class="badge bg-secondary">Inactive</span>
                                            @endif
                                        </button>
                                    </td>
                                    <td>
                                        <button wire:click="editCategory({{ $category->id }})" class="btn btn-sm btn-outline-warning p-2">
                                            <i class="fa fa-edit"></i>
                                        </button>

                                        @if ($category->products_count == 0)
                                            <button wire:confirm="Are you sure?" wire:click="deleteCategory({{ $category->id }})" class="btn btn-sm btn-outline-danger p-2 ml-1">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        @else
                                            <button class="btn btn-sm btn-outline-secondary p-2 ml-1" title="Cannot delete: Products exist">
                                                <i class="fa fa-exclamation-triangle"></i>
                                            </button>
                                        @endif
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="6" class="text-center text-muted">No categories found.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @if($isModalOpen)
    <div class="modal fade show d-block" style="background: rgba(0,0,0,0.5); overflow-y: auto;" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">{{ $modalTitle }}</h5>
                    <button type="button" class="close text-white" wire:click="$set('isModalOpen', false)">&times;</button>
                </div>
                <form wire:submit.prevent="saveCategory">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Category Name <span class="text-danger">*</span></label>
                            <input type="text" wire:model.blur="category_name" class="form-control @error('category_name') is-invalid @enderror">
                            @error('category_name') <span class="invalid-feedback">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group mt-3">
                            <label>Select Section <span class="text-danger">*</span></label>
                            <select wire:model.live="section_id" class="form-control @error('section_id') is-invalid @enderror">
                                <option value="">Select Section</option>
                                @foreach($sections as $sec)
                                    <option value="{{ $sec->id }}">{{ $sec->name }}</option>
                                @endforeach
                            </select>
                            @error('section_id') <span class="invalid-feedback">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group mt-3">
                            <label>Category Level</label>
                            <select wire:model="parent_id" class="form-control">
                                <option value="0">Main Category</option>
                                @foreach($parentCategories as $pCat)
                                    <option value="{{ $pCat->id }}">{{ $pCat->category_name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group mt-3">
                            <label>URL / Slug (Optional)</label>
                            <input type="text" wire:model="url" class="form-control" placeholder="Leave blank to auto-generate">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" wire:click="$set('isModalOpen', false)">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fa fa-save mr-1"></i> Save Category
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @endif
</div>
