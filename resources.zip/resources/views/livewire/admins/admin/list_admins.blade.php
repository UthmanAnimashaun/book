<?php

use Livewire\Volt\Component;
use App\Models\Admin;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Manage Admins and Vanedors Dashboard')]
class extends Component {
    public string $title = "Manage Admins & Vendors";

    // Data provider for the view
    public function with(): array
    {
        Session::put('page', 'view_admins');

        return [
            'admins' => Admin::select('id', 'name', 'email', 'is_admin', 'image', 'status', 'created_at')
                ->orderBy('id', 'desc')
                ->get()
        ];
    }

    // Toggle Status Logic
    public function updateAdminStatus(int $adminId): void
    {
        $admin = Admin::find($adminId);

        if (!$admin) {
            $this->dispatch('toast', message: 'Account records not found.', type: 'error');
            return;
        }

        $newStatus = $admin->status == 1 ? 0 : 1;
        $admin->update(['status' => $newStatus]);

        $statusLabel = $newStatus == 1 ? 'Activated' : 'Deactivated';

        $this->dispatch('toast',
            message: "{$admin->name} has been successfully {$statusLabel}.",
            type: 'success'
        );
    }

    // Delete Logic
    public function deleteAdmin(int $adminId): void
    {
        $admin = Admin::find($adminId);

        if ($admin) {
            $adminName = $admin->name;
            $admin->delete();

            $this->dispatch('toast',
                message: "Account profile for {$adminName} was permanently deleted.",
                type: 'success'
            );
        }
    }
}; ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card shadow-sm border-0">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4 class="card-title text-primary font-weight-bold">
                            <i class="fas fa-users-cog mr-2"></i> {{ $title }}
                        </h4>
                    </div>

                    <div class="table-responsive pt-3">
                        <table id="admins" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-light">
                                    <th style="width: 5%;">#</th>
                                    <th>Admin Details</th>
                                    <th class="text-center" style="width: 15%;">Status</th>
                                    <th class="text-center" style="width: 10%;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($admins as $index => $admin)
                                <tr wire:key="admin-row-{{ $admin->id }}" class="align-middle">
                                    <td class="text-secondary font-weight-medium">{{ $index + 1 }}</td>

                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="mr-3">
                                                @if (!empty($admin->image))
                                                    <a href="{{ asset('storage/images/admin_photos/'.$admin->image) }}" target="_blank">
                                                        <img src="{{ asset('storage/images/admin_photos/'.$admin->image) }}"
                                                            alt="Profile" class="rounded-circle shadow-sm"
                                                            style="width: 45px; height: 45px; object-fit: cover;">
                                                    </a>
                                                @else
                                                    <div class="rounded-circle d-flex align-items-center justify-content-center bg-light font-weight-bold text-primary shadow-sm"
                                                         style="width: 45px; height: 45px; font-size: 0.9rem; border: 1px solid #e3e6f0;">
                                                        {{ strtoupper(substr($admin->name, 0, 2)) }}
                                                    </div>
                                                @endif
                                            </div>

                                            <div class="d-flex flex-column">
                                                <div class="d-flex align-items-center mb-1">
                                                    <span class="font-weight-bold text-dark mr-2" style="font-size: 1rem;">
                                                        {{ $admin->name }}
                                                    </span>

                                                    @if ($admin->is_admin == 1)
                                                        <span class="badge badge-pill text-white bg-danger px-2" style="font-size: 0.7rem;">Super Admin</span>
                                                    @elseif ($admin->is_admin == 2)
                                                        <span class="badge badge-pill text-white bg-info px-2" style="font-size: 0.7rem;">Vendor</span>
                                                    @else
                                                        <span class="badge badge-pill text-white bg-secondary px-2" style="font-size: 0.7rem;">Guest</span>
                                                    @endif
                                                </div>

                                                <small class="text-secondary d-flex align-items-center">
                                                    <span class="mr-3">
                                                        <i class="far fa-envelope mr-1"></i> {{ $admin->email }}
                                                    </span>
                                                    <span class="text-muted">
                                                        <i class="far fa-clock mr-1"></i> {{ $admin->created_at ? $admin->created_at->diffForHumans() : 'N/A' }}
                                                    </span>
                                                </small>
                                            </div>
                                        </div>
                                    </td>

                                    <td class="text-center">
                                        <button
                                            wire:click="updateAdminStatus({{ $admin->id }})"
                                            wire:loading.attr="disabled"
                                            wire:target="updateAdminStatus({{ $admin->id }})"
                                            class="btn p-0 border-0 bg-transparent"
                                            style="cursor: pointer; outline: none;"
                                            title="Click to switch status"
                                        >
                                            <div wire:loading wire:target="updateAdminStatus({{ $admin->id }})" class="spinner-border spinner-border-sm text-primary" role="status">
                                                <span class="sr-only">Updating...</span>
                                            </div>

                                            <div wire:loading.remove wire:target="updateAdminStatus({{ $admin->id }})">
                                                @if ($admin->status == 1)
                                                    <span class="badge badge-pill badge-success px-3 py-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">Active</span>
                                                @else
                                                    <span class="badge badge-pill badge-secondary px-3 py-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">Inactive</span>
                                                @endif
                                            </div>
                                        </button>
                                    </td>

                                    <td class="text-center">
                                        <button
                                            wire:click="deleteAdmin({{ $admin->id }})"
                                            wire:confirm="Are you sure you want to permanently delete this user account profile?"
                                            wire:loading.attr="disabled"
                                            class="btn btn-sm btn-outline-danger p-2 shadow-sm border-0"
                                            style="border-radius: 6px;"
                                            title="Delete Account Entry"
                                        >
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-5">
                                        <i class="fas fa-folder-open d-block mb-2 style-2x" style="font-size: 1.5rem;"></i>
                                        No structural admin or vendor records matching dataset signatures found.
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

                   @include("pages.messages")

</div>
