<?php

use Livewire\Volt\Component;
use App\Models\Product;
use App\Models\Category;
use App\Models\Section;
use App\Models\Order;
use App\Models\OrdersProduct;
use App\Models\Admin;
use App\Models\User;
use App\Models\Subscriber; // Imported Subscriber Model
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

new #[Layout('layouts.admin.app')]
    #[Title('Admin Dashboard')]
class extends Component {

    public $totalBooks, $totalOrders, $totalVendors, $totalUsers, $totalSubscribers;
    public $totalSections, $totalCategories;
    public $recentOrders = [];
    public $salesLabels = [];
    public $salesData = [];
    public $adminName;
    public $is_admin;

    public function mount()
    {
        Session::put('page', 'dashboard');

        // Ensure you use the correct guard 'staff-portal' we set up earlier
        $admin = Auth::guard('admin')->user();
        $admin_id = $admin->id;
        $this->is_admin = $admin->is_admin;
        $this->adminName = $admin->name;

        /** ========== COUNTERS ========== */
        if ($this->is_admin == 1) {
            $this->totalBooks       = Product::count();
            $this->totalCategories  = Category::count();
            $this->totalSections    = Section::count();
            $this->totalOrders      = Order::count(); // Use Order count for main admin
            $this->totalUsers       = User::count();
            $this->totalVendors     = Admin::where('is_admin', 2)->count();
            $this->totalSubscribers = Subscriber::count(); // Main Admin can see all subscribers
            $this->recentOrders     = OrdersProduct::with('order')->latest()->take(5)->get();
        } else {
            $this->totalBooks       = Product::where('admin_id', $admin_id)->count();
            $this->totalCategories  = Category::count();
            $this->totalSections    = Section::count();
            $this->totalOrders      = OrdersProduct::where('admin_id', $admin_id)->count();
            $this->totalUsers       = 0;
            $this->totalVendors     = 0;
            $this->totalSubscribers = 0; // Vendors don't manage main platform subscriptions
            $this->recentOrders     = OrdersProduct::where('admin_id', $admin_id)->latest()->take(5)->get();
        }

        /** ========== SALES CHART DATA (Ensuring 30 consecutive days) ========== */
        $startDate = now()->subDays(29)->startOfDay();
        $salesResults = Order::select(
            DB::raw('DATE(created_at) as date'),
            DB::raw('SUM(grand_total) as total')
        )
        ->when($this->is_admin == 2, function ($q) use ($admin_id) {
            return $q->whereHas('orders_products', fn($q2) => $q2->where('admin_id', $admin_id));
        })
        ->where('created_at', '>=', $startDate)
        ->groupBy('date')
        ->get()
        ->keyBy('date');

        // Reset arrays to ensure they are empty before filling
        $this->salesLabels = [];
        $this->salesData = [];

        // Fill the 30-day range correctly
        for ($i = 29; $i >= 0; $i--) {
            $currentDate = now()->subDays($i);
            $dateKey = $currentDate->format('Y-m-d');

            $this->salesLabels[] = $currentDate->format('M d');

            // Explicitly check if the collection has the key
            if ($salesResults->has($dateKey)) {
                $this->salesData[] = (float) $salesResults->get($dateKey)->total;
            } else {
                $this->salesData[] = 0;
            }
        }

        // Dispatch an event to tell JavaScript the data is ready
        $this->dispatch('chartUpdated');
    }
};
?>

<div class="content-wrapper" style="background: #f8f9fc;">
    {{-- Header Section --}}
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="d-flex align-items-center justify-content-between bg-white p-4 rounded-3 shadow-sm">
                <div>
                    <h3 class="font-weight-bold text-dark mb-1">Welcome back, {{ $adminName }}! 👋</h3>
                    <p class="text-muted mb-0">Here's what's happening with your store today.</p>
                </div>
                <div class="d-none d-md-block">
                    <span class="badge bg-primary-subtle text-primary p-2 px-3 rounded-pill">
                        📅 {{ now()->format('D, M d, Y') }}
                    </span>
                </div>
            </div>
        </div>
    </div>

    {{-- STAT CARDS --}}
    <div class="row g-3 my-4">

        @include('admin.components.stat-card', [
            'title' => 'Total Books',
            'value' => $totalBooks,
            'icon' => '📚'
        ])

        @include('admin.components.stat-card', [
            'title' => 'Total Orders',
            'value' => $totalOrders,
            'icon' => '📦'
        ])

        @include('admin.components.stat-card', [
            'title' => 'Total Sections',
            'value' => $totalSections,
            'icon' => '🗂️'
        ])

        @include('admin.components.stat-card', [
            'title' => 'Total Categories',
            'value' => $totalCategories,
            'icon' => '🏷️'
        ])

        @if($is_admin == 1)
            @include('admin.components.stat-card', [
                'title' => 'Total Vendors',
                'value' => $totalVendors,
                'icon' => '🏪'
            ])

            @include('admin.components.stat-card', [
                'title' => 'Total Users',
                'value' => $totalUsers,
                'icon' => '👥'
            ])

            {{-- Added Subscribers Stat Card --}}
            @include('admin.components.stat-card', [
                'title' => 'Subscribers',
                'value' => $totalSubscribers,
                'icon' => '📧'
            ])
        @endif

    </div>

    <div class="row g-4">
        {{-- SALES CHART --}}
        <div class="col-12 col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <h6 class="fw-bold text-dark mb-0">Revenue Overview</h6>
                        <select class="form-select form-select-sm w-auto border-0 bg-light">
                            <option>Last 30 Days</option>
                        </select>
                    </div>
                </div>
                <div class="card-body p-4" wire:ignore>
                    <div style="height: 300px;" wire:ignore>
                        <canvas id="salesChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        {{-- RECENT ORDERS --}}
        <div class="col-12 col-lg-4">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-header bg-white border-0 py-3">
                    <h6 class="fw-bold text-dark mb-0">Recent Activity</h6>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        @forelse($recentOrders as $order)
                            <div class="list-group-item border-0 px-4 py-3 border-bottom">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="d-flex align-items-center">
                                        <div class="bg-light rounded-3 p-2 me-3">
                                            <span>🛍️</span>
                                        </div>
                                        <div>
                                            <p class="mb-0 fw-bold text-dark">Order #{{ $order->id }}</p>
                                            <small class="text-muted">{{ Str::limit($order->product_name, 20) }}</small>
                                        </div>
                                    </div>
                                    <span class="fw-bold text-dark">₦{{ number_format($order->product_price * $order->product_qty) }}</span>
                                </div>
                            </div>
                        @empty
                            <div class="p-5 text-center">
                                <img src="https://cdn-icons-png.flaticon.com/512/5058/5058436.png" style="width: 50px; opacity: 0.3;">
                                <p class="text-muted mt-2">No recent activity</p>
                            </div>
                        @endforelse
                    </div>
                </div>
                <div class="card-footer bg-white border-0 text-center py-3">
                    <a href="{{ route('admin.orders') }}" class="btn btn-light btn-sm w-100 text-primary fw-bold">View All Orders</a>
                </div>
            </div>
        </div>
    </div>

    @script
    <script>
        let chart;
        const renderChart = () => {
            const ctx = document.getElementById('salesChart');
            if (!ctx) return;

            if (chart) chart.destroy();
            chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: $wire.salesLabels,
                    datasets: [{
                        label: 'Sales Total',
                        data: $wire.salesData,
                        borderColor: '#4f46e5',
                        tension: 0.3,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                }
            });
        };

        renderChart();
        $wire.on('chartUpdated', () => {
            renderChart();
        });
    </script>
    @endscript
</div>
