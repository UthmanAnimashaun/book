<footer class="bg-blue-900 text-gray-300 mt-16 pt-12 pb-8 border-t border-amber-600/30">
  <div class="max-w-6xl mx-auto px-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
    <div>
      <h4 class="text-lg font-semibold text-gray-100 mb-2">📚 Book Buffet</h4>
      <p class="text-gray-400 hover:text-gray-200 focus:outline-hidden focus:text-gray-200">Lagos' premier multi-vendor bookstore connecting readers with book sellers across the states.</p>
    </div>
    <div>
      <h4 class="text-lg font-semibold text-gray-100 mb-2">🛍️ Shop</h4>
      <ul class="grid space-y-3 text-sfm">
        <li><a href="{{ route('product-shop') }}" class="hover:text-amber-600 transition duration-150">📖 All Books</a></li>
        <li><a href="{{ route('about') }}" class="hover:text-amber-600 transition duration-150">ℹ️ About Us</a></li>
        <li><a href="{{ route('contact') }}" class="hover:text-amber-600 transition duration-150">📞 Contact Us</a></li>
        <li><a href="#" class="hover:text-amber-600 transition duration-150">🚚 Delivery Info</a></li>
      </ul>
    </div>
    <div>
      <h4 class="text-lg font-semibold text-gray-100 mb-2">🤝 Vendors</h4>
      <ul class="grid space-y-3">
        <li><a href="{{ route('vendors') }}" class="hover:text-amber-600 transition duration-150">🏪 Vendors</a></li>
        <li><a href="#" class="hover:text-amber-600 transition duration-150">🚀 Become a Vendor</a></li>
        <li><a href="{{ route('admin.login') }}" class="hover:text-amber-600 transition duration-150">🔑 Vendor Login</a></li>
        <li><a href="#" class="hover:text-amber-600 transition duration-150">💡 Vendor Help</a></li>
      </ul>
    </div>
    <div>
      <h4 class="text-lg font-semibold text-gray-100 mb-2">🔗 Links</h4>
      <ul class="grid space-y-3">
        <li><a href="{{ route('faq') }}" class="hover:text-amber-600 transition duration-150">❓ FAQ</a></li>
        <li><a href="{{ route('pp') }}" class="hover:text-amber-600 transition duration-150">🔒 Privacy Policy</a></li>
        <li><a href="{{ route('tc') }}" class="hover:text-amber-600 transition duration-150">📜 Terms & Condition</a></li>
      </ul>
    </div>
  </div>

  <div class="mt-8 text-center text-sm text-gray-400 hover:text-gray-200 focus:outline-hidden space-y-4 md:space-y-0 md:space-x-4 focus:text-gray-200">
      <p class="mb-4 md:mb-2"> © 2025 Book Buffet. All rights reserved. Made with ❤️ By: <a href="http://axiondesign.netlify.app" target="_blank" rel="noopener noreferrer">Uthman (AXION)</a> in Lagos, Nigeria.</p>

      {{-- SWAPPED SOCIAL AND CONTACT FONTAWESOME ICONS TO EMOJIS --}}
      <a href="tel:{{ optional($websites[0])->phone_number }}" class="inline-flex items-center hover:text-amber-600 transition duration-150 mx-2">📞 <span class="ml-1">{{ optional($websites[0])->phone_number }}</span></a>

      <a href="mailto:{{ optional($websites[0])->email }}" class="inline-flex items-center hover:text-amber-600 transition duration-150 mx-2">✉️ <span class="ml-1">{{ optional($websites[0])->email }}</span></a>

      <a href="{{ optional($websites[0])->facebook }}" class="hover:text-amber-600 transition duration-150 mx-2 text-base" title="Facebook">👥</a>

      <a href="{{ optional($websites[0])->whatsapp }}" class="hover:text-amber-600 transition duration-150 mx-2 text-base" title="WhatsApp">💬</a>

      <a href="{{ optional($websites[0])->twitter }}" class="hover:text-amber-600 transition duration-150 mx-2 text-base" title="Twitter / X">🐦</a>
  </div>
</footer>
