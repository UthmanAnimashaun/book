<!DOCTYPE html>
<html class="no-js" lang="en-US">

<head>
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-NSZR4J2F');</script>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="google-site-verification" content="m9hcsilnvMSU7049C0Ca_LlWXVLqGVZc3N8HBkYlqAk" />

    <title>{{ $title ?? 'Book Buffet | Buy & Sell Books Online in Nigeria' }}</title>

    <meta name="title" content="{{ $meta_title ?? 'Book Buffet | Buy & Sell Books Online in Nigeria' }}">
    <meta name="description" content="{{ $meta_description ?? 'Explore a vast collection of new and used books at Book Buffet. Nigeria\'s trusted multi-vendor marketplace for readers and independent booksellers.' }}">
    <meta name="keywords" content="buy books online Nigeria, online bookstore Lagos, multi-vendor bookstore, used books Nigeria, academic books, Islamic books, novels, Book Buffet, {{ optional($websites[0])->name }}">
    <meta name="author" content="AXION Designs">
    <link rel="canonical" href="{{ url()->current() }}">

    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:site_name" content="Book Buffet">

    <meta property="og:title" content="{{ $meta_title ?? 'Book Buffet - The Ultimate Marketplace for Book Lovers' }}">
    <meta property="og:description" content="{{ $meta_description ?? 'Join thousands of readers. Buy your favorite titles or start selling your own books today on Book Buffet.' }}">
    <meta property="og:image" content="{{ asset('storage/images/logo/'.optional($websites[0])->logo) }}">

    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="{{ url()->current() }}">
    <meta property="twitter:title" content="{{ $meta_title ?? 'Book Buffet | Buy & Sell Books Online in Nigeria' }}">
    <meta property="twitter:description" content="{{ $meta_description ?? 'Shop a massive collection of books from multiple vendors across Nigeria.' }}">
    <meta property="twitter:image" content="{{ asset('storage/images/logo/'.optional($websites[0])->logo) }}">

    <link href="{{ asset('storage/images/logo/'.optional($websites[0])->logo) }}" rel="shortcut icon">
    <link rel="apple-touch-icon" href="{{ asset('storage/images/logo/'.optional($websites[0])->logo) }}">

    <link rel="manifest" href="{{ asset('manifest.json') }}">

    {{-- Google analytics --}}
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-QSPH620WX0"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'G-QSPH620WX0');
    </script>



    {{-- Datatable Styles --}}
    <link rel="stylesheet" href="/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="/admin/js/select.dataTables.min.css">

    <link rel="stylesheet" href="/front/css/custom.css">

    <script src="/front/js/tailwind.js"></script>
    <link rel="stylesheet" href="/front/css/tailwind.min.css">


    <link rel="stylesheet" href="/front/css/fontawesome.min.css">
    <link rel="stylesheet" href="/front/css/Font.css">

    {{-- sweetAlert & Butterup--}}
    <link rel="stylesheet" href="/admin/butterup/butterup.min.css">
    <link href="/admin/sweetalert/sweetalert2.css" rel="stylesheet"/>


    <style>
        .bg-cream-100 { background-color: #f7f3e8; }
        .bg-blue-900 { background-color: #1e3a8a; }
        .bg-info-50 {background-color: #F3FAFC;}
        .bg-info-100 {background-color: #E7F4F9;}
        .bg-info-200 {background-color: #CEE9F2;}
        .bg-info-300 {background-color: #B6DFEC;}
        .bg-info-400 {background-color: #9ED4E6;}
        .bg-info-500 {background-color: #79C4DC;}
        .bg-info-600 {background-color: #34A4CA;}
        .bg-info-700 {background-color: #2B89A8;}
        .bg-info-800 {background-color: #236D86;}
        .bg-info-900 {background-color: #1A5265;}
        .text-blue-900 { color: #1e3a8a; }
        .text-amber-600 { color: #d97706; }
        .border-gray-300 { border-color: #d1d5db; }

        .card-hover {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.021), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        [x-cloak] {
          display: none !important;
        }
    </style>

    @stack('stylesheets')
      @livewireStyles

</head>

<body class="font-sans tracking-wide bg-cream-100 text-blue-900">

    <div id="app">
        {{-- Custom global header Livewire component --}}
        @livewire('front.layouts.header')

        <div class="main-panel">
            {{-- Required slot for Livewire 3 full page components --}}
            {{ $slot }}
        </div>

        {{-- Global layout footer --}}
        @include('layouts.front.footer')
    </div>
@livewireScripts

    <script>
        window.ga = function() { ga.q.push(arguments) }; ga.q = []; ga.l = +new Date;
        ga('create', 'UA-XXXXX-Y', 'auto'); ga('send', 'pageview');
    </script>
    <script src="/front/https://www.google-analytics.com/analytics.js" async defer></script>
    <script type="text/javascript" src="/front/js/vendor/modernizr-custom.min.js"></script>
    <script type="text/javascript" src="/front/js/nprogress.min.js"></script>
    <script type="text/javascript" src="/front/js/jquery.min.js"></script>
    <script type="text/javascript" src="/front/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/front/js/popper.min.js"></script>
    <script type="text/javascript" src="/front/js/jquery.scrollUp.min.js"></script>
    <script type="text/javascript" src="/front/js/app.js"></script>
    <script type="text/javascript" src="/front/js/custom.js"></script>

    {{-- butterup --}}
    <script src="/admin/butterup/butterup.min.js"></script>
  <script src="/admin/butterup/butterup.js"></script>
    {{-- dataTable --}}
    <script src="/admin/vendors/datatables.net/jquery.dataTables.js"></script>
    <script src="/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
    <script src="/admin/js/dataTables.select.min.js"></script>

    <script>
        $(document).ready(function(){
            $('#trans').DataTable();
        });
    </script>

    <script src="/admin/sweetalert/sweetalert2.js"></script>

    {{-- @include('front.layouts.scripts') --}}
    @stack('scripts')
</body>
</html>
