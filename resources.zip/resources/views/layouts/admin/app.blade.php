<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="csrf_token" content="{{ csrf_token() }}">

  {{-- Dynamically set the title if provided by the Volt component --}}
  <title>{{ $title ?? 'BookBuffet Admin' }}</title>

  <!-- Standard Favicon -->
  {{-- <link href="{{ url('/storage/images/logo/'. optional($websites[0])->logo )}}" rel="shortcut icon" type="image/x-icon"> --}}

@if($website && $website->logo)
    <link href="{{ asset('storage/images/logo/' . $website->logo) }}" rel="shortcut icon" type="image/x-icon">
  @endif
  <!-- plugins:css -->
  <link rel="stylesheet" href="/admin/vendors/feather/feather.css">
  <link rel="stylesheet" href="/admin/vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="/admin/vendors/css/vendor.bundle.base.css">

  <!-- Plugin css -->
  <link rel="stylesheet" href="/admin/vendors/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.css">

  <!-- inject:css -->
  <link rel="stylesheet" href="/admin/css/vertical-layout-light/style.css">
  <link rel="stylesheet" href="/admin/butterup/butterup.min.css">
  <link href="/admin/sweetalert/sweetalert2.css" rel="stylesheet" />

  @stack('stylesheets')

  {{-- Livewire Styles (Optional in V3, but safe) --}}
  @livewireStyles

  <style>
    :root { --brand: #0d6efd; --muted-dark: #222831; --card-radius: .75rem; }
    body { background: #f5f7fb; color: #121212; font-family: Inter, system-ui, sans-serif; }
    .stat-card { border-radius: var(--card-radius); box-shadow: 0 6px 20px rgba(15, 15, 20, .04); }
  </style>
</head>

<body>
  <div class="container-scroller">
    {{-- Top Navbar --}}
    @include('layouts.admin.header')

    <div class="container-fluid page-body-wrapper">
      {{-- Sidebar --}}
      @include('layouts.admin.sidebar')

      <div class="main-panel">
        <div class="content-wrapper">
            {{-- This $slot is where your Volt components will be injected --}}
            {{ $slot }}
        </div>

        {{-- Footer --}}
        @include('layouts.admin.footer')
      </div>
    </div>
  </div>

  <!-- core:js -->
  <script src="/admin/vendors/js/vendor.bundle.base.js"></script>

  {{-- Livewire Scripts --}}
  @livewireScripts

  <!-- Plugin js -->
  <script src="/admin/vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <script src="/admin/sweetalert/sweetalert2.js"></script>
  <script src="/admin/butterup/butterup.min.js"></script>

  <!-- inject:js -->
  <script src="/admin/js/off-canvas.js"></script>
  <script src="/admin/js/hoverable-collapse.js"></script>
  <script src="/admin/js/template.js"></script>
  <script src="/admin/js/custom.js"></script>

  @stack('scripts')
</body>
</html>
