<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item">
        <a href="{{ route('admin.dashboard') }}"
           @if (Session::get('page')=="dashboard") style="background: #4B49AC !important; color:#fff !important;" @endif
           class="nav-link">
          <i class="icon-grid menu-icon"></i>
          <span class="menu-title">Dashboard

          </span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic"
           @if (in_array(Session::get('page'), ["update-admin-details", "website", "faq", "rating"])) style="background: #4B49AC !important; color:#fff !important;" @endif>
          <i class="menu-icon fa solid fa-gear"></i>
          <span class="menu-title">Settings</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="ui-basic">
          <ul class="nav flex-column sub-menu highlight_background">
            <li class="nav-item">
                <a class="nav-link" href="{{ route('update-admin-details') }}"
                   style="@if (Session::get('page')=='update-admin-details') background: #4B49AC !important; color:#fff !important; @else background: #fff !important; color:#4B49AC !important; @endif">
                   My details
                </a>
            </li>

               <li class="nav-item"> <a class="nav-link" href="{{ route('admin.rating') }}" style="@if (Session::get('page')=='admin.rating') background: #4B49AC !important; color:#fff !important; @else background: #fff !important; color:#4B49AC !important; @endif">Rating & Review</a></li>

            @if (Auth::guard('admin')->user()->is_admin === 1)

                <li class="nav-item"> <a class="nav-link" href="{{ route('admin.editwebsite') }}" style="@if (Session::get('page')=='admin.editwebsite') background: #4B49AC !important; color:#fff !important; @else background: #fff !important; color:#4B49AC !important; @endif">Website Details</a></li>

                <li class="nav-item"> <a class="nav-link" href="{{ route('admin.faq') }}" style="@if (Session::get('page')=='admin.faq') background: #4B49AC !important; color:#fff !important; @else background: #fff !important; color:#4B49AC !important; @endif">FAQ</a></li>

            @endif
          </ul>
        </div>
      </li>

      @if (Auth::guard('admin')->user()->is_admin === 1)
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#Admin-Management" @if (Session::get('page')=="view_admins") style="background: #4B49AC !important; color:#fff !important;" @endif>
          <i class="menu-icon fa fa-user"></i>
          <span class="menu-title">Admin</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="Admin-Management">
          <ul class="nav flex-column sub-menu highlight_background">
            <li class="nav-item">
                <a class="nav-link" href="{{ route('admin.admins') }}"
                   style="@if (Session::get('page')=='view_admins') background: #4B49AC !important; color:#fff !important; @else background: #fff !important; color:#4B49AC !important; @endif">
                   Admins
                </a>
            </li>
          </ul>
        </div>
      </li>
      @endif

      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#Catalogue" @if (in_array(Session::get('page'), ["sections", "categories", "products"])) style="background: #4B49AC !important; color:#fff !important;" @endif>
          <i class="menu-icon fa fa-book"></i>
          <span class="menu-title">Catalogue</span>
          {{-- <i class="menu-arrow"></i> --}}
        </a>
        <div class="collapse" id="Catalogue">
          <ul class="nav flex-column sub-menu highlight_background">

             
            @if (Auth::guard('admin')->user()->is_admin === 1)
              <li class="nav-item"> <a class="nav-link" href="{{ route('admin.sections') }}" style="@if (Session::get('page')=='admin.sections') background: #4B49AC !important; color:#fff !important; @else background: #fff !important; color:#4B49AC !important; @endif">Sections</a></li>
              <li class="nav-item"> <a class="nav-link" href="{{ route('admin.categories') }}" style="@if (Session::get('page')=='admin.categories') background: #4B49AC !important; color:#fff !important; @else background: #fff !important; color:#4B49AC !important; @endif">Categories</a></li>
              <li class="nav-item"> <a class="nav-link" href="{{ route('admin.products') }}" style="@if (Session::get('page')=='admin.products') background: #4B49AC !important; color:#fff !important; @else background: #fff !important; color:#4B49AC !important; @endif">Products</a></li>
            @else
                <li class="nav-item"> <a class="nav-link" href="{{ route('admin.products') }}" style="@if (Session::get('page')=='admin.products') background: #4B49AC !important; color:#fff !important; @else background: #fff !important; color:#4B49AC !important; @endif">Products</a></li>
            @endif
          </ul>
        </div>
      </li>

      @if (Auth::guard('admin')->user()->is_admin === 1)
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#Users_Management" @if (Session::get('page')=="users") style="background: #4B49AC !important; color:#fff !important;" @endif>
          <i class="menu-icon fa solid fa-users"></i>
          <span class="menu-title">Users</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="Users_Management">
          <ul class="nav flex-column sub-menu highlight_background">
            <li class="nav-item"> <a class="nav-link" href="{{ route('admin.users') }}" style="@if (Session::get('page')=='admin.users') background: #4B49AC !important; color:#fff !important; @else background: #fff !important; color:#4B49AC !important; @endif">
            Users</a></li>
          </ul>
        </div>
      </li>


      @endif

      <li class="nav-item">
        <a href="{{ route('admin.location') }}" class="nav-link" @if (Session::get('page')=="Locations") style="background: #4B49AC !important; color:#fff !important;" @endif>
          <i class="menu-icon fa fa-map-marker"></i>
          <span class="menu-title">Locations Fee</span>
        </a>
      </li>

        @if (Auth::guard('admin')->user()->is_admin === 1)
            <li class="nav-item">
                <a href="{{ route('admin.transactions') }}" class="nav-link" @if (Session::get('page')=="Transaction") style="background: #4B49AC !important; color:#fff !important;" @endif>
                <i class="menu-icon fa fa-credit-card"></i>
                <span class="menu-title">Transactions</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('clear-everything') }}" class="nav-link">
                <i class="menu-icon fa fa-credit-card"></i>
                <span class="menu-title">Clear Everything</span>
                </a>
            </li>
        @endif

      <li class="nav-item">
        <a href="{{ route('admin.orders') }}" class="nav-link" @if (Session::get('page')=="Orders") style="background: #4B49AC !important; color:#fff !important;" @endif>
          <i class="menu-icon fa fa-shopping-cart"></i>
          <span class="menu-title">Orders</span>
        </a>
      </li>

      <li class="nav-item">
  <a href="{{ route('admin.notification-center') }}"
     class="nav-link"
     @if (Session::get('page') == "Notifications-Center") style="background: #4B49AC !important; color:#fff !important;" @endif>
    <i class="menu-icon icon-bell"></i>
    <span class="menu-title">Notification Center</span>
  </a>
</li>

      <li class="nav-item">
        <a href="{{ route('admin.terms-and-conditions') }}" class="nav-link" @if (Session::get('page')=="TC") style="background: #4B49AC !important; color:#fff !important;" @endif>
          <i class="menu-icon fa fa-file-text"></i>
          <span class="menu-title">{{ Auth::guard('admin')->user()->is_admin == 2 ? 'Terms and Condition' : "Vendor's T & C" }}</span>
        </a>
      </li>
    </ul>
</nav>
