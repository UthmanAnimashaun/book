<nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
    <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
      <a class="navbar-brand brand-logo mr-5" href="{{ url('admin/dashboard') }}">
        @if($website && $website->logo)
            <img src="{{ asset('storage/images/logo/' . $website->logo) }}" alt="{{ $website->name }}" class="mr-2" style="width: 140px; height: auto; object-fit: contain;">
        @else
            <span class="font-weight-bold text-primary">{{ $website->name ?? 'BookBuffet' }}</span>
        @endif
      </a>
      <a class="navbar-brand brand-logo-mini" href="{{ url('admin/dashboard') }}">
        @if($website && $website->logo)
            <img src="{{ asset('storage/images/logo/' . $website->logo) }}" alt="{{ $website->name }}" />
        @else
            <span class="font-weight-bold text-primary">B</span>
        @endif
      </a>
    </div>

    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
      <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
        <span class="icon-menu"></span>
      </button>

      <ul class="navbar-nav navbar-nav-right">
        {{-- NOTIFICATION BELL CENTER LINK SHORTCUT --}}
        {{-- Livewire Volt Component Injection Hooks --}}
        <livewire:admins.components.notification-bell />

        {{-- USER ADMIN PROFILE ACCESSIBILITY CONTROLS WITH LOGOUT --}}
        <li class="nav-item nav-profile dropdown">
          <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" data-toggle="dropdown" id="profileDropdown">
            @if (Auth::guard('admin')->check() && !empty(Auth::guard('admin')->user()->image))
                <img src="{{ asset('storage/images/admin_photos/' . Auth::guard('admin')->user()->image) }}" alt="profile" class="rounded-circle" style="width: 34px; height: 34px; object-fit: cover;"/>
            @else
                <img src="{{ asset('storage/images/admin_photos/default.jpg') }}" alt="profile" class="rounded-circle" style="width: 34px; height: 34px; object-fit: cover;"/>
            @endif
          </a>

       <div class="dropdown-menu dropdown-menu-right navbar-dropdown shadow-sm border-0 mt-2" aria-labelledby="profileDropdown" style="border-radius: 8px;">
    <a href="{{ route('update-admin-details') }}" class="dropdown-item py-2.5">
        <i class="ti-settings text-primary mr-2"></i>
        My Details
    </a>

                <form method="POST" action="{{ route('admin.logout') }}">
                    @csrf
                    <button type="submit" class="dropdown-item py-2.5" style="background: none; border: none; width: 100%; text-align: left;">
                        <span>🚪</span> Logout
                    </button>
                </form>
                {{-- @endauth --}}
    <div class="dropdown-divider my-1" style="opacity: 0.15;"></div>

    {{-- LIVEWIRE 3 VOLT SFC LOGOUT TRIGGER ACTION --}}
    {{-- <livewire:pages.admins.logout-action /> --}}
    {{-- <livewire:pages.admins.notifications.notification /> --}}

</div>
        </li>
      </ul>

      <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
        <span class="icon-menu"></span>
      </button>
    </div>
</nav>
