<div class="col-12 col-md-6 col-lg-3">
    <div class="card shadow-sm p-3 rounded-3 h-100">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <small class="text-muted">{{ $title }}</small>
                <h4 class="fw-bold mb-0">{{ $value }}</h4>
            </div>
            <div class="bg-light rounded-circle p-3">
                <i class="fa fa-2x text-primary"> {{ $icon }}</i>
            </div>
        </div>
    </div>
</div>
