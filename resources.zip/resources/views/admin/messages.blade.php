  {{-- error message  for bootstrap--}}
  @if (Session::has('admin_error_message'))
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
     {{ Session::get('admin_error_message') }}
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
       <span aria-hidden="true">&times;</span>
     </button>
   </div>
 @endif
 @if (Session::has('admin_swal_success_message'))
  <div class="alert alert-success alert-dismissible fade show" role="alert">
     {{ Session::get('admin_swal_success_message') }}
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
       <span aria-hidden="true">&times;</span>
     </button>
   </div>
 @endif




 {{-- successful message --}}
 @if (Session::has('admin_success_message'))
 <div class="alert alert-success alert-dismissible fade show" role="alert">
     {{ Session::get('admin_success_message') }}
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
       <span aria-hidden="true">&times;</span>
     </button>
   </div>
 @endif





 {{-- Tailwind css --}}
  {{-- error message --}}
  @if (Session::get('error_message'))
  <div id="errorAlert" class="max-w-md mx-auto flex justify-between items-center text-center p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg mb-3 transition-opacity duration-500 opacity-100">
      <div>
          {{-- <i class="fas fa-times mr-2"></i> --}}

        {{ Session::get('error_message') }}
      </div>
      <span onclick="closeAlert('errorAlert')" class="text-red-700 cursor-pointer font-bold text-xl">&times;</span>
  </div>
  @endif

  {{-- success message --}}
  @if (Session::get('success_message'))
  <div id="successAlert" class="max-w-md mx-auto flex justify-between items-center text-center p-3 bg-green-100 border border-green-400 text-green-700 rounded-lg mb-3 transition-opacity duration-500 opacity-100">
      <div>
         {{ Session::get('success_message') }}
      </div>
      <span onclick="closeAlert('successAlert')" class="text-green-700 cursor-pointer font-bold text-xl">&times;</span>
  </div>
  @endif


  {{-- info message --}}
  @if (Session::get('info_message'))
  <div id="infoAlert" class="max-w-md mx-auto flex justify-between items-center text-center p-3 bg-info-600 text-white border border-green-400 rounded-lg mb-3 transition-opacity duration-500 opacity-100">
      <div>
      {{ Session::get('info_message') }}
      </div>
      <span onclick="closeAlert('infoAlert')" class="text-green-700 cursor-pointer font-bold text-xl">&times;</span>
  </div>
  @endif






 {{-- /Tailwind css --}}





<!-- ✅ Global Toast Component -->
<div
    x-data="toast()"
    x-on:toast.window="showToast($event.detail)"
    x-show="visible"
    x-transition:enter="transform ease-out duration-300 transition"
    x-transition:enter-start="translate-y-2 opacity-0"
    x-transition:enter-end="translate-y-0 opacity-100"
    x-transition:leave="transform ease-in duration-200 transition"
    x-transition:leave-start="opacity-100"
    x-transition:leave-end="opacity-0"
    x-cloak
    class="fixed top-6 right-6 z-50 w-auto max-w-xs sm:max-w-sm px-4 py-3 rounded-lg shadow-lg flex items-center space-x-3"
    :class="{
        'bg-green-600 text-white': type === 'success',
        'bg-red-600 text-white': type === 'error',
        'bg-info-600 text-white': type === 'info'
    }"
>
    <!-- Icon -->
    <template x-if="type === 'success'">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path>
        </svg>
    </template>

    <template x-if="type === 'error'">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
        </svg>
    </template>

    <template x-if="type === 'info'">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M13 16h-1v-4h-1m1-4h.01M12 19a9 9 0 100-18 9 9 0 000 18z"></path>
        </svg>
    </template>

    <!-- Message -->
    <span x-text="message" class="text-sm font-medium"></span>
</div>




 <script>
    function closeAlert(id) {
        const el = document.getElementById(id);
        if (el) {
            el.style.opacity = '0';
            setTimeout(() => el.remove(), 700); // remove after fade-out
        }
    }

    // Auto-close alerts after 5 seconds
    setTimeout(() => closeAlert('errorAlert'), 7000);
    setTimeout(() => closeAlert('successAlert'), 7000);
    setTimeout(() => closeAlert('infoAlert'), 7000);
    </script>












@push('scripts')



<script>
    function toast() {
        return {
            visible: false,
            message: '',
            type: 'info',
            timeoutId: null,

            showToast(detail) {
                this.message = detail.message || 'Success';
                this.type = detail.type || 'info';
                this.visible = true;

                clearTimeout(this.timeoutId);

                this.timeoutId = setTimeout(() => {
                    this.visible = false;
                }, 7000);
            }
        };
    }
</script>





{{--
<script>
    window.addEventListener('toast', event => {
        const { message, type } = event.detail;
        const toast = document.querySelector('[x-data]');
        if (!toast) return;

        toast.__x.$data.message = message;
        toast.__x.$data.type = type || 'success';
        toast.__x.$data.show = true;

        setTimeout(() => toast.__x.$data.show = false, 9000);
    });
</script> --}}

@endpush






