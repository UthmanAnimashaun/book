
@extends('front.layouts.coming-soon-layout')
@section('pageTitle', isset($pageTitle) ? $pageTitle : "Coming soon")
@section('meta_tags')
<meta name="robots" content="index,follow" />
<meta name="title" content="{{ optional($websites[0])->name }}" />
<meta name="description" content="{{ optional($websites[0])->website_description }}" />
<meta name="author" content="{{ optional($websites[0])->name }}" />
<link rel="canonical" hef="{{ Request::root() }}" />
<meta property="og:title" content="{{ optional($websites[0])->name }}" />
<meta property="og:type" content="website" />
<meta property="og:description" content="{{ optional($websites[0])->website_description }}" />
<meta property="og:url" content="{{ Request::root() }}" />
<meta property="og:image" content="{{ optional($websites[0])->logo }}" />
<meta name="twitter:domain" content="{{ Request::root() }}" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" property="og:title" itemprop="name" content="{{ optional($websites[0])->name }}" />
<meta name="twitter:description " property="og:description " itemprop="description "
    content="{{ optional($websites[0])->website_description }}" />
<meta name="twitter:image" content="{{ optional($websites[0])->logo  }}" />
@endsection
@section('content')


 <div class="">
    <div class="container px-4">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 text-center">
                <div class="brand-badge mb-4 animate__animated animate__fadeInDown">
                    <span class="badge-text">SYSTEM UPDATE</span>
                </div>

                <h1 class="coming-soon-title mb-3 animate__animated animate__zoomIn">
                    Coming Soon
                </h1>
                <p class="coming-soon-subtitle mb-5 mx-auto">
                    We are engineering a premium multi-vendor literary ecosystem. The deployment countdown sequence has been initialized.
                </p>

                <div class="countdown-card p-4 mb-5 animate__animated animate__fadeInUp">
                    <div class="row g-3 justify-content-center" id="countdown-grid">
                        <div class="col-3 text-center">
                            <div class="time-box" id="days-box">00</div>
                            <span class="time-label">Days</span>
                        </div>
                        <div class="col-3 text-center">
                            <div class="time-box" id="hours-box">00</div>
                            <span class="time-label">Hours</span>
                        </div>
                        <div class="col-3 text-center">
                            <div class="time-box" id="minutes-box">00</div>
                            <span class="time-label">Mins</span>
                        </div>
                        <div class="col-3 text-center">
                            <div class="time-box" id="seconds-box">00</div>
                            <span class="time-label">Secs</span>
                        </div>
                    </div>
                </div>

                <div class="status-footer text-muted font-monospace small">
                    <span class="pulse-indicator"></span> ALL SYSTEMS OPERATIONAL
                </div>
            </div>
        </div>
    </div>
</div>

    <script>
       let countDownDate = new Date("June 30, 2026 00:00:00").getTime();

let x = setInterval(function() {
    let now = new Date().getTime();
    let distance = countDownDate - now;
    
    let days = Math.floor(distance / (1000 * 60 * 60 * 24));
    let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    // Check elements map dynamically to secure layout transitions without throwing browser console errors
    let dBox = document.getElementById("days-box");
    let hBox = document.getElementById("hours-box");
    let mBox = document.getElementById("minutes-box");
    let sBox = document.getElementById("seconds-box");

    if (dBox && hBox && mBox && sBox) {
        dBox.innerHTML = days < 10 ? "0" + days : days;
        hBox.innerHTML = hours < 10 ? "0" + hours : hours;
        mBox.innerHTML = minutes < 10 ? "0" + minutes : minutes;
        sBox.innerHTML = seconds < 10 ? "0" + seconds : seconds;
    }
    
    if (distance < 0) {
        clearInterval(x);
        let grid = document.getElementById("countdown-grid");
        if (grid) {
            grid.innerHTML = `<div class="col-12 text-center text-white font-monospace fw-bold py-2" style="color: #00AEEF !important;">LAUNCHING SEQUENCE ACTIVATED</div>`;
        }
    }
}, 1000);
    </script>
@endsection