<?php
    use App\Models\Section; 
    use App\Models\Product; 
    $sections = Section::sections();
        $totalCartItems = totalCartItems();
?>

<header>
  <!-- Top-Header -->


  <div class="full-layer-outer-header">
      <div class="container clearfix">

        <nav>
            <ul class="primary-nav g-nav d-none d-md-block">
                <li>
                    <a href="tel:+111444989">
                        <i class="fas fa-phone u-c-brand u-s-m-r-4"></i>
                        Telephone:{{  optional($websites[0])->phone_number }}
                        {{-- Telephone:{{ Website()->phone_number->phone_number }} --}}
                    </a>                      
                </li>
                <li>
                    <a href="mailto:{{ optional($websites[0])->email }}">
                        <i class="fas fa-envelope u-c-brand u-s-m-r-9"></i>
                        E-mail: {{ optional($websites[0])->email }}
                    </a>
                </li>
            </ul>
        </nav>

          <nav>
              <ul class="secondary-nav g-nav">
                <li>
                    <a>
                    @if (Auth::check())
                        My Account
                    @else
                        Login / Register
                    @endif
                    
                        <i class="fas fa-chevron-down u-s-m-l-9"></i>
                    </a>
                    <ul class="g-dropdown" style="width:200px">
                        <li>
                            <a href="{{ asset('/cart') }}">
                                <i class="fas fa-cog u-s-m-r-9"></i>
                                My Cart</a>
                        </li>
                        
                        
                        @if (Auth::check())
                            
                        <li>
                            <a href="{{ asset('user/orders') }}">
                                <i class="fas fa-sign-in-alt u-s-m-r-9"></i>
                                My Orders</a>
                        </li>
                        <li>
                            <a href="{{ asset('user/account') }}">
                                <i class="fas fa-sign-in-alt u-s-m-r-9"></i>
                                My Account</a>
                        </li>
                        <li>
                            <a href="{{ asset('/checkout') }}">
                                <i class="far fa-check-circle u-s-m-r-9"></i>
                                Checkout</a>
                        </li>
                        <li>
                            <a href="{{ asset('user/logout') }}">
                                <i class="fas fa-sign-in-alt u-s-m-r-9"></i>
                                Logout</a>
                        </li>
                        @else
                        <li>
                            <a href="{{ asset('user/login') }}">
                                <i class="fas fa-sign-in-alt u-s-m-r-9"></i>
                                Customer Login</a>
                        </li>
                        
                        @endif
                        
                    </ul>
                </li>
                <li>
                  
                   @livewire('pages.cart.cart-badge')
                </li>
                 
              </ul>
          </nav>
      </div>
  </div>

  
  <nav class="navbar mt-0 mb-5 navbar-expand-lg navbar-fixed navbar-light text-danger bg-light">
    <a class="navbar-brand" href="{{ asset('/') }}">
            <img src="/storage/images/logo/{{ optional($websites[0])->logo  }}"
                alt="{{ optional($websites[0])->logo }}" 
                class="app-bra " width="100" height="100">

        </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
        <li class="nav-item active">
        <a class="nav-link" href="{{ asset('/') }}">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link"  href="{{ asset('about') }}" class="u-c-brand">About Us</a>
        </li>
        <li class="nav-item">
            <a class="nav-link"  href="{{ asset('contact') }}">Contact Us</a>
        </li>
       
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            More
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
           
            <a class="dropdown-item"  href="{{ asset('faq') }}">FAQ</a>
            <a class="dropdown-item"  href="{{ asset('tc') }}">T&C</a>
            
        </li>
       
    </ul>
  
    </div>
</nav>


  <!-- Mini Cart -->
  <div id="appendHeaderCartItems">

        {{-- @include('front.layouts.header_cart_items') --}}
        @livewire('pages.cart.cart-head')

  </div>
  <!-- Mini Cart /- -->
  <!-- Bottom-Header -->
  <div class="full-layer-bottom-header">
      <div class="container">
          <div class="row align-items-center">
              <div class="col-lg-3">
                  <div class="v-menu v-close">
                      <span class="v-title">
                          <i class="ion ion-md-menu"></i>
                          All Sections
                          <i class="fas fa-angle-down"></i>
                      </span>
                      <nav>
                          <div class="v-wrapper">
                              <ul class="v-list animated fadeIn">
                                @foreach (\App\Models\Section::where('status', 1)
    ->whereHas('categories', function ($q) {
        $q->whereHas('products');
    })->get() as $section)

    <li class="js-backdrop">
        <a href="javascript:;">
            <i class="ion-ios-add-circle"></i>
            {{ $section->name }}
            <i class="ion ion-ios-arrow-forward"></i>
        </a>
        <button class="v-button ion ion-md-add"></button>
        <div class="v-drop-right" style="width: 700px;">
            <div class="row">
                @foreach (\App\Models\Category::where('section_id', $section->id)
                    ->whereHas('products')
                    ->get() as $category)
                    <div class="col-lg-4">
                        <ul class="v-level-2">
                            <li>
                                <a href="{{ asset($category->category_slug) }}">
                                    {{ $category->category_name }}
                                </a>
                            </li>
                        </ul>
                    </div>
                @endforeach
            </div>
        </div>
    </li>

@endforeach
                                      
                              </ul>
                          </div>
                      </nav>
                  </div>
              </div>
             
          </div>
      </div>
  </div>
  <!-- Bottom-Header /- -->
</header>
