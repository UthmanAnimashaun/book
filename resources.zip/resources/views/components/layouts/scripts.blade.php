<script>
       
$(document).ready(function(){

        // filter product
        $('#sort').on("change", function(){
        var sort = $('#sort').val();
        var category_slug = $('#category_slug').val();
        var price = get_filter('price');
        var brand = get_filter('brand');
        

        // alert(sort); return false;

        $.ajax({          
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')
            },

            method:'post',
            url:category_slug,
            data:{
                sort:sort,
                category_slug:category_slug,
                price:price,
                brand:brand
            },
            success:function(data){
                
                    $('.filter_products').html(data);
            },
            error:function(data){
                butterup.toast({
                    message:'Something went wrong ',
                    type:'error',
                    icon:true
                }); 
            },
        });
});


});





$(document).ready(function(){

        // filter Price
        $('.price').on("change", function(){
        // this.form.submit();
        var price = get_filter('price');
        var brand = get_filter('brand');
        var sort = $('#sort').val();
        var category_slug = $('#category_slug').val();
 

        $.ajax({          
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')
            },

            method:'post',
            url:category_slug,
            data:{
                sort:sort,
                category_slug:category_slug,
                price:price,
                brand:brand
            },
            success:function(data){
                
                    $('.filter_products').html(data);
            },
            error:function(data){
                butterup.toast({
                    message:'Something went wrong ',
                    type:'error',
                    icon:true
                }); 
            },
        });
        });
});

$(document).ready(function(){

        // filter brand
        $('.brand').on("change", function(){
        // this.form.submit();
        var price = get_filter('price');
        var brand = get_filter('brand');
        var sort = $('#sort').val();
        var category_slug = $('#category_slug').val();
 

        $.ajax({          
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')
            },

            method:'post',
            url:category_slug,
            data:{
                sort:sort,
                category_slug:category_slug,
                price:price,
                brand:brand
            },
            success:function(data){
                
                    $('.filter_products').html(data);
            },
            error:function(data){
                butterup.toast({
                    message:'Something went wrong ',
                    type:'error',
                    icon:true
                }); 
            },
        });
        });
});


</script>