<!DOCTYPE html>
<html class="no-js" lang="en-US">

<head>
  <meta charset="UTF-8">
  <!--[if IE]>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <![endif]-->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>@yield('pageTitle') - {{ optional($websites[0])->name }}</title>	
	@yield('meta_tags')
  <meta name="csrf_token" content="{{ csrf_token() }}">
  <meta name="theme-name" content="{{ optional($websites[0])->name }}" />

  @vite('resources/css/app.css')
  @livewireStyles

  <!-- Standard Favicon -->
  <link href="/storage/images/logo/{{ optional($websites[0])->logo  }}" rel="shortcut icon">
  <!-- Base Google Font for Web-app -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
  <!-- Google Fonts for Banners only -->
  <link href="https://fonts.googleapis.com/css?family=Raleway:400,800" rel="stylesheet">

  {{-- datatable --}}
  
  <link rel="stylesheet" href="/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <link rel="stylesheet" type="text/css" href="/admin/js/select.dataTables.min.css">


  <!-- Bootstrap 4 -->
  <link rel="stylesheet" href="/front/css/bootstrap.min.css">
  <!-- Font Awesome 5 -->
  <link rel="stylesheet" href="/front/css/fontawesome.min.css">
  <!-- Ion-Icons 4 -->
  <link rel="stylesheet" href="/front/css/ionicons.min.css">
  <!-- Animate CSS -->
  <link rel="stylesheet" href="/front/css/animate.min.css">
  <!-- Owl-Carousel -->
  <link rel="stylesheet" href="/front/css/owl.carousel.min.css">
  <!-- Jquery-Ui-Range-Slider -->
  <link rel="stylesheet" href="/front/css/jquery-ui-range-slider.min.css">
  <!-- Utility -->
  <link rel="stylesheet" href="/front/css/utility.css">
  <!-- Main -->
  <link rel="stylesheet" href="/front/css/bundle.css">
  <link rel="stylesheet" href="/front/css/easyzoom.css">
  {{-- Loader--}}
  <link rel="stylesheet" href="/front/css/custom.css">
  {{-- sweetAlert & Butterup--}}
  <link rel="stylesheet" href="/admin/butterup/butterup.min.css">
  <link href="/admin/sweetalert/sweetalert2.css" rel="stylesheet"/>

     {{-- <script src="/admin/butterup/butterup.min.js"></script> --}}
     <script src="/admin/butterup/butterup.js"></script>
  
  <style>
    html {
      scroll-behavior: smooth;
    }
    a {
  text-decoration: none !important;
}
    .double{
      text-decoration-style: double;
    }
    .notification {
  text-decoration: none;
  padding: 5px 6px;
  position: relative;
  display: inline-block;
  border-radius: 2px;
}

.ion-md-basket{
  font-size: 17px;
}

.notification .badge {
  position: absolute;
  top: 5px;
  right: -10px;
  padding: 2px 4px;
  border-radius: 50%;
  background: red;
  color: white;
}

  </style>

@stack('stylesheets')

</head>

<body>
  <div class="loader">
    <img src="/storage/images/loader/loader.gif" alt="loading">
  </div>

  <!-- app -->
    <div id="app">

      {{-- header here --}}
      {{-- @include('components.layouts.header') --}}
      <x-layouts.header /> 

      <!-- partial:partials/_sidebar.html -->
      {{-- @include('layout.sidebar') --}}
      <!-- partial -->
      <div class="main-panel">
        @yield('content')
        {{-- {{ $slot }} --}}
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        {{-- @include('components.layouts.footer') --}}
        <x-layouts.footer />

        {{-- @include('layouts.modals') --}}
        <!-- partial -->
    </div>
      <!-- main-panel ends -->




         <!-- app /- -->
              <!--[if lte IE 9]>
        <div class="app-issue">
            <div class="vertical-center">
                <div class="text-center">
                    <h1>You are using an outdated browser.</h1>
                    <span>This web app is not compatible with following browser. Please upgrade your browser to improve your security and experience.</span>
                </div>
            </div>
        </div>
        <style> #app {
            display: none;
        } </style>
        <![endif]-->
      <!-- NoScript -->
      <noscript>
        <div class="app-issue">
          <div class="vertical-center">
            <div class="text-center">
              <h1>JavaScript is disabled in your browser.</h1>
              <span>Please enable JavaScript in your browser or upgrade to a JavaScript-capable browser.</span>
            </div>
          </div>
        </div>
        <style>
          #app {
            display: none;
          }
        </style>
      </noscript>
      <!-- Google Analytics: change UA-XXXXX-Y to be your site's ID. -->
      <script>
                  window.ga = function() {
            ga.q.push(arguments)
          };
          ga.q = [];
          ga.l = +new Date;
          ga('create', 'UA-XXXXX-Y', 'auto');
          ga('send', 'pageview')
      </script>
      <script src="/front/https://www.google-analytics.com/analytics.js" async defer></script>
      <!-- Modernizr-JS -->
      <script type="text/javascript" src="/front/js/vendor/modernizr-custom.min.js"></script>
      <!-- NProgress -->
      <script type="text/javascript" src="/front/js/nprogress.min.js"></script>
      <!-- jQuery -->
      <script type="text/javascript" src="/front/js/jquery.min.js"></script>
      <!-- Bootstrap JS -->
      <script type="text/javascript" src="/front/js/bootstrap.min.js"></script>
      <!-- Popper -->
      <script type="text/javascript" src="/front/js/popper.min.js"></script>
      <!-- ScrollUp -->
      <script type="text/javascript" src="/front/js/jquery.scrollUp.min.js"></script>
      <!-- Elevate Zoom -->
      <script type="text/javascript" src="/front/js/jquery.elevatezoom.min.js"></script>
      <!-- jquery-ui-range-slider -->
      <script type="text/javascript" src="/front/js/jquery-ui.range-slider.min.js"></script>
      <!-- jQuery Slim-Scroll -->
      <script type="text/javascript" src="/front/js/jquery.slimscroll.min.js"></script>
      <!-- jQuery Resize-Select -->
      <script type="text/javascript" src="/front/js/jquery.resize-select.min.js"></script>
      <!-- jQuery Custom Mega Menu -->
      <script type="text/javascript" src="/front/js/jquery.custom-megamenu.min.js"></script>
      <!-- jQuery Countdown -->
      <script type="text/javascript" src="/front/js/jquery.custom-countdown.min.js"></script>
      <!-- Owl Carousel -->
      <script type="text/javascript" src="/front/js/owl.carousel.min.js"></script>
      <!-- Main -->
      <script type="text/javascript" src="/front/js/app.js"></script>
      <script type="text/javascript" src="/front/js/custom.js"></script>
   
      <script src="/front/js/easyzoom.js"></script>

      {{-- dataTable --}}
      
  <script src="/admin/vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <script src="/admin/js/dataTables.select.min.js"></script>
	<script>
		// Instantiate EasyZoom instances
		var $easyzoom = $('.easyzoom').easyZoom();

		// Setup thumbnails example
		var api1 = $easyzoom.filter('.easyzoom--with-thumbnails').data('easyZoom');

		$('.thumbnails').on('click', 'a', function(e) {
			var $this = $(this);

			e.preventDefault();

			// Use EasyZoom's `swap` method
			api1.swap($this.data('standard'), $this.attr('href'));
		});

		// Setup toggles example
		var api2 = $easyzoom.filter('.easyzoom--with-toggle').data('easyZoom');

		$('.toggle').on('click', function() {
			var $this = $(this);

			if ($this.data("active") === true) {
				$this.text("Switch on").data("active", false);
				api2.teardown();
			} else {
				$this.text("Switch off").data("active", true);
				api2._init();
			}
		});
                                         
    </script>
   <script>
    $(document).ready(function(){
  
     $('#trans').DataTable();
  
     });
</script>

@stack('scripts')

      {{-- @include('components.layouts.scripts') --}}
      <x-layouts.scripts />
      <script src="/admin/sweetalert/sweetalert2.js"></script> 

</body>

</html>
