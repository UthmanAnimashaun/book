<footer class="footer">
  <div class="container">
      <!-- Outer-Footer -->
      <div class="outer-footer-wrapper u-s-p-y-80">
          <h6>
              For special offers and other discount information
          </h6>
          <h1>
              Subscribe to our Newsletter
          </h1>
          <p>
              Subscribe to the mailing list to receive updates on promotions, new arrivals, discount and coupons.
          </p>
          <form class="newsletter-form">
              <label class="sr-only" for="newsletter-field">Enter your Email</label>
              <input type="text" id="newsletter-field" placeholder="Your Email Address">
              <button type="submit" class="button">SUBMIT</button>
          </form>
      </div>
      <!-- Outer-Footer /- -->
      <!-- Mid-Footer -->
      <div class="mid-footer-wrapper u-s-p-b-80">
          <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-12">
                  <div class="footer-list">
                      <h6>COMPANY</h6>
                      <ul>
                          <li>
                              <a href="{{ asset('about') }}">About Us</a>
                          </li>
                          <li>
                              <a href="{{ asset('contact') }}">Contact Us</a>
                          </li>
                          <li>
                              <a href="{{ asset('faq') }}">FAQ</a>
                          </li>
                      </ul>
                  </div>
              </div>
             
            
              <div class="col-lg-6 col-md-6 col-sm-12">
                  <div class="footer-list">
                      <h6>Contact</h6>
                      <ul>
                          <li>
                              <i class="fas fa-location-arrow u-s-m-r-9"></i>
                              <span>{{ optional($websites[0])->name }}</span>
                          </li>
                          <li>
                              <a href="tel:{{ optional($websites[0])->phone_number }}">
                                  <i class="fas fa-phone u-s-m-r-9"></i>
                                  <span>{{ optional($websites[0])->phone_number }}</span>
                              </a>
                          </li>
                          <li>
                              <a href="mailto:{{ optional($websites[0])->email }}">
                                  <i class="fas fa-envelope u-s-m-r-9"></i>
                                  <span>
                                      {{ optional($websites[0])->email }}</span>
                              </a>
                          </li>
                      </ul>
                  </div>
              </div>
          </div>
      </div>
      <!-- Mid-Footer /- -->
      
  </div>
  <!-- Bottom-Footer /- -->
</footer>