import './bootstrap';
// import "tailwindcss";

import 'preline';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
